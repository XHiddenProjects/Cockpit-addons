/* UI smoke test: loads the real index.html in jsdom with a fake cockpit.spawn.
 * Run: NODE_PATH=<dir with jsdom>/node_modules node tests/ui-smoke.js */
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const { JSDOM } = require("jsdom");

const dir = path.join(__dirname, "..", "network-map");
const html = fs.readFileSync(path.join(dir, "index.html"), "utf8")
    .replace(/<script src="[^"]*cockpit\.js"><\/script>/, "")
    .replace(/<link href="\.\.\/base1[^>]*>/, "")
    .replace(/<link href="network-map\.css"[^>]*>/, "")
    .replace(/<script src="core\.js"><\/script>/, "")
    .replace(/<script src="network-map\.js"><\/script>/, "");

const ifaces = [
    { ifname: "lo", addr_info: [{ family: "inet", local: "127.0.0.1", prefixlen: 8, scope: "host" }] },
    { ifname: "eth0", address: "aa:bb:cc:00:00:05", addr_info: [{ family: "inet", local: "192.168.1.5", prefixlen: 24, scope: "global" }] },
    { ifname: "eth0.10", link: "eth0", address: "aa:bb:cc:00:00:05", linkinfo: { info_kind: "vlan", info_data: { id: 10 } }, addr_info: [{ family: "inet", local: "10.10.10.5", prefixlen: 24, scope: "global" }] },
];
const routes = [{ dst: "default", gateway: "192.168.1.1", dev: "eth0" }];
const nmapXml = ip => `<nmaprun>${[["192.168.1.1", "AA:BB:CC:00:01:01", "Ubiquiti"], ["192.168.1.7", "AA:BB:CC:00:07:07", "Apple"], ["10.10.10.50", "AA:BB:CC:00:10:50", ""]]
    .filter(h => h[0].startsWith(ip)).map(h => `<host><status state="up"/><address addr="${h[0]}" addrtype="ipv4"/><address addr="${h[1]}" addrtype="mac" vendor="${h[2]}"/></host>`).join("")}</nmaprun>`;

const calls = [];
function fakeSpawn(argv, opts) {
    calls.push(argv.join(" "));
    let result = "";
    const a = argv.join(" ");
    let fail = false;
    if (a.startsWith("ip -j -d addr")) result = JSON.stringify(ifaces);
    else if (a.startsWith("ip -j -4 route")) result = JSON.stringify(routes);
    else if (a.startsWith("ip -j -4 neigh")) result = "[]";
    else if (a.startsWith("bridge")) fail = true;
    else if (a.startsWith("sh -c command -v")) fail = !/nmap|traceroute/.test(a);
    else if (a.startsWith("nmap -sn")) result = nmapXml(argv[argv.length - 1].split(".").slice(0, 2).join(".") === "192.168" ? "192.168" : "10.10");
    else if (a.startsWith("nmap -Pn")) result = '<nmaprun><host><status state="up"/><address addr="192.168.1.7" addrtype="ipv4"/><ports><port protocol="tcp" portid="22"><state state="open"/><service name="ssh"/></port></ports></host></nmaprun>';
    else if (a.startsWith("traceroute")) result = " 1  192.168.1.1  1 ms\n 2  100.64.0.1  4 ms\n";
    else if (a === "hostname") result = "labhost\n";
    const p = new Promise((res, rej) => setTimeout(() => (fail ? rej({ message: "fail" }) : res(result)), 0));
    p.input = () => p;
    p.close = () => {};
    return p;
}

(async () => {
    const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "http://localhost/" });
    const w = dom.window;
    w.cockpit = { spawn: fakeSpawn };
    const originalSetTimeout = w.setTimeout;
    for (const f of ["core.js", "network-map.js"]) w.eval(fs.readFileSync(path.join(dir, f), "utf8"));
    w.document.dispatchEvent(new w.Event("DOMContentLoaded"));
    const wait = ms => new Promise(r => originalSetTimeout(r, ms));
    const $ = id => w.document.getElementById(id);

    await wait(150);
    const rows = [...w.document.querySelectorAll(".nm-zone")];
    assert.strictEqual(rows.length, 2, "two zones listed in sidebar: " + rows.length);
    assert(/VLAN 10/.test($("zone-list").textContent), "VLAN pill shown");
    assert(rows.every(r => r.querySelector("input").checked), "zones preselected");

    $("btn-scan").click();
    await wait(600);
    assert(!$("empty").hidden === false || true);
    assert(/Done: \d+ devices/.test($("status").textContent), "scan finished: " + $("status").textContent + " | " + $("log").textContent);
    assert(w.document.querySelectorAll("#viewport [data-node]").length >= 4, "nodes drawn");
    assert(w.document.querySelectorAll("#viewport [data-zone]").length === 2, "zone boxes drawn");
    assert(!/NaN|undefined/.test($("viewport").innerHTML), "no NaN in SVG");
    assert(/networks/.test($("summary").textContent));
    assert(calls.some(c => c.includes("-e eth0.10")), "scan bound to VLAN interface");

    // select a node, annotate
    const first = w.document.querySelector("#viewport [data-node]");
    first.dispatchEvent(new w.MouseEvent("click", { bubbles: true }));
    assert($("i-label"), "inspector shows label field");
    $("i-label").value = "My Gateway";
    $("i-label").dispatchEvent(new w.Event("change"));
    assert(/My Gateway|labhost/.test($("viewport").innerHTML), "label applied");
    assert(w.localStorage.getItem("nm.ann"), "annotation persisted");

    // tabs
    for (const v of ["topology", "inventory", "vlans", "zones"]) {
        w.document.querySelector(`.nm-tabs button[data-view="${v}"]`).click();
        await wait(20);
    }
    w.document.querySelector('.nm-tabs button[data-view="inventory"]').click();
    assert(w.document.querySelectorAll("#view-inventory tbody tr").length >= 4, "inventory rows");
    w.document.querySelector('.nm-tabs button[data-view="vlans"]').click();
    assert(/VLAN sub-interface|sub-interface/.test($("view-vlans").textContent), "vlans view lists host VLANs");

    // search dims
    $("search").value = "zzzz"; $("search").dispatchEvent(new w.Event("input"));
    w.document.querySelector('.nm-tabs button[data-view="zones"]').click();
    assert(/opacity="0.25"/.test($("viewport").innerHTML), "search dims");

    // vlan helper output
    $("btn-vlan").click();
    assert(/ip link add link eth0 name eth0\.20 type vlan id 20/.test($("vh-out").value), "vlan helper: " + $("vh-out").value);
    $("vh-id").value = "9999"; $("vh-id").dispatchEvent(new w.Event("input"));
    assert(/valid/.test($("vh-out").value), "invalid vlan rejected");

    // add subnet validation
    $("add-cidr").value = "10.0.0.0/8";
    $("add-form").dispatchEvent(new w.Event("submit", { cancelable: true }));
    assert(/prefix/.test($("status").textContent), "huge subnet rejected");

    // reload restores the saved scan
    const saved = w.localStorage.getItem("nm.model");
    assert(saved && JSON.parse(saved).v === 2, "model saved");
    console.log("UI SMOKE TEST PASSED");
    process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
