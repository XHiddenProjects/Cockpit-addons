#!/usr/bin/env bash
# Installs (or upgrades) VM Portal: Cockpit page, backend service, console proxy and guest firewall.
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "Run as root (sudo ./install.sh)"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"

echo "==> Installing dependencies"
if command -v apt-get >/dev/null; then
    apt-get update -qq
    apt-get install -y cockpit libvirt-clients libvirt-daemon-system qemu-system-x86 qemu-utils ovmf \
        websockify novnc python3 nftables
    apt-get install -y libguestfs-tools || echo "(optional) libguestfs-tools not installed; per-guest sysprep disabled"
elif command -v dnf >/dev/null; then
    dnf install -y cockpit libvirt-client libvirt-daemon-kvm qemu-img edk2-ovmf python3-websockify novnc python3 nftables
    dnf install -y guestfs-tools || echo "(optional) guestfs-tools not installed; per-guest sysprep disabled"
else
    echo "Unsupported distro: install cockpit, libvirt, qemu-img, ovmf, websockify, novnc, python3, nftables manually."
fi

echo "==> Installing files"
install -d /usr/lib/vm-portal /usr/share/vm-portal/web /usr/share/cockpit/vm-portal
install -d -m 755 /etc/vm-portal
install -m 755 "$SRC/backend/vmportal.py" /usr/lib/vm-portal/vmportal
install -m 755 "$SRC/uninstall.sh" /usr/lib/vm-portal/uninstall.sh
install -m 644 "$SRC"/web/portal.* /usr/share/vm-portal/web/
install -m 644 "$SRC"/cockpit/vm-portal/* /usr/share/cockpit/vm-portal/
# The config is read by the unprivileged console proxy, so it must be world-readable (it holds no secrets).
[ -f /etc/vm-portal/config.json ] || install -m 644 "$SRC/deploy/config.json" /etc/vm-portal/config.json
chmod 644 /etc/vm-portal/config.json
install -m 644 "$SRC/deploy/nftables.conf" /etc/vm-portal/nftables.conf
install -m 644 "$SRC/deploy/vmportal-net.xml" /etc/vm-portal/vmportal-net.xml
install -m 644 "$SRC"/deploy/*.service /etc/systemd/system/
install -d -m 755 /var/lib/vm-portal /var/lib/vm-portal/clones /var/lib/vm-portal/golden \
    /var/lib/vm-portal/library /var/lib/vm-portal/vms
install -d -m 700 /var/lib/vm-portal/uploads
ln -sf /usr/lib/vm-portal/vmportal /usr/local/bin/vmportal
install -d /usr/local/sbin
ln -sf /usr/lib/vm-portal/uninstall.sh /usr/local/sbin/vm-portal-uninstall

echo "==> Creating isolated libvirt network 'vmportal'"
systemctl enable --now libvirtd 2>/dev/null || systemctl enable --now libvirtd.socket 2>/dev/null || true
if ! virsh net-info vmportal >/dev/null 2>&1; then
    virsh net-define /etc/vm-portal/vmportal-net.xml
fi
virsh net-autostart vmportal >/dev/null
virsh net-start vmportal 2>/dev/null || true

echo "==> Starting services"
systemctl daemon-reload
systemctl enable vm-portal-nft.service vm-portal.service vm-portal-ws.service
systemctl restart vm-portal-nft.service vm-portal.service vm-portal-ws.service

cat <<EOF

Done.
  * Open Cockpit -> "VM Portal". Upload an ISO / OVA / disk image or use an existing VM, make a template,
    then create an invite link. Everything, including settings, is configured in that page.
  * Open firewall ports 8480 (portal) and 6080 (console) -- or put both behind a TLS reverse proxy.
    See README.md before exposing this to the internet.
  * Uninstall: use the page (Settings -> Remove VM Portal) or run: sudo vm-portal-uninstall [--purge]
EOF
