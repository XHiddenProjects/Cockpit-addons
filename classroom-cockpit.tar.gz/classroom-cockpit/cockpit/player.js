/*
 * Custom recording player.
 *
 * One control surface (play/pause, scrub bar, +/-10s, speed, fullscreen, keyboard shortcuts)
 * driving one of two engines, because a recording is stored in one of two forms:
 *   - "mp4"    : ffmpeg was available when the recording stopped -> a normal video file
 *   - "frames" : ffmpeg wasn't (or failed) -> a folder of 1-per-second JPEGs
 * The admin never needs to know which; both look and behave identically here.
 *
 *   createPlayer(host, { kind, info, loadVideo(), loadFrame(i), onError(msg) }) -> { destroy() }
 *     loadVideo() -> Promise<Uint8Array>      whole mp4
 *     loadFrame(i) -> Promise<Uint8Array>     jpeg number i
 */
(function () {
  const ICON = {
    play: '<path d="M8 5v14l11-7z"/>',
    pause: '<path d="M6 5h4v14H6zM14 5h4v14h-4z"/>',
    back: '<path d="M12 5V2L7 6.5 12 11V8a5 5 0 1 1-5 5H5a7 7 0 1 0 7-8z"/><text x="8.2" y="16.2" font-size="6.5" font-weight="700" fill="currentColor" stroke="none">10</text>',
    fwd: '<path d="M12 5V2l5 4.5L12 11V8a5 5 0 1 0 5 5h2a7 7 0 1 1-7-8z"/><text x="8.2" y="16.2" font-size="6.5" font-weight="700" fill="currentColor" stroke="none">10</text>',
    full: '<path d="M5 5h5v2H7v3H5zM14 5h5v5h-2V7h-3zM5 14h2v3h3v2H5zM17 14h2v5h-5v-2h3z"/>',
    exit: '<path d="M8 5h2v5H5V8h3zM14 5h2v3h3v2h-5zM5 14h5v5H8v-3H5zM14 14h5v2h-3v3h-2z"/>',
  };
  const svg = n => `<svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">${ICON[n]}</svg>`;
  const SPEEDS = [0.5, 1, 1.5, 2, 4, 8];

  function fmt(t) {
    t = Math.max(0, Math.floor(t || 0));
    const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
    const p = n => String(n).padStart(2, "0");
    return h ? `${h}:${p(m)}:${p(s)}` : `${m}:${p(s)}`;
  }

  /* ---------- engines: same tiny interface -------------------------------------------------
   * duration() time() playing() play() pause() seek(t) setRate(r) destroy()
   * They call h.update() on any change and h.busy(bool) while buffering. */

  function videoEngine(stage, loadVideo, h) {
    const v = document.createElement("video");
    v.playsInline = true; v.preload = "auto"; v.className = "cls-player-media";
    stage.appendChild(v);
    let url = null, dead = false;
    ["timeupdate", "durationchange", "loadedmetadata", "play", "pause", "ended", "seeked"].forEach(e =>
      v.addEventListener(e, () => h.update()));
    v.addEventListener("waiting", () => h.busy(true));
    v.addEventListener("playing", () => h.busy(false));
    v.addEventListener("canplay", () => h.busy(false));
    v.addEventListener("error", () => h.error("This video can't be played in the browser."));
    h.busy(true, "Loading video…");
    loadVideo().then(bytes => {
      if (dead) return;
      url = URL.createObjectURL(new Blob([bytes], { type: "video/mp4" })); v.src = url; h.ready();
    }).catch(e => h.error(e.message || String(e)));
    return {
      duration: () => (isFinite(v.duration) ? v.duration : 0),
      time: () => v.currentTime,
      playing: () => !v.paused && !v.ended,
      play: () => { if (v.ended) v.currentTime = 0; return v.play(); },
      pause: () => v.pause(),
      seek: t => { v.currentTime = Math.max(0, Math.min(t, v.duration || 0)); },
      setRate: r => { v.playbackRate = r; },
      destroy: () => { dead = true; v.pause(); v.removeAttribute("src"); v.load(); if (url) URL.revokeObjectURL(url); v.remove(); },
    };
  }

  function frameEngine(stage, info, loadFrame, h) {
    const img = document.createElement("img");
    img.className = "cls-player-media"; img.alt = "Recording frame";
    stage.appendChild(img);
    const N = info.frames, AHEAD = 6, KEEP = 24;
    const cache = new Map(), pending = new Set();
    let t = 0, rate = 1, play = false, last = performance.now(), shown = -1, dead = false;

    const want = i => {
      if (i < 0 || i >= N || cache.has(i) || pending.has(i)) return;
      pending.add(i);
      loadFrame(i).then(b => { cache.set(i, URL.createObjectURL(new Blob([b], { type: "image/jpeg" }))); })
        .catch(() => {}).finally(() => pending.delete(i));
    };
    const trim = cur => {
      for (const [k, u] of cache) if (k < cur - KEEP || k > cur + KEEP * 2) { URL.revokeObjectURL(u); cache.delete(k); }
    };
    const timer = setInterval(() => {
      if (dead) return;
      const now = performance.now(), dt = (now - last) / 1000; last = now;
      const cur = Math.min(N - 1, Math.floor(t));
      for (let k = 0; k <= AHEAD; k++) want(cur + k);
      want(cur);
      if (cache.has(cur)) {
        if (shown !== cur) { img.src = cache.get(cur); shown = cur; trim(cur); }
        h.busy(false);
        if (play) {
          t += dt * rate;
          if (t >= N) { t = N; play = false; }
          h.update();
        }
      } else if (N) h.busy(true, "Buffering…");   // time stands still until the frame arrives
    }, 100);
    if (!N) h.error("This recording has no frames.");
    h.ready();
    return {
      duration: () => N,
      time: () => Math.min(t, N),
      playing: () => play,
      play: () => { if (t >= N) t = 0; play = true; last = performance.now(); h.update(); },
      pause: () => { play = false; h.update(); },
      seek: s => { t = Math.max(0, Math.min(s, N)); shown = -1; h.update(); },
      setRate: r => { rate = r; },
      destroy: () => { dead = true; clearInterval(timer); cache.forEach(u => URL.revokeObjectURL(u)); cache.clear(); img.remove(); },
    };
  }

  /* ---------- the control surface --------------------------------------------------------- */

  window.createPlayer = function (host, opts) {
    host.replaceChildren();
    const root = document.createElement("div");
    root.className = "cls-player"; root.tabIndex = 0;
    root.innerHTML = `
      <div class="cls-player-stage">
        <div class="cls-player-overlay" hidden><span class="cls-player-spinner"></span><span class="cls-player-overlay-text"></span></div>
        <div class="cls-player-bigplay" hidden>${svg("play").replace('width="20" height="20"', 'width="44" height="44"')}</div>
      </div>
      <div class="cls-player-controls">
        <div class="cls-player-scrub">
          <input type="range" min="0" max="1000" value="0" step="1" aria-label="Seek">
          <div class="cls-player-tip" hidden></div>
        </div>
        <div class="cls-player-row">
          <button type="button" class="cls-pbtn" data-a="play" title="Play / pause (space)"></button>
          <button type="button" class="cls-pbtn" data-a="back" title="Back 10 s (J)">${svg("back")}</button>
          <button type="button" class="cls-pbtn" data-a="fwd" title="Forward 10 s (L)">${svg("fwd")}</button>
          <span class="cls-ptime">0:00 / 0:00</span>
          <span class="cls-pspacer"></span>
          <button type="button" class="cls-pbtn cls-pspeed" data-a="speed" title="Playback speed (&lt; &gt;)">1×</button>
          <button type="button" class="cls-pbtn" data-a="full" title="Fullscreen (F)"></button>
        </div>
      </div>`;
    host.appendChild(root);

    const $ = s => root.querySelector(s);
    const stage = $(".cls-player-stage"), overlay = $(".cls-player-overlay"), big = $(".cls-player-bigplay");
    const range = $("input[type=range]"), tip = $(".cls-player-tip"), time = $(".cls-ptime");
    const bPlay = $('[data-a="play"]'), bFull = $('[data-a="full"]'), bSpeed = $('[data-a="speed"]');
    let speedIx = 1, scrubbing = false, failed = false, idleTimer = null, eng = null;

    const h = {
      update() { render(); },
      busy(on, text) { overlay.hidden = !on || failed; overlay.querySelector(".cls-player-overlay-text").textContent = text || ""; },
      ready() { overlay.hidden = true; render(); },
      error(msg) {
        failed = true; overlay.hidden = false; overlay.classList.add("cls-player-error");
        overlay.innerHTML = ""; overlay.append(Object.assign(document.createElement("span"), { textContent: msg }));
        opts.onError && opts.onError(msg);
      },
    };

    eng = opts.kind === "mp4"
      ? videoEngine(stage, opts.loadVideo, h)
      : frameEngine(stage, opts.info, opts.loadFrame, h);

    function render() {
      if (!eng) return;                       // engines may call update() before they're returned
      const d = eng.duration(), t = eng.time(), playing = eng.playing();
      bPlay.innerHTML = svg(playing ? "pause" : "play");
      big.hidden = playing || failed;
      root.classList.toggle("cls-playing", playing);
      if (!scrubbing) range.value = d ? Math.round(t / d * 1000) : 0;
      range.style.setProperty("--pct", (d ? t / d * 100 : 0) + "%");
      time.textContent = `${fmt(t)} / ${fmt(d)}`;
      bFull.innerHTML = svg(isFull() ? "exit" : "full");
    }
    const toggle = () => { if (!failed) (eng.playing() ? eng.pause() : eng.play()); render(); };
    const skip = s => { eng.seek(eng.time() + s); render(); };
    const setSpeed = i => {
      speedIx = Math.max(0, Math.min(SPEEDS.length - 1, i));
      eng.setRate(SPEEDS[speedIx]); bSpeed.textContent = SPEEDS[speedIx] + "×";
    };

    // Fullscreen: the Cockpit shell's iframe may not allow the Fullscreen API, so fall back to
    // a fixed-position "expanded" mode that fills the whole page instead.
    const isFull = () => document.fullscreenElement === root || root.classList.contains("cls-expanded");
    const toggleFull = () => {
      if (document.fullscreenElement === root) return document.exitFullscreen();
      if (root.classList.contains("cls-expanded")) { root.classList.remove("cls-expanded"); return render(); }
      const p = root.requestFullscreen ? root.requestFullscreen() : Promise.reject();
      Promise.resolve(p).catch(() => { root.classList.add("cls-expanded"); render(); });
    };
    document.addEventListener("fullscreenchange", render);

    root.addEventListener("click", e => {
      const a = e.target.closest("[data-a]")?.dataset.a;
      if (a === "play") toggle();
      else if (a === "back") skip(-10);
      else if (a === "fwd") skip(10);
      else if (a === "speed") setSpeed((speedIx + 1) % SPEEDS.length);
      else if (a === "full") toggleFull();
      else if (e.target.closest(".cls-player-stage")) toggle();
    });
    stage.addEventListener("dblclick", toggleFull);

    range.addEventListener("input", () => { scrubbing = true; eng.seek(range.value / 1000 * eng.duration()); });
    range.addEventListener("change", () => { scrubbing = false; render(); });
    range.addEventListener("pointermove", e => {
      const r = range.getBoundingClientRect(), f = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
      tip.hidden = false; tip.textContent = fmt(f * eng.duration()); tip.style.left = f * 100 + "%";
    });
    range.addEventListener("pointerleave", () => { tip.hidden = true; });

    root.addEventListener("keydown", e => {
      const k = e.key.toLowerCase(); let used = true;
      if (k === " " || k === "k") toggle();
      else if (k === "arrowleft") skip(e.shiftKey ? -10 : -5);
      else if (k === "arrowright") skip(e.shiftKey ? 10 : 5);
      else if (k === "j") skip(-10);
      else if (k === "l") skip(10);
      else if (k === "f") toggleFull();
      else if (k === ",") setSpeed(speedIx - 1);       // "<"
      else if (k === ".") setSpeed(speedIx + 1);       // ">"
      else if (k === "<") setSpeed(speedIx - 1);
      else if (k === ">") setSpeed(speedIx + 1);
      else if (k === "home") { eng.seek(0); render(); }
      else if (k === "end") { eng.seek(eng.duration()); render(); }
      else if (/^[0-9]$/.test(k)) { eng.seek(eng.duration() * (+k / 10)); render(); }
      else used = false;
      if (used) { e.preventDefault(); e.stopPropagation(); }
    });

    // Controls fade out while playing and the pointer is idle (like any video player).
    const wake = () => {
      root.classList.remove("cls-idle"); clearTimeout(idleTimer);
      idleTimer = setTimeout(() => { if (eng.playing()) root.classList.add("cls-idle"); }, 2500);
    };
    root.addEventListener("pointermove", wake); root.addEventListener("keydown", wake);

    setSpeed(1); render(); root.focus();
    return {
      destroy() {
        clearTimeout(idleTimer); document.removeEventListener("fullscreenchange", render);
        if (document.fullscreenElement === root) document.exitFullscreen();
        eng.destroy(); host.replaceChildren();
      },
    };
  };
})();
