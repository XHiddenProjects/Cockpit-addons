# Classroom Cockpit

A Cockpit page (admin host) plus a small agent (every student machine) for monitoring and
managing a computer lab. Install the admin side with `sudo ./install.sh`, then enrol each
student machine with the one-liner it prints. See `offline/README.md` for no-internet labs.

## Tabs

| Tab | What it does |
|---|---|
| **Workstations** | Live thumbnails; lock, message, open website, broadcast a screen, remote control, send/collect files, record, power, restrictions. |
| **Recordings** | Lists every screen recording. **Play** opens the built-in player (play/pause, scrub bar with hover time, ±10 s, 0.5×–8× speed, fullscreen; keys: Space/K, J/L, arrows, `<` `>`, F, 0–9). **Download** (MP4) and **Delete** (single or multi-select) are here too. Viewing and deleting are written to the audit log. |
| **Audit log** | Every action taken from the console (who, what, which machine), newest first, with filter, **Export CSV** and **Delete log**. Deleting the log is itself recorded as the first line of the new one. Text typed during remote control is never stored, only its length. |
| **Schedule** | Shut every classroom computer down / wake them at set times on chosen days, optionally warning students N minutes before shutdown. Runs in its own service (`classroom-scheduler`), so it works with nobody logged in to Cockpit. Times use the admin server's clock. |

## Remote control

Open **Remote control** with one workstation selected: left-click = click, double-click = double-click,
**right-click** = context menu on the student's machine, **mouse wheel / trackpad** = scroll (vertical and horizontal).
There is also a text box and an Enter button.

## What "Collect files" does

It is the hand-in half of a file exchange between instructor and students:

* **Send file** copies a file you pick into each selected workstation's **handout** folder.
* Students save their finished work into their machine's **handin** folder.
* **Collect files** pulls everything currently in each selected workstation's handin folder to the
  admin server, into `/srv/classroom/collected/<workstation IP>/` (one folder per machine).
  The page reports how many files came from how many machines.

| OS | Student-side folders (created by the agent, world-writable) |
|---|---|
| Linux | `/var/lib/classroom/share/{handout,handin}` |
| macOS | `/Users/Shared/Classroom/{handout,handin}` |
| Windows | `C:\ProgramData\Classroom\Share\{handout,handin}` |

It copies (never deletes) the student's files; a same-named file from the same machine is overwritten
on re-collect; sub-folders are not collected.

## Wake-on-LAN

* A machine's MAC is learned the first time it is discovered while on (the agent also reports it).
* **Wake** with nothing selected wakes every machine ever discovered, including ones that are off now.
* The agent enables magic-packet wake on the NIC at every start (Linux `ethtool`, Windows adapter power
  settings, macOS `pmset womp`), but Wake-on-LAN must also be enabled in each computer's **BIOS/UEFI**,
  and machines must be on wired Ethernet.

## Theme

The page follows the Cockpit shell's Appearance setting (Auto / Light / Dark) live, with no reload.
