"""Run: python3 -I tests/test_user_backend.py   (no Samba needed; tests the pure planning logic)"""
import importlib.util
import os
import sys

here = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("user_backend", os.path.join(here, "..", "user_backend.py"))
ub = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ub)

cur = {"givenName": "Al", "sn": "Smith", "userAccountControl": "512", "pwdLastSet": "133000000000000000", "accountExpires": "9223372036854775807"}

# unchanged values produce no changes
assert ub.plan_update(cur, {"given": "Al", "sn": "Smith"}, {}) == {}
# change, clear, and set a new attribute
assert ub.plan_update(cur, {"given": "Alice", "sn": "", "mail": "a@x.org"}, {}) == {"givenName": "Alice", "sn": None, "mail": "a@x.org"}
# disable / never-expires toggles keep other UAC bits
assert ub.plan_update(cur, {}, {"disabled": True}) == {"userAccountControl": "514"}
assert ub.plan_update(cur, {}, {"neverExpires": True}) == {"userAccountControl": str(512 | 0x10000)}
c2 = dict(cur, userAccountControl=str(514 | 0x10000))
assert ub.plan_update(c2, {}, {"disabled": False, "neverExpires": False}) == {"userAccountControl": "512"}
# must change at next logon
assert ub.plan_update(cur, {}, {"mustChange": True}) == {"pwdLastSet": "0"}
assert ub.plan_update(dict(cur, pwdLastSet="0"), {}, {"mustChange": False}) == {"pwdLastSet": "-1"}
assert ub.plan_update(cur, {}, {"mustChange": False}) == {}
# unlock
assert ub.plan_update(cur, {}, {"unlock": True}) == {"lockoutTime": "0"}
# expiry round trip
ft = ub.date_to_filetime("2030-01-31")
assert ub.filetime_to_date(ft) == "2030-02-01" or ub.filetime_to_date(ft - 10**7) == "2030-01-31"
assert ub.plan_update(cur, {}, {"expires": "2030-01-31"}) == {"accountExpires": str(ft)}
assert ub.plan_update(dict(cur, accountExpires=str(ft)), {}, {"expires": ""}) == {"accountExpires": "0"}
assert ub.plan_update(cur, {}, {"expires": ""}) == {}
# bad input
for bad in ({"nope": "x"}, {"given": "a\nb"}):
    try:
        ub.plan_update(cur, bad, {})
        raise SystemExit("expected ValueError for %r" % bad)
    except ValueError:
        pass
print("user_backend: all tests passed")
