#!/bin/bash
# Inventory agent uninstaller for macOS (launchd).
# Usage: curl -fsSL <server>/agent/uninstall-macos.sh | sudo bash
#    or: sudo bash uninstall-macos.sh [--install-dir <path>] [--delay <seconds>]
#
# --delay N  schedule the removal N seconds from now in a detached process and
#            return immediately, so the agent can still report a job result
#            before it is stopped and deleted.
set -euo pipefail

INSTALL_DIR="/usr/local/inventory-agent"
STATE_DIR="/Library/Application Support/inventory-agent"
PLIST="/Library/LaunchDaemons/com.inventory.agent.plist"
LABEL="com.inventory.agent"
DELAY="${INVENTORY_UNINSTALL_DELAY:-0}"

while [ $# -gt 0 ]; do
  case "$1" in
    --install-dir) INSTALL_DIR="$2"; shift 2 ;;
    --delay) DELAY="$2"; shift 2 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "This uninstaller must be run as root (sudo)." >&2
  exit 1
fi
case "$DELAY" in ''|*[!0-9]*) echo "--delay must be a whole number of seconds." >&2; exit 1 ;; esac
case "$INSTALL_DIR" in
  ''|/|/usr|/usr/local|/etc|/var|/Users|/Library|/System|/Applications) echo "Refusing to remove unsafe install dir: '$INSTALL_DIR'" >&2; exit 1 ;;
esac

# Unloading the launchd job is LAST: launchd kills the agent on unload.
HELPER="$(mktemp /private/var/tmp/inventory-agent-uninstall.XXXXXX)"
cat > "$HELPER" <<HELPER_EOF
#!/bin/bash
rm -f "$PLIST"
rm -rf "$INSTALL_DIR" "$STATE_DIR"
rm -f /var/log/inventory-agent.log /var/log/inventory-agent.err.log
launchctl bootout "system/$LABEL" >/dev/null 2>&1 || launchctl remove "$LABEL" >/dev/null 2>&1 || true
HELPER_EOF
chmod 700 "$HELPER"

if [ "$DELAY" -eq 0 ]; then
  echo "Removing inventory agent ..."
  /bin/bash "$HELPER"
  rm -f "$HELPER"
  echo "Inventory agent removed."
  exit 0
fi

# The job runs in its own session, so this outlives the agent being stopped.
nohup /bin/bash -c "sleep $DELAY; /bin/bash '$HELPER'; rm -f '$HELPER'" >/dev/null 2>&1 &
echo "Inventory agent removal scheduled in ${DELAY}s."
