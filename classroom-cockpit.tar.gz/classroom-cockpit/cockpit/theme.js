/*
 * Keeps this page's theme in lock-step with the Cockpit shell's own "Appearance" setting
 * (Auto / Light / Dark, top-right user menu -> Preferences).
 *
 * How Cockpit does it: the shell stores the choice in localStorage under "shell:style"
 * ("auto" | "light" | "dark") and, after resolving "auto" against the OS preference, puts a
 * `pf-v5-theme-dark` (PatternFly 5) / `pf-v6-theme-dark` class on <html> in the shell and in
 * every package iframe. This page is a package iframe on the same origin as the shell, so we:
 *
 *   1. read the shell's own <html> classes (the already-resolved truth) when reachable,
 *   2. otherwise resolve "shell:style" ourselves (auto -> OS prefers-color-scheme),
 *   3. re-apply live whenever the setting, the shell's class, or the OS preference changes,
 *      so flipping the toggle updates this page immediately without a reload.
 *
 * It is loaded synchronously in <head>, before any stylesheet paints, so there is no
 * flash of the wrong theme.
 */
(function () {
  var root = document.documentElement;
  var mq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
  var CLASSES = ["pf-v5-theme-dark", "pf-v6-theme-dark"];

  function stored() {
    try { return window.localStorage.getItem("shell:style") || "auto"; } catch (e) { return "auto"; }
  }

  function shellClassDark() {
    // null = can't tell (not embedded in the shell, or cross-origin)
    try {
      if (window.parent && window.parent !== window) {
        var pc = window.parent.document.documentElement.classList;
        return CLASSES.some(function (c) { return pc.contains(c); });
      }
    } catch (e) { /* cross-origin */ }
    return null;
  }

  function isDark() {
    var pref = stored();
    if (pref === "dark") return true;
    if (pref === "light") return false;
    var viaShell = shellClassDark();           // "auto": the shell has already resolved it
    if (viaShell !== null) return viaShell;
    return !!(mq && mq.matches);
  }

  function apply() {
    var dark = isDark();
    CLASSES.forEach(function (c) { root.classList.toggle(c, dark); });
    root.setAttribute("data-theme", dark ? "dark" : "light");
    root.style.colorScheme = dark ? "dark" : "light";
    window.dispatchEvent(new CustomEvent("cls-theme", { detail: { dark: dark } }));
  }

  apply();
  window.addEventListener("storage", function (e) { if (!e.key || e.key === "shell:style") apply(); });
  if (mq) (mq.addEventListener ? mq.addEventListener("change", apply) : mq.addListener(apply));
  try {
    if (window.parent && window.parent !== window && window.MutationObserver) {
      new MutationObserver(apply).observe(window.parent.document.documentElement,
                                          { attributes: true, attributeFilter: ["class"] });
    }
  } catch (e) { /* cross-origin: storage + media events still cover it */ }
  // Last-resort safety net: some Cockpit versions change the setting without a storage event
  // reaching sub-frames; a cheap poll keeps us correct regardless.
  setInterval(function () {
    if (root.classList.contains(CLASSES[0]) !== isDark()) apply();
  }, 2000);
})();
