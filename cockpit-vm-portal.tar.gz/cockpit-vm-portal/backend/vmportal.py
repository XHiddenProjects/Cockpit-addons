#!/usr/bin/env python3
"""vmportal - a VM manager plus a "give outsiders their own disposable copy of a VM" portal.

  * VM manager: create VMs from uploaded ISO / OVA / qcow2 / vmdk / vdi / vhd(x) / raw images (or
    manage the ones Cockpit already has): power, console, resources, media, snapshots, delete.
  * Templates: a stopped VM is copied once into a read-only golden image.
  * Invite links (optionally unlimited in time and launches) let a visitor launch a private,
    isolated, resource-limited, auto-expiring copy-on-write clone and use it from the browser.

Admin API (used by the Cockpit page):   vmportal call <command>   (JSON on stdin, JSON on stdout)
Long operations (copy, import, create) run as background jobs with progress in <state>/jobs/.
Other subcommands: serve | ws | status | upload-chunk | purge-vms | template-ls | invite-add |
invite-ls | session-ls | session-kill | _work
"""
import argparse
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import signal
import sqlite3
import ssl
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import xml.etree.ElementTree as ET
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import quote, urlparse

CONF_PATH = os.environ.get("VMPORTAL_CONF", "/etc/vm-portal/config.json")
DEFAULTS = {
    "state_dir": "/var/lib/vm-portal",
    "token_dir": "/run/vm-portal/tokens",
    "web_dir": "/usr/share/vm-portal/web",
    "novnc_dir": "/usr/share/novnc",
    "libvirt_uri": "qemu:///system",
    "network": "vmportal",
    "antispoof": True,
    "listen": "0.0.0.0",
    "port": 8480,
    "tls_cert": "",
    "tls_key": "",
    "ws_port": 6080,
    "ws_tls": False,
    "ws_cert": "",
    "ws_key": "",
    "public_host": "",
    "trust_proxy": False,
    "max_sessions": 8,
    "launches_per_hour_per_ip": 6,
    "max_extensions": 2,
}
# settings editable from the Cockpit GUI (the rest are internal paths)
CONF_FIELDS = {k: type(DEFAULTS[k]) for k in (
    "public_host", "listen", "port", "ws_port", "max_sessions", "launches_per_hour_per_ip",
    "max_extensions", "trust_proxy", "antispoof", "network", "tls_cert", "tls_key",
    "ws_tls", "ws_cert", "ws_key")}
CONF_RANGES = {"port": (1, 65535), "ws_port": (1, 65535), "max_sessions": (1, 500),
               "launches_per_hour_per_ip": (1, 10000), "max_extensions": (0, 50)}
C = dict(DEFAULTS)
NAME_RE = re.compile(r"^[A-Za-z0-9._-]{1,48}$")
HEX_RE = re.compile(r"^[0-9a-f]{8,32}$")
DISK_EXT = {".qcow2", ".qcow", ".vmdk", ".vdi", ".vhd", ".vhdx", ".raw", ".img"}
UPLOAD_EXT = DISK_EXT | {".iso", ".ova"}
LAUNCH_LOCK = threading.RLock()


class Err(Exception):
    def __init__(self, msg, code=400):
        super().__init__(msg)
        self.code = code


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def load_conf(required=False):
    try:
        with open(CONF_PATH) as f:
            C.update(json.load(f))
    except FileNotFoundError:
        pass
    except PermissionError:
        msg = (f"cannot read {CONF_PATH}: permission denied. The file must be world-readable "
               f"(chmod 644 {CONF_PATH}); it contains no secrets.")
        if required:
            log(msg)
            sys.exit(1)
        raise Err(msg, 500)
    except json.JSONDecodeError as e:
        msg = f"{CONF_PATH} is not valid JSON: {e}"
        if required:
            log(msg)
            sys.exit(1)
        raise Err(msg, 500)


def run(cmd, timeout=600, check=True, env=None, input=None):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env, input=input)
    except FileNotFoundError:
        raise Err(f"{cmd[0]} is not installed", 500)
    except subprocess.TimeoutExpired:
        raise Err(f"{cmd[0]} timed out", 500)
    if check and p.returncode:
        raise Err((p.stderr or p.stdout).strip() or f"{cmd[0]} failed", 500)
    return p.stdout


def virsh(*a, check=True, timeout=120):
    return run(["virsh", "-c", C["libvirt_uri"], *a], check=check, timeout=timeout)


def virsh_ok(*a):
    try:
        p = subprocess.run(["virsh", "-c", C["libvirt_uri"], *a], capture_output=True, text=True, timeout=60)
        return p.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


PROGRESS_RE = re.compile(r"\((\d+(?:\.\d+)?)/100%\)")


def run_progress(cmd, cb):
    """Run a qemu-img command with -p, calling cb(percent) as it advances."""
    err = tempfile.TemporaryFile()
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=err)
    except FileNotFoundError:
        raise Err(f"{cmd[0]} is not installed", 500)
    last, tail = -1.0, ""
    try:
        while True:
            chunk = os.read(p.stdout.fileno(), 4096)
            if not chunk:
                break
            tail = (tail + chunk.decode("latin-1"))[-200:]
            m = PROGRESS_RE.findall(tail)
            if m and float(m[-1]) - last >= 0.5:
                last = float(m[-1])
                cb(last)
        rc = p.wait()
    except BaseException:
        p.kill()
        p.wait()
        raise
    if rc:
        err.seek(0)
        raise Err(err.read().decode(errors="replace").strip() or f"{cmd[0]} failed", 500)
    cb(100.0)


def free_bytes(path="/var/lib"):
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    return shutil.disk_usage(p).free


def safe_name(s):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s)[:60].strip("._") or "file"


# ----------------------------------------------------------------------------- database
SCHEMA = """
CREATE TABLE IF NOT EXISTS templates(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE, source_domain TEXT, golden TEXT, golden_fmt TEXT,
  owns_golden INT, xml TEXT, vcpus INT, memory_mb INT, ttl_minutes INT, max_disk_gb INT,
  iops INT, sysprep INT DEFAULT 0, created INT);
CREATE TABLE IF NOT EXISTS invites(
  token TEXT PRIMARY KEY, template_id INT, label TEXT, expires INT, max_uses INT,
  uses INT DEFAULT 0, pw_hash TEXT, revoked INT DEFAULT 0, created INT);
CREATE TABLE IF NOT EXISTS sessions(
  id TEXT PRIMARY KEY, secret_hash TEXT UNIQUE, invite TEXT, template_id INT, domain TEXT,
  overlay TEXT, nvram TEXT, console_token TEXT, vnc_pw TEXT, vnc_port INT, created INT,
  expires INT, state TEXT, ip TEXT, extensions INT DEFAULT 0, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS library(
  id INTEGER PRIMARY KEY, name TEXT, kind TEXT, path TEXT, size INT, created INT, hint TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS managed(name TEXT PRIMARY KEY);
"""
MIGRATIONS = {"sessions": [("progress", "INT DEFAULT 0"), ("step", "TEXT DEFAULT ''")]}


@contextmanager
def conn():
    Path(C["state_dir"]).mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(Path(C["state_dir"]) / "portal.db"), timeout=30)
    c.row_factory = sqlite3.Row
    c.executescript(SCHEMA)
    for table, cols in MIGRATIONS.items():
        have = {r["name"] for r in c.execute(f"PRAGMA table_info({table})")}
        for col, decl in cols:
            if col not in have:
                c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {decl}")
    try:
        yield c
        c.commit()
    finally:
        c.close()


def rows(c, sql, *a):
    return [dict(r) for r in c.execute(sql, a).fetchall()]


def one(c, sql, *a):
    r = c.execute(sql, a).fetchone()
    return dict(r) if r else None


def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()


def pw_hash(password):
    salt = secrets.token_bytes(16)
    h = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 200_000)
    return salt.hex() + "$" + h.hex()


def pw_check(password, stored):
    salt, h = stored.split("$")
    cand = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 200_000)
    return hmac.compare_digest(cand.hex(), h)


def sdir(*parts, mode=0o755):
    d = Path(C["state_dir"], *parts)
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, mode)
    return d


def pool_dir():
    return sdir("clones")


# ----------------------------------------------------------------------------- settings (GUI)
def config_get():
    return {k: C[k] for k in CONF_FIELDS}


def config_set(settings):
    cur = config_get()
    for k, v in (settings or {}).items():
        if k not in CONF_FIELDS:
            raise Err(f"unknown setting '{k}'")
        t = CONF_FIELDS[k]
        if t is bool:
            if not isinstance(v, bool):
                raise Err(f"{k} must be true or false")
        elif t is int:
            try:
                v = int(v)
            except (TypeError, ValueError):
                raise Err(f"{k} must be a number")
            lo, hi = CONF_RANGES[k]
            if not lo <= v <= hi:
                raise Err(f"{k} must be between {lo} and {hi}")
        else:
            v = str(v).strip()
        cur[k] = v
    if not re.fullmatch(r"[A-Za-z0-9.\-:\[\]]{0,253}", cur["public_host"]):
        raise Err("Public host name looks invalid (use a host name or IP, no scheme or path)")
    if not re.fullmatch(r"[0-9A-Fa-f:.]{2,45}", cur["listen"]):
        raise Err("Listen address must be an IP address such as 0.0.0.0 or 127.0.0.1")
    if not NAME_RE.match(cur["network"]):
        raise Err("Network name may only contain letters, digits, . _ -")
    if cur["port"] == cur["ws_port"]:
        raise Err("Portal port and console port must differ")
    for cert, key, what in (("tls_cert", "tls_key", "portal"), ("ws_cert", "ws_key", "console")):
        if bool(cur[cert]) != bool(cur[key]) and (what == "portal" or cur[key]):
            raise Err(f"Set both the {what} certificate and key (or neither)")
        for k in (cert, key):
            if cur[k] and not os.path.isfile(cur[k]):
                raise Err(f"File not found: {cur[k]}")
    if cur["ws_tls"] and not cur["ws_cert"]:
        raise Err("Console TLS needs a certificate file")
    if cur["network"] != C["network"] and not virsh_ok("net-info", cur["network"]):
        raise Err(f"libvirt network '{cur['network']}' does not exist")
    try:
        raw = json.loads(Path(CONF_PATH).read_text())
    except (OSError, json.JSONDecodeError):
        raw = {}
    raw.update(cur)
    Path(CONF_PATH).parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(Path(CONF_PATH).parent))
    with os.fdopen(fd, "w") as f:
        json.dump(raw, f, indent=4)
        f.write("\n")
    os.chmod(tmp, 0o644)          # read by the unprivileged console proxy; holds no secrets
    os.replace(tmp, CONF_PATH)
    C.update(cur)
    return {"ok": True, "config": cur}


# ----------------------------------------------------------------------------- jobs (progress)
def jobs_dir():
    return sdir("jobs")


def job_read(jid):
    try:
        return json.loads((jobs_dir() / f"{jid}.json").read_text())
    except (OSError, json.JSONDecodeError):
        return None


def job_write(j):
    p = jobs_dir() / f"{j['id']}.json"
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(j))
    os.replace(tmp, p)


def job_update(jid, **kw):
    j = job_read(jid)
    if j:
        j.update(kw, updated=int(time.time()))
        job_write(j)


def job_start(kind, title, params):
    j = {"id": secrets.token_hex(4), "kind": kind, "title": title, "status": "queued", "progress": 0,
         "step": "Starting…", "error": "", "created": int(time.time()), "updated": int(time.time()),
         "params": params, "result": None, "pid": 0}
    job_write(j)
    logf = open(jobs_dir() / f"{j['id']}.log", "ab")
    subprocess.Popen([sys.executable, os.path.realpath(sys.argv[0]), "_work", j["id"]],
                     start_new_session=True, stdin=subprocess.DEVNULL, stdout=logf, stderr=logf,
                     env=dict(os.environ, VMPORTAL_CONF=CONF_PATH))
    return {"job": j["id"]}


def job_list():
    out, now = [], time.time()
    for p in sorted(jobs_dir().glob("*.json")):
        j = job_read(p.stem)
        if not j:
            continue
        age = now - j["updated"]
        if (j["status"] in ("done", "cancelled") and age > 3600) or age > 86400:
            for ext in ("json", "log"):
                p.with_suffix("." + ext).unlink(missing_ok=True)
            continue
        if j["status"] in ("queued", "running") and now - j["updated"] > 20 and j.get("pid"):
            try:
                os.kill(j["pid"], 0)
            except ProcessLookupError:
                j.update(status="error", error="The worker process stopped unexpectedly.")
                job_write(j)
        j.pop("params", None)
        out.append(j)
    return sorted(out, key=lambda j: j["created"])


def job_cancel(id):
    j = job_read(id)
    if not j:
        raise Err("no such job", 404)
    if j["status"] in ("queued", "running") and j.get("pid"):
        try:
            os.killpg(j["pid"], signal.SIGTERM)
        except ProcessLookupError:
            job_update(id, status="cancelled", step="Cancelled")
    return {"ok": True}


def job_dismiss(id):
    j = job_read(id)
    if j and j["status"] not in ("queued", "running"):
        for ext in ("json", "log"):
            (jobs_dir() / f"{id}.{ext}").unlink(missing_ok=True)
    return {"ok": True}


def work(jid):
    j = job_read(jid)
    if not j:
        return
    job_update(jid, status="running", pid=os.getpid())

    def on_term(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, on_term)
    fn = {"template": w_template, "import": w_import, "vmcreate": w_vmcreate}[j["kind"]]

    def prog(pct=None, step=None):
        kw = {}
        if pct is not None:
            kw["progress"] = round(pct, 1)
        if step is not None:
            kw["step"] = step
        job_update(jid, **kw)
    try:
        res = fn(j["params"], prog)
        job_update(jid, status="done", progress=100, step="Done", result=res)
    except KeyboardInterrupt:
        job_update(jid, status="cancelled", step="Cancelled")
    except Err as e:
        job_update(jid, status="error", error=str(e))
    except Exception as e:
        log("job failed:", repr(e))
        job_update(jid, status="error", error=f"Unexpected error: {e}")


# ----------------------------------------------------------------------------- libvirt helpers
def vm_state(dom):
    p = subprocess.run(["virsh", "-c", C["libvirt_uri"], "domstate", dom], capture_output=True, text=True)
    return p.stdout.strip() if p.returncode == 0 else None


def dom_names():
    return [n.strip() for n in virsh("list", "--all", "--name").split("\n") if n.strip()]


def user_domains():
    return [n for n in dom_names() if not n.startswith("vmp-")]


def dom_root(name, inactive=False, secure=False):
    args = ["dumpxml"] + (["--inactive"] if inactive else []) + (["--security-info"] if secure else [])
    return ET.fromstring(virsh(*args, name))


def define_xml(xml):
    tmpd = sdir("tmp")
    p = tmpd / f"def-{secrets.token_hex(4)}.xml"
    p.write_text(xml)
    try:
        virsh("define", str(p))
    finally:
        p.unlink(missing_ok=True)


def disk_paths(root):
    out = []
    for d in root.findall("./devices/disk"):
        src = d.find("source")
        if src is not None and src.get("file"):
            out.append((d.get("device"), src.get("file")))
    return out


def primary_disk(root):
    for d in root.findall("./devices/disk"):
        if d.get("device") == "disk":
            src, drv = d.find("source"), d.find("driver")
            if src is not None and src.get("file"):
                return src.get("file"), (drv.get("type") if drv is not None else "raw")
    raise Err("The VM has no file-backed disk (block devices / network disks are not supported)")


def all_disk_use(skip=None):
    """{path: domain name} for every file used by a libvirt domain (other than `skip`)."""
    use = {}
    for n in dom_names():
        if n == skip:
            continue
        try:
            for _, p in disk_paths(dom_root(n, inactive=True)):
                use[p] = n
        except Err:
            pass
    return use


def qimg_info(path):
    try:
        return json.loads(run(["qemu-img", "info", "--output=json", "-U", path], timeout=60))
    except json.JSONDecodeError:
        raise Err("qemu-img could not read this image")


def kvm_ok():
    return os.path.exists("/dev/kvm")


# ----------------------------------------------------------------------------- guest XML for portal clones
def build_xml(tpl, name, overlay, vnc_pw, nvram_copy=None):
    """Turn the template domain XML into a safe, isolated, resource-limited clone."""
    root = ET.fromstring(tpl["xml"])
    for tag in ("uuid", "genid", "seclabel", "metadata", "maxMemory", "cputune",
                "blkiotune", "memoryBacking"):
        for e in root.findall(tag):
            root.remove(e)
    root.find("name").text = name
    for tag in ("memory", "currentMemory"):
        e = root.find(tag)
        if e is None:
            e = ET.SubElement(root, tag)
        e.attrib.clear()
        e.set("unit", "KiB")
        e.text = str(int(tpl["memory_mb"]) * 1024)
    v = root.find("vcpu")
    if v is None:
        v = ET.SubElement(root, "vcpu")
    v.attrib.clear()
    v.text = str(int(tpl["vcpus"]))
    cpu = root.find("cpu")
    if cpu is not None:
        for tag in ("topology", "numa"):
            for e in cpu.findall(tag):
                cpu.remove(e)
    ct = ET.SubElement(root, "cputune")
    ET.SubElement(ct, "shares").text = "512"
    for tag, val in (("on_poweroff", "destroy"), ("on_reboot", "restart"), ("on_crash", "destroy")):
        e = root.find(tag)
        if e is None:
            e = ET.SubElement(root, tag)
        e.text = val
    nv = root.find("os/nvram")
    if nv is not None and nvram_copy:
        nv.text = str(nvram_copy)
    dev = root.find("devices")
    if dev is None:
        raise Err("template XML has no <devices>")
    primary = None
    for d in dev.findall("disk"):
        src = d.find("source")
        if primary is None and d.get("device") == "disk" and src is not None and src.get("file"):
            primary = d
        else:
            dev.remove(d)
    if primary is None:
        raise Err("template has no usable disk")
    src = primary.find("source")
    src.attrib.clear()
    src.set("file", str(overlay))
    drv = primary.find("driver")
    if drv is None:
        drv = ET.SubElement(primary, "driver", name="qemu")
    drv.set("type", "qcow2")
    for tag in ("backingStore", "iotune", "readonly", "shareable"):
        for e in primary.findall(tag):
            primary.remove(e)
    io = ET.SubElement(primary, "iotune")
    ET.SubElement(io, "total_iops_sec").text = str(int(tpl["iops"]))
    model = "virtio"
    old = dev.find("interface")
    if old is not None and old.find("model") is not None:
        model = old.find("model").get("type", "virtio")
    for tag in ("interface", "graphics", "hostdev", "filesystem", "redirdev",
                "smartcard", "audio", "sound", "channel", "tpm"):
        for e in dev.findall(tag):
            dev.remove(e)
    nic = ET.SubElement(dev, "interface", type="network")
    ET.SubElement(nic, "source", network=C["network"])
    ET.SubElement(nic, "model", type=model)
    ET.SubElement(nic, "port", isolated="yes")
    if C["antispoof"]:
        ET.SubElement(nic, "filterref", filter="clean-traffic")
    g = ET.SubElement(dev, "graphics", type="vnc", port="-1", autoport="yes",
                      listen="127.0.0.1", passwd=vnc_pw)
    ET.SubElement(g, "listen", type="address", address="127.0.0.1")
    return ET.tostring(root, encoding="unicode")


def vnc_port(dom):
    root = dom_root(dom)
    g = root.find("devices/graphics[@type='vnc']")
    port = int(g.get("port", "-1")) if g is not None else -1
    if port < 0:
        raise Err("VM has no active VNC port (is it running?)", 409)
    return port


def write_token(token, port, host="127.0.0.1"):
    d = Path(C["token_dir"])
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o755)
    p = d / token
    p.write_text(f"{token}: {host}:{port}\n")
    os.chmod(p, 0o644)


def overlay_bytes(path):
    try:
        return os.stat(path).st_blocks * 512
    except OSError:
        return 0


def tree_bytes(path):
    total = 0
    for dp, _, files in os.walk(path):
        for f in files:
            try:
                total += os.lstat(os.path.join(dp, f)).st_blocks * 512
            except OSError:
                pass
    return total


# ----------------------------------------------------------------------------- VM manager
def vm_list():
    names = user_domains()
    auto = set(n.strip() for n in virsh("list", "--all", "--autostart", "--name", check=False).split("\n"))
    with conn() as c:
        managed = {r["name"] for r in c.execute("SELECT name FROM managed")}
        tpls = rows(c, "SELECT name,source_domain FROM templates")
    out = []
    for n in names:
        try:
            r = dom_root(n)
        except Err:
            continue
        mem = r.find("memory")
        kib = int(mem.text) * {"KiB": 1, "MiB": 1024, "GiB": 1048576, "B": 1 / 1024}.get(mem.get("unit", "KiB"), 1) if mem is not None else 0
        g = r.find("devices/graphics")
        disks, iso = [], ""
        for d in r.findall("devices/disk"):
            src = d.find("source")
            path = (src.get("file") or src.get("dev") or src.get("name") or "") if src is not None else ""
            if d.get("device") == "cdrom":
                iso = path
            elif d.get("device") == "disk":
                disks.append({"path": path, "mb": overlay_bytes(path) // 1048576 if path.startswith("/") else 0})
        vc = r.find("vcpu")
        out.append({
            "name": n, "state": vm_state(n) or "unknown",
            "vcpus": int(vc.text) if vc is not None else 1, "memory_mb": int(kib // 1024),
            "autostart": n in auto, "disks": disks, "iso": iso,
            "graphics": g.get("type") if g is not None else "",
            "networks": [i.find("source").get("network") or i.find("source").get("bridge") or ""
                         for i in r.findall("devices/interface") if i.find("source") is not None],
            "managed": n in managed,
            "uefi": r.find("os").get("firmware") == "efi" or r.find("os/loader") is not None,
            "templates": [t["name"] for t in tpls if t["source_domain"] == n]})
    return out


def need_vm(name):
    if not isinstance(name, str) or name.startswith("vmp-") or vm_state(name) is None:
        raise Err(f"VM '{name}' not found", 404)


def vm_action(name, action):
    need_vm(name)
    cmds = {"start": ["start"], "shutdown": ["shutdown"], "reboot": ["reboot"], "poweroff": ["destroy"],
            "pause": ["suspend"], "resume": ["resume"],
            "autostart-on": ["autostart"], "autostart-off": ["autostart", "--disable"]}
    if action not in cmds:
        raise Err("unknown action")
    virsh(cmds[action][0], name, *cmds[action][1:])
    return {"ok": True}


def removable(path, other_use):
    rp = os.path.realpath(path)
    allowed = rp.startswith(os.path.realpath(C["state_dir"]) + "/") or rp.startswith("/var/lib/libvirt/images/")
    return allowed and path not in other_use


def vm_delete(name, storage=False):
    need_vm(name)
    root = dom_root(name, inactive=True)
    paths = [p for dev, p in disk_paths(root) if dev == "disk"]
    other = all_disk_use(skip=name)
    with conn() as c:
        golden = {r["golden"] for r in c.execute("SELECT golden FROM templates")}
    virsh("destroy", name, check=False)
    if not virsh_ok("undefine", name, "--nvram", "--managed-save", "--snapshots-metadata"):
        virsh("undefine", name)
    removed, kept = [], []
    for p in paths:
        if storage and removable(p, other) and p not in golden:
            try:
                os.unlink(p)
                removed.append(p)
                continue
            except OSError:
                pass
        kept.append(p)
    with conn() as c:
        c.execute("DELETE FROM managed WHERE name=?", (name,))
    return {"ok": True, "removed": removed, "kept": kept}


def vm_console(name):
    need_vm(name)
    root = dom_root(name, secure=True)
    g = root.find("devices/graphics[@type='vnc']")
    if g is None:
        raise Err("This VM has no VNC display (it may use SPICE). Use Cockpit's own console for it.")
    port = int(g.get("port", "-1"))
    if port < 0:
        raise Err("The VM is not running.", 409)
    addr = g.get("listen") or "127.0.0.1"
    host = "127.0.0.1" if addr in ("0.0.0.0", "::", "") else addr
    token = "adm-" + secrets.token_hex(12)
    write_token(token, port, host)
    return {"token": token, "password": g.get("passwd", ""), "ws_port": C["ws_port"], "ws_tls": C["ws_tls"],
            "public_host": C["public_host"]}


def vm_set(name, vcpus=None, memory_mb=None):
    need_vm(name)
    root = dom_root(name, inactive=True, secure=True)
    if vcpus:
        vcpus = int(vcpus)
        if not 1 <= vcpus <= 128:
            raise Err("vCPUs must be between 1 and 128")
        v = root.find("vcpu")
        v.attrib.clear()
        v.text = str(vcpus)
        cpu = root.find("cpu")
        if cpu is not None:
            for e in cpu.findall("topology"):
                cpu.remove(e)
    if memory_mb:
        memory_mb = int(memory_mb)
        if memory_mb < 64:
            raise Err("RAM must be at least 64 MB")
        for tag in ("memory", "currentMemory"):
            e = root.find(tag)
            e.attrib.clear()
            e.set("unit", "KiB")
            e.text = str(memory_mb * 1024)
    define_xml(ET.tostring(root, encoding="unicode"))
    return {"ok": True, "note": "Changes apply the next time the VM is started."}


def lib_get(lid):
    with conn() as c:
        r = one(c, "SELECT * FROM library WHERE id=?", int(lid))
    if not r:
        raise Err("image not found in the library", 404)
    return r


def vm_media(name, library_id=None):
    need_vm(name)
    root = dom_root(name, inactive=True, secure=True)
    dev = root.find("devices")
    cd = next((d for d in dev.findall("disk") if d.get("device") == "cdrom"), None)
    if library_id:
        item = lib_get(library_id)
        if item["kind"] != "iso":
            raise Err("That image is not an ISO")
        if cd is None:
            cd = ET.SubElement(dev, "disk", type="file", device="cdrom")
            ET.SubElement(cd, "driver", name="qemu", type="raw")
            ET.SubElement(cd, "target", dev="sdc", bus="sata")
            ET.SubElement(cd, "readonly")
        for s in cd.findall("source"):
            cd.remove(s)
        src = ET.Element("source", file=item["path"])
        cd.insert(1 if cd.find("driver") is not None else 0, src)
        for d in dev.findall("disk"):
            for b in d.findall("boot"):
                d.remove(b)
        for b in root.findall("os/boot"):
            root.find("os").remove(b)
        ET.SubElement(cd, "boot", order="1")
        first = next((d for d in dev.findall("disk") if d.get("device") == "disk"), None)
        if first is not None:
            ET.SubElement(first, "boot", order="2")
    elif cd is not None:
        for s in cd.findall("source"):
            cd.remove(s)
        for b in cd.findall("boot"):
            cd.remove(b)
    define_xml(ET.tostring(root, encoding="unicode"))
    return {"ok": True, "note": "Takes effect the next time the VM is started."}


def vm_snap(name, action, snap=None):
    need_vm(name)
    if action == "list":
        return [n.strip() for n in virsh("snapshot-list", name, "--name").split("\n") if n.strip()]
    if not snap or not NAME_RE.match(snap):
        raise Err("snapshot name may only contain letters, digits, . _ -")
    if action == "create":
        virsh("snapshot-create-as", name, snap, timeout=900)
    elif action == "revert":
        virsh("snapshot-revert", name, snap, timeout=900)
    elif action == "delete":
        virsh("snapshot-delete", name, snap)
    else:
        raise Err("unknown action")
    return {"ok": True}


def net_list():
    return [n.strip() for n in virsh("net-list", "--all", "--name", check=False).split("\n") if n.strip()]


def build_vm_xml(p, disk_path, iso_path):
    name = p["name"]
    kvm = kvm_ok()
    dom = ET.Element("domain", type="kvm" if kvm else "qemu")
    ET.SubElement(dom, "name").text = name
    ET.SubElement(dom, "memory", unit="MiB").text = str(p["memory_mb"])
    ET.SubElement(dom, "currentMemory", unit="MiB").text = str(p["memory_mb"])
    ET.SubElement(dom, "vcpu").text = str(p["vcpus"])
    os_ = ET.SubElement(dom, "os", **({"firmware": "efi"} if p["uefi"] else {}))
    ET.SubElement(os_, "type", arch="x86_64", machine="q35").text = "hvm"
    ft = ET.SubElement(dom, "features")
    for f in ("acpi", "apic"):
        ET.SubElement(ft, f)
    if kvm:
        ET.SubElement(dom, "cpu", mode="host-passthrough")
    ET.SubElement(dom, "clock", offset="localtime" if p["os_type"] == "windows" else "utc")
    for tag, val in (("on_poweroff", "destroy"), ("on_reboot", "restart"), ("on_crash", "destroy")):
        ET.SubElement(dom, tag).text = val
    dev = ET.SubElement(dom, "devices")
    d = ET.SubElement(dev, "disk", type="file", device="disk")
    ET.SubElement(d, "driver", name="qemu", type="qcow2", discard="unmap")
    ET.SubElement(d, "source", file=str(disk_path))
    ET.SubElement(d, "target", dev="vda" if p["disk_bus"] == "virtio" else "sda", bus=p["disk_bus"])
    if iso_path:
        ET.SubElement(d, "boot", order="2")
        cd = ET.SubElement(dev, "disk", type="file", device="cdrom")
        ET.SubElement(cd, "driver", name="qemu", type="raw")
        ET.SubElement(cd, "source", file=str(iso_path))
        ET.SubElement(cd, "target", dev="sdc", bus="sata")
        ET.SubElement(cd, "readonly")
        ET.SubElement(cd, "boot", order="1")
    nic = ET.SubElement(dev, "interface", type="network")
    ET.SubElement(nic, "source", network=p["network"])
    ET.SubElement(nic, "model", type=p["nic_model"])
    g = ET.SubElement(dev, "graphics", type="vnc", port="-1", autoport="yes", listen="127.0.0.1",
                      passwd=secrets.token_hex(4))
    ET.SubElement(g, "listen", type="address", address="127.0.0.1")
    v = ET.SubElement(dev, "video")
    ET.SubElement(v, "model", type="vga", vram="16384")
    ET.SubElement(dev, "input", type="tablet", bus="usb")
    ET.SubElement(dev, "memballoon", model="virtio")
    return ET.tostring(dom, encoding="unicode")


def vm_create(**p):
    """Validate, then run the (possibly long) creation as a background job."""
    name = str(p.get("name", ""))
    if not NAME_RE.match(name) or name.startswith("vmp-"):
        raise Err("VM name may only contain letters, digits, . _ - (max 48) and must not start with 'vmp-'")
    if vm_state(name) is not None:
        raise Err(f"A VM named '{name}' already exists")
    clean = {"name": name,
             "vcpus": int(p.get("vcpus") or 2), "memory_mb": int(p.get("memory_mb") or 2048),
             "network": str(p.get("network") or C["network"]),
             "disk_bus": p.get("disk_bus") if p.get("disk_bus") in ("virtio", "sata") else "virtio",
             "nic_model": p.get("nic_model") if p.get("nic_model") in ("virtio", "e1000e") else "virtio",
             "uefi": bool(p.get("uefi")), "os_type": "windows" if p.get("os_type") == "windows" else "linux",
             "start": bool(p.get("start")), "autostart": bool(p.get("autostart")),
             "iso_id": int(p["iso_id"]) if p.get("iso_id") else None,
             "disk_id": int(p["disk_id"]) if p.get("disk_id") else None,
             "disk_gb": int(p.get("disk_gb") or 0)}
    if not 1 <= clean["vcpus"] <= 128 or clean["memory_mb"] < 64:
        raise Err("Invalid CPU or memory value")
    if not clean["disk_id"] and clean["disk_gb"] < 1:
        raise Err("Choose a disk image or a size for a new blank disk")
    if clean["iso_id"] and lib_get(clean["iso_id"])["kind"] != "iso":
        raise Err("The installation source must be an ISO")
    need = lib_get(clean["disk_id"])["size"] if clean["disk_id"] else 0
    if free_bytes(C["state_dir"]) < need + (1 << 28):
        raise Err("Not enough free disk space for this VM")
    return job_start("vmcreate", f"Create VM {name}", clean)


def w_vmcreate(p, prog):
    name = p["name"]
    vmdir = sdir("vms")
    disk = vmdir / f"{name}.qcow2"
    if disk.exists():
        raise Err(f"{disk} already exists")
    ok = False
    try:
        if p["disk_id"]:
            src = lib_get(p["disk_id"])
            prog(0, "Copying disk image")
            run_progress(["qemu-img", "convert", "-p", "-O", "qcow2", src["path"], str(disk)],
                         lambda x: prog(x * 0.95))
        else:
            prog(10, "Creating blank disk")
            run(["qemu-img", "create", "-q", "-f", "qcow2", str(disk), f"{p['disk_gb']}G"])
        os.chmod(disk, 0o644)
        prog(96, "Defining the virtual machine")
        iso = lib_get(p["iso_id"])["path"] if p["iso_id"] else None
        define_xml(build_vm_xml(p, disk, iso))
        with conn() as c:
            c.execute("INSERT OR REPLACE INTO managed(name) VALUES(?)", (name,))
        if p["autostart"]:
            virsh("autostart", name)
        if p["start"]:
            prog(99, "Starting")
            virsh("start", name)
        ok = True
        return {"name": name}
    finally:
        if not ok:
            if vm_state(name) is not None:
                virsh("undefine", name, "--nvram", check=False)
            disk.unlink(missing_ok=True)


# ----------------------------------------------------------------------------- uploads + image library
def lib_list():
    with conn() as c:
        res = rows(c, "SELECT * FROM library ORDER BY created DESC")
    use = all_disk_use() if res else {}
    for r in res:
        r["in_use_by"] = use.get(r["path"], "")
        r["hint"] = json.loads(r["hint"] or "{}")
    return res


def lib_rm(id):
    item = lib_get(id)
    users = all_disk_use()
    if item["path"] in users:
        raise Err(f"This image is attached to VM '{users[item['path']]}'. Eject or delete that VM first.")
    with conn() as c:
        c.execute("DELETE FROM library WHERE id=?", (item["id"],))
    Path(item["path"]).unlink(missing_ok=True)
    return {"ok": True}


def up_paths(uid):
    if not HEX_RE.match(str(uid)):
        raise Err("bad upload id")
    d = sdir("uploads", mode=0o700)
    return d / f"{uid}.part", d / f"{uid}.json"


def upload_begin(filename, size):
    ext = Path(str(filename)).suffix.lower()
    if ext not in UPLOAD_EXT:
        raise Err("Unsupported file type. Use ISO, OVA, QCOW2, VMDK, VDI, VHD, VHDX, IMG or RAW.")
    size = int(size)
    if size <= 0:
        raise Err("The file is empty")
    if free_bytes(C["state_dir"]) < size * 2 + (1 << 28):
        raise Err("Not enough free disk space (an upload needs about twice its size while importing)")
    uid = secrets.token_hex(6)
    part, meta = up_paths(uid)
    part.touch(mode=0o600)
    meta.write_text(json.dumps({"name": safe_name(Path(filename).name), "size": size, "created": int(time.time())}))
    return {"id": uid}


def upload_status(id):
    part, meta = up_paths(id)
    if not part.exists():
        raise Err("upload not found", 404)
    return {"size": part.stat().st_size}


def upload_chunk(uid, offset):
    part, _ = up_paths(uid)
    if not part.exists():
        raise Err("upload not found", 404)
    have = part.stat().st_size
    if have != offset:
        raise Err(f"offset mismatch: server has {have} bytes", 409)
    with open(part, "ab") as f:
        while True:
            b = sys.stdin.buffer.read(1 << 20)
            if not b:
                break
            f.write(b)
    return {"size": part.stat().st_size}


def upload_abort(id):
    for p in up_paths(id):
        p.unlink(missing_ok=True)
    return {"ok": True}


def upload_finish(id):
    part, meta = up_paths(id)
    m = json.loads(meta.read_text())
    if part.stat().st_size != m["size"]:
        raise Err(f"Upload incomplete ({part.stat().st_size} of {m['size']} bytes)", 409)
    return job_start("import", f"Import {m['name']}", {"upload": id, "name": m["name"]})


def parse_ovf(text):
    hint = {}
    try:
        root = ET.fromstring(text)
    except ET.ParseError:
        return hint
    for it in root.iter():
        if it.tag.split("}")[-1] != "Item":
            continue
        f = {c.tag.split("}")[-1]: (c.text or "").strip() for c in it}
        try:
            if f.get("ResourceType") == "3":
                hint["vcpus"] = int(f["VirtualQuantity"])
            elif f.get("ResourceType") == "4":
                q, unit = int(f["VirtualQuantity"]), f.get("AllocationUnits", "")
                hint["memory_mb"] = q * 1024 if "2^30" in unit else (q // 1024 if "2^10" in unit else q)
        except (KeyError, ValueError):
            pass
    return hint


def w_import(p, prog):
    part, meta = up_paths(p["upload"])
    name = p["name"]
    ext = Path(name).suffix.lower()
    base = f"{secrets.token_hex(4)}_{safe_name(Path(name).stem)}"
    libdir = sdir("library")
    work_files = [part]
    hint = {}
    out = None
    try:
        if ext == ".iso":
            prog(50, "Moving ISO into the library")
            out = libdir / f"{base}.iso"
            os.replace(part, out)
            os.chmod(out, 0o644)
            kind = "iso"
        else:
            src = part
            if ext == ".ova":
                prog(0, "Unpacking OVA")
                with tarfile.open(part) as tf:
                    members = [m for m in tf.getmembers() if m.isfile()]
                    ovf = next((m for m in members if m.name.lower().endswith(".ovf")), None)
                    if ovf:
                        hint = parse_ovf(tf.extractfile(ovf).read(2_000_000).decode("utf-8", "replace"))
                    disk_m = [m for m in members if Path(m.name).suffix.lower() in DISK_EXT]
                    if not disk_m:
                        raise Err("This OVA does not contain a disk image")
                    src = sdir("uploads", mode=0o700) / f"{p['upload']}.disk"
                    work_files.append(src)
                    done = 0
                    with tf.extractfile(disk_m[0]) as fi, open(src, "wb") as fo:
                        while True:
                            b = fi.read(1 << 22)
                            if not b:
                                break
                            fo.write(b)
                            done += len(b)
                            prog(done / max(1, disk_m[0].size) * 25)
            info = qimg_info(str(src))
            if info.get("backing-filename"):
                raise Err("Images with a backing file are not accepted. Flatten it first (qemu-img convert).")
            if info.get("format") == "vmdk" and os.path.getsize(src) < (1 << 20):
                raise Err("This looks like a VMDK descriptor file. Upload the full disk image instead.")
            out = libdir / f"{base}.qcow2"
            lo = 25 if ext == ".ova" else 0
            prog(lo, "Converting to qcow2")
            run_progress(["qemu-img", "convert", "-p", "-f", info["format"], "-O", "qcow2", str(src), str(out)],
                         lambda x: prog(lo + x * (100 - lo) / 100))
            os.chmod(out, 0o644)
            kind = "disk"
            hint["virtual_gb"] = round(info.get("virtual-size", 0) / 1024 ** 3, 1)
        with conn() as c:
            cur = c.execute("INSERT INTO library(name,kind,path,size,created,hint) VALUES(?,?,?,?,?,?)",
                            (Path(name).stem, kind, str(out), os.path.getsize(out), int(time.time()), json.dumps(hint)))
            lid = cur.lastrowid
        out = None
        return {"library_id": lid, "kind": kind, "hint": hint}
    finally:
        for f in work_files:
            Path(f).unlink(missing_ok=True)
        meta.unlink(missing_ok=True)
        if out:
            Path(out).unlink(missing_ok=True)


# ----------------------------------------------------------------------------- templates
def template_add(name, domain, vcpus=2, memory_mb=2048, ttl_minutes=120, max_disk_gb=20, iops=500,
                 sysprep=False, no_copy=False):
    if not NAME_RE.match(str(name)):
        raise Err("template name may only contain letters, digits, . _ - (max 48)")
    state = vm_state(domain)
    if state is None:
        raise Err(f"libvirt domain '{domain}' not found")
    if state != "shut off":
        raise Err(f"'{domain}' is '{state}'. Shut it down first so the template image is consistent.")
    primary_disk(dom_root(domain, inactive=True))
    with conn() as c:
        if one(c, "SELECT id FROM templates WHERE name=?", name):
            raise Err(f"template '{name}' already exists")
    ttl_minutes = int(ttl_minutes)
    if ttl_minutes < 5:
        raise Err("Session length must be at least 5 minutes")
    return job_start("template", f"Create template {name}", {
        "name": name, "domain": domain, "vcpus": int(vcpus), "memory_mb": int(memory_mb),
        "ttl": ttl_minutes, "max_disk_gb": int(max_disk_gb), "iops": int(iops),
        "sysprep": bool(sysprep), "no_copy": bool(no_copy)})


def w_template(p, prog):
    domain, name = p["domain"], p["name"]
    if vm_state(domain) != "shut off":
        raise Err(f"'{domain}' must be shut off")
    xml = virsh("dumpxml", "--inactive", domain)
    src, fmt = primary_disk(ET.fromstring(xml))
    golden, owns = None, 0
    try:
        if p["no_copy"]:
            golden, gfmt = src, fmt
        else:
            prog(0, "Cloning the disk into a golden image")
            golden = str(sdir("golden") / f"{name}.qcow2")
            if free_bytes(C["state_dir"]) < os.path.getsize(src) + (1 << 28):
                raise Err("Not enough free disk space to clone this VM's disk")
            run_progress(["qemu-img", "convert", "-p", "-f", fmt, "-O", "qcow2", src, golden],
                         lambda x: prog(x * 0.98))
            os.chmod(golden, 0o644)
            gfmt, owns = "qcow2", 1
        prog(99, "Registering template")
        with conn() as c:
            c.execute("INSERT INTO templates(name,source_domain,golden,golden_fmt,owns_golden,xml,vcpus,"
                      "memory_mb,ttl_minutes,max_disk_gb,iops,sysprep,created) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (name, domain, golden, gfmt, owns, xml, p["vcpus"], p["memory_mb"], p["ttl"],
                       p["max_disk_gb"], p["iops"], int(p["sysprep"]), int(time.time())))
        golden = None if owns or not p["no_copy"] else None
        return {"name": name}
    except BaseException:
        if golden and not p["no_copy"]:
            Path(golden).unlink(missing_ok=True)
        raise


def template_list():
    with conn() as c:
        res = rows(c, "SELECT id,name,source_domain,golden,golden_fmt,owns_golden,vcpus,memory_mb,"
                      "ttl_minutes,max_disk_gb,iops,sysprep,created FROM templates ORDER BY id")
        for t in res:
            t["invites"] = one(c, "SELECT COUNT(*) n FROM invites WHERE template_id=?", t["id"])["n"]
            t["live"] = one(c, "SELECT COUNT(*) n FROM sessions WHERE template_id=? AND state IN ('active','creating')",
                            t["id"])["n"]
    for t in res:
        t["golden_mb"] = overlay_bytes(t["golden"]) // 1048576 if t["owns_golden"] else 0
    return res


def template_rm(id, force=False):
    """Remove a template, its invites, its golden image and (with force) its running guests.
    The shared 'vmportal' libvirt network is intentionally kept: other templates use it and an idle
    network costs nothing; guests are what use resources and each one is destroyed with its session."""
    with conn() as c:
        t = one(c, "SELECT * FROM templates WHERE id=?", int(id))
        if not t:
            raise Err("no such template", 404)
        live = rows(c, "SELECT id FROM sessions WHERE template_id=? AND state IN ('active','creating')", t["id"])
    if live and not force:
        raise Err(f"{len(live)} guest session(s) are running from this template. End them first, or confirm to end them.")
    for s in live:
        destroy_session(s["id"], "template removed")
    with conn() as c:
        n_inv = c.execute("DELETE FROM invites WHERE template_id=?", (t["id"],)).rowcount
        c.execute("DELETE FROM sessions WHERE template_id=?", (t["id"],))
        c.execute("DELETE FROM templates WHERE id=?", (t["id"],))
    freed = 0
    if t["owns_golden"]:
        freed = overlay_bytes(t["golden"])
        Path(t["golden"]).unlink(missing_ok=True)
    return {"ok": True, "sessions_ended": len(live), "invites_removed": n_inv, "freed_mb": freed // 1048576}


# ----------------------------------------------------------------------------- invites
def invite_add(template, label="", expires_hours=72, max_uses=1, password=""):
    """expires_hours=0 -> never expires; max_uses=0 -> unlimited launches."""
    expires_hours, max_uses = float(expires_hours), int(max_uses)
    if expires_hours < 0 or max_uses < 0:
        raise Err("Values cannot be negative")
    with conn() as c:
        if not one(c, "SELECT id FROM templates WHERE id=?", int(template)):
            raise Err("no such template", 404)
        token = secrets.token_urlsafe(14)
        exp = int(time.time() + expires_hours * 3600) if expires_hours else 0
        c.execute("INSERT INTO invites(token,template_id,label,expires,max_uses,pw_hash,created) VALUES(?,?,?,?,?,?,?)",
                  (token, int(template), str(label)[:60], exp, max_uses, pw_hash(password) if password else None,
                   int(time.time())))
    return {"ok": True, "token": token}


def invite_list():
    with conn() as c:
        return rows(c, "SELECT i.token,i.label,i.expires,i.max_uses,i.uses,i.revoked,i.created,"
                       "(i.pw_hash IS NOT NULL) AS has_password,t.name AS template,i.template_id "
                       "FROM invites i LEFT JOIN templates t ON t.id=i.template_id ORDER BY i.created DESC")


def invite_revoke(token):
    with conn() as c:
        c.execute("UPDATE invites SET revoked=1 WHERE token=?", (token,))
    return {"ok": True}


def invite_delete(token):
    with conn() as c:
        c.execute("DELETE FROM invites WHERE token=?", (token,))
    return {"ok": True}


def invite_public(token):
    with conn() as c:
        inv = one(c, "SELECT * FROM invites WHERE token=?", token)
        if not inv:
            raise Err("This invite link is not valid.", 404)
        t = one(c, "SELECT name,ttl_minutes,vcpus,memory_mb FROM templates WHERE id=?", inv["template_id"])
    if not t:
        raise Err("This invite link is no longer available.", 410)
    if inv["revoked"]:
        raise Err("This invite has been revoked.", 410)
    if inv["expires"] and inv["expires"] < time.time():
        raise Err("This invite has expired.", 410)
    if inv["max_uses"] and inv["uses"] >= inv["max_uses"]:
        raise Err("This invite has already been used up.", 410)
    return {"template": t["name"], "ttl_minutes": t["ttl_minutes"], "vcpus": t["vcpus"],
            "memory_mb": t["memory_mb"], "needs_password": bool(inv["pw_hash"]),
            "uses_left": (inv["max_uses"] - inv["uses"]) if inv["max_uses"] else None}


# ----------------------------------------------------------------------------- guest sessions
def cleanup_vm(name, overlay=None, nvram=None):
    virsh("destroy", name, check=False)
    virsh("undefine", name, "--nvram", check=False)
    virsh("undefine", name, check=False)
    for p in (overlay, nvram):
        if p:
            Path(p).unlink(missing_ok=True)


def create_vm(tpl, sid, progress=lambda p, s: None):
    name = f"vmp-{sid}"
    pdir = pool_dir()
    overlay = pdir / f"{name}.qcow2"
    nvram = None
    try:
        progress(10, "Creating your private disk")
        run(["qemu-img", "create", "-q", "-f", "qcow2", "-F", tpl["golden_fmt"], "-b", tpl["golden"], str(overlay)])
        os.chmod(overlay, 0o600)
        progress(30, "Preparing firmware")
        root = ET.fromstring(tpl["xml"])
        nv = root.find("os/nvram")
        if nv is not None and nv.text and os.path.exists(nv.text):
            nvram = pdir / f"{name}_VARS.fd"
            shutil.copyfile(nv.text, nvram)
        if tpl["sysprep"] and shutil.which("virt-sysprep"):
            progress(40, "Giving the machine a fresh identity")
            env = dict(os.environ, LIBGUESTFS_BACKEND="direct")
            run(["virt-sysprep", "-q", "-a", str(overlay), "--hostname", name, "--operations",
                 "machine-id,ssh-hostkeys,dhcp-client-state,net-hwaddr,logfiles,tmp-files"], timeout=600, env=env)
        progress(65, "Configuring the virtual machine")
        vnc_pw = secrets.token_hex(4)
        xml = build_xml(tpl, name, overlay, vnc_pw, nvram)
        define_xml(xml)
        progress(80, "Booting")
        virsh("start", name)
        progress(95, "Waiting for the console")
        port = vnc_port(name)
        return {"domain": name, "overlay": str(overlay), "nvram": str(nvram) if nvram else None,
                "vnc_pw": vnc_pw, "vnc_port": port}
    except Exception:
        cleanup_vm(name, overlay, nvram)
        raise


def sess_update(sid, **kw):
    with conn() as c:
        c.execute("UPDATE sessions SET " + ",".join(f"{k}=?" for k in kw) + " WHERE id=?", (*kw.values(), sid))


def build_session(sid, tpl, ct):
    try:
        vm = create_vm(tpl, sid, lambda p, s: sess_update(sid, progress=p, step=s))
        write_token(ct, vm["vnc_port"])
        now = int(time.time())
        with conn() as c:
            n = c.execute("UPDATE sessions SET state='active',overlay=?,nvram=?,vnc_pw=?,vnc_port=?,progress=100,"
                          "step='Ready',expires=? WHERE id=? AND state='creating'",
                          (vm["overlay"], vm["nvram"], vm["vnc_pw"], vm["vnc_port"],
                           now + tpl["ttl_minutes"] * 60, sid)).rowcount
        if not n:                                   # ended by an admin while we were building
            cleanup_vm(vm["domain"], vm["overlay"], vm["nvram"])
            Path(C["token_dir"], ct).unlink(missing_ok=True)
    except Exception as e:
        log("session build failed:", sid, repr(e))
        with conn() as c:
            row = one(c, "SELECT invite FROM sessions WHERE id=?", sid)
            c.execute("UPDATE sessions SET state='ended',note=?,progress=0 WHERE id=?",
                      (f"Could not create your VM: {e}", sid))
            if row:
                c.execute("UPDATE invites SET uses=MAX(0,uses-1) WHERE token=?", (row["invite"],))


def launch(token, password, ip):
    with LAUNCH_LOCK:
        with conn() as c:
            inv = one(c, "SELECT * FROM invites WHERE token=?", token)
            if not inv:
                raise Err("This invite link is not valid.", 404)
            invite_public(token)
            if inv["pw_hash"] and not (password and pw_check(password, inv["pw_hash"])):
                raise Err("Wrong password.", 403)
            n = one(c, "SELECT COUNT(*) n FROM sessions WHERE state IN ('active','creating')")["n"]
            if n >= C["max_sessions"]:
                raise Err("The server is at capacity right now. Please try again later.", 503)
            tpl = one(c, "SELECT * FROM templates WHERE id=?", inv["template_id"])
            sid, secret, ct = secrets.token_hex(4), secrets.token_urlsafe(24), secrets.token_hex(16)
            now = int(time.time())
            c.execute("INSERT INTO sessions(id,secret_hash,invite,template_id,domain,overlay,nvram,console_token,"
                      "vnc_pw,vnc_port,created,expires,state,ip,progress,step) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (sid, sha(secret), token, tpl["id"], f"vmp-{sid}", "", None, ct, "", 0, now, now + 1800,
                       "creating", ip, 0, "Queued"))
            c.execute("UPDATE invites SET uses=uses+1 WHERE token=?", (token,))
    threading.Thread(target=build_session, args=(sid, tpl, ct), daemon=True).start()
    return secret


def get_session(secret):
    with conn() as c:
        s = one(c, "SELECT * FROM sessions WHERE secret_hash=?", sha(secret))
    if not s:
        raise Err("Session not found.", 404)
    return s


def session_view(s, host):
    if s["state"] == "creating":
        return {"id": s["id"], "vm_state": "creating", "creating": True, "ended": False, "note": "",
                "progress": s["progress"], "step": s["step"], "remaining": 0, "can_extend": False}
    st = vm_state(s["domain"]) if s["state"] == "active" else "ended"
    st = st or "missing"
    view = {"id": s["id"], "vm_state": st, "ended": s["state"] != "active", "creating": False,
            "note": s["note"], "expires": s["expires"], "remaining": max(0, s["expires"] - int(time.time())),
            "can_extend": s["extensions"] < C["max_extensions"] and s["state"] == "active"}
    if st == "running":
        h = C["public_host"] or host
        scheme = "https" if C["ws_tls"] else "http"
        path = quote("websockify?token=" + s["console_token"], safe="")
        view["console_url"] = (f"{scheme}://{h}:{C['ws_port']}/vnc.html?autoconnect=true&resize=scale"
                               f"&path={path}&password={s['vnc_pw']}")
    return view


def sync_port(s):
    port = vnc_port(s["domain"])
    write_token(s["console_token"], port)
    with conn() as c:
        c.execute("UPDATE sessions SET vnc_port=? WHERE id=?", (port, s["id"]))


def over_quota(s):
    with conn() as c:
        t = one(c, "SELECT max_disk_gb FROM templates WHERE id=?", s["template_id"])
    return bool(t) and overlay_bytes(s["overlay"]) > t["max_disk_gb"] * 1024 ** 3


def destroy_session(sid, note="ended"):
    with conn() as c:
        s = one(c, "SELECT * FROM sessions WHERE id=?", sid)
    if not s:
        raise Err("no such session", 404)
    cleanup_vm(s["domain"], s["overlay"] or None, s["nvram"])
    Path(C["token_dir"], s["console_token"]).unlink(missing_ok=True)
    with conn() as c:
        c.execute("UPDATE sessions SET state='ended', note=? WHERE id=?", (note, sid))
    return {"ok": True}


def session_action(s, action):
    if s["state"] == "creating":
        raise Err("Your VM is still being prepared.", 409)
    if s["state"] != "active":
        raise Err("This session has ended.", 410)
    dom = s["domain"]
    if action == "start":
        if over_quota(s):
            raise Err("Disk quota exceeded. Use 'Reset to clean' to start over.", 409)
        virsh("start", dom)
        sync_port(s)
    elif action == "shutdown":
        virsh("shutdown", dom)
    elif action == "poweroff":
        virsh("destroy", dom)
    elif action == "reboot":
        virsh("reboot", dom)
    elif action == "reset":
        virsh("destroy", dom, check=False)
        with conn() as c:
            t = one(c, "SELECT * FROM templates WHERE id=?", s["template_id"])
        os.unlink(s["overlay"])
        run(["qemu-img", "create", "-q", "-f", "qcow2", "-F", t["golden_fmt"], "-b", t["golden"], s["overlay"]])
        os.chmod(s["overlay"], 0o600)
        virsh("start", dom)
        sync_port(s)
        with conn() as c:
            c.execute("UPDATE sessions SET note='' WHERE id=?", (s["id"],))
    elif action == "extend":
        if s["extensions"] >= C["max_extensions"]:
            raise Err("No more extensions available.", 403)
        with conn() as c:
            t = one(c, "SELECT ttl_minutes FROM templates WHERE id=?", s["template_id"])
            c.execute("UPDATE sessions SET expires=expires+?, extensions=extensions+1 WHERE id=?",
                      (t["ttl_minutes"] * 60 // 2, s["id"]))
    elif action == "end":
        destroy_session(s["id"], "ended by user")
    else:
        raise Err("unknown action")
    return {"ok": True}


def session_list():
    """Live sessions only: once a session ends it disappears from this list."""
    with conn() as c:
        res = rows(c, "SELECT s.id,s.domain,s.created,s.expires,s.state,s.note,s.ip,s.overlay,s.extensions,"
                      "s.progress,s.step,t.name AS template, i.label AS invite_label "
                      "FROM sessions s LEFT JOIN templates t ON t.id=s.template_id "
                      "LEFT JOIN invites i ON i.token=s.invite "
                      "WHERE s.state IN ('active','creating') ORDER BY s.created DESC")
    for r in res:
        r["vm_state"] = vm_state(r["domain"]) if r["state"] == "active" else "creating"
        r["disk_mb"] = overlay_bytes(r["overlay"]) // 1048576 if r["overlay"] else 0
        del r["overlay"]
    return res


# ----------------------------------------------------------------------------- status + reaper
def host_info():
    mem = {}
    try:
        for line in open("/proc/meminfo"):
            k, v = line.split(":")
            mem[k] = int(v.split()[0]) // 1024
    except OSError:
        pass
    return {"cpus": os.cpu_count() or 1, "mem_total_mb": mem.get("MemTotal", 0),
            "mem_avail_mb": mem.get("MemAvailable", 0), "kvm": kvm_ok()}


def status():
    st = Path(C["state_dir"])
    st.mkdir(parents=True, exist_ok=True)
    with conn() as c:
        sess = one(c, "SELECT SUM(state='active') a, SUM(state='creating') b FROM sessions")
        tpl = one(c, "SELECT COUNT(*) n FROM templates")["n"]
        inv = one(c, "SELECT COUNT(*) n FROM invites WHERE revoked=0 AND (expires=0 OR expires>?) "
                     "AND (max_uses=0 OR uses<max_uses)", int(time.time()))["n"]
        lib = one(c, "SELECT COUNT(*) n FROM library")["n"]
    du = shutil.disk_usage(st)
    return {"active": sess["a"] or 0, "creating": sess["b"] or 0, "max_sessions": C["max_sessions"],
            "port": C["port"], "public_host": C["public_host"], "ws_port": C["ws_port"], "ws_tls": C["ws_tls"],
            "tls": bool(C["tls_cert"]) or C["trust_proxy"], "templates": tpl, "invites_active": inv,
            "library": lib, "disk_total": du.total, "disk_free": du.free, "data_bytes": tree_bytes(st),
            "network": C["network"], "network_up": virsh_ok("net-info", C["network"]), **host_info()}


def reap_once():
    now = int(time.time())
    with LAUNCH_LOCK:
        with conn() as c:
            live = rows(c, "SELECT * FROM sessions WHERE state IN ('active','creating')")
            c.execute("DELETE FROM sessions WHERE state='ended' AND created<?", (now - 86400,))
        ids = {s["id"] for s in live}
        for s in live:
            try:
                if s["expires"] <= now:
                    destroy_session(s["id"], "expired" if s["state"] == "active" else "timed out while starting")
                    continue
                if s["state"] != "active":
                    continue
                st = vm_state(s["domain"])
                if st is None:
                    destroy_session(s["id"], "VM disappeared")
                elif st == "running" and over_quota(s):
                    virsh("destroy", s["domain"], check=False)
                    sess_update(s["id"], note="VM was stopped: disk quota exceeded. Use 'Reset to clean'.")
            except Exception as e:
                log("reaper error for", s["id"], e)
        for n in virsh("list", "--all", "--name", check=False).split("\n"):
            n = n.strip()
            if n.startswith("vmp-") and n[4:] not in ids:
                log("removing orphan domain", n)
                cleanup_vm(n)
                for p in Path(C["state_dir"], "clones").glob(n + "*"):
                    p.unlink(missing_ok=True)
        for s in live:
            if s["state"] == "active" and vm_state(s["domain"]) == "running":
                try:
                    write_token(s["console_token"], vnc_port(s["domain"]))
                except Exception:
                    pass
    tdir = Path(C["token_dir"])
    if tdir.is_dir():
        for p in tdir.glob("adm-*"):
            if now - p.stat().st_mtime > 1800:
                p.unlink(missing_ok=True)
    up = Path(C["state_dir"], "uploads")
    if up.is_dir():
        for p in up.iterdir():
            if now - p.stat().st_mtime > 3 * 86400:
                p.unlink(missing_ok=True)


def reaper_loop():
    while True:
        try:
            reap_once()
        except Exception as e:
            log("reaper loop error:", e)
        time.sleep(20)


def purge_vms(guests_only=False):
    """Used by the uninstaller: delete all guest VMs and (unless guests_only) the VMs created by this app."""
    n = 0
    for name in dom_names():
        if name.startswith("vmp-"):
            cleanup_vm(name)
            n += 1
    if guests_only:
        return {"removed": n}
    with conn() as c:
        mine = [r["name"] for r in c.execute("SELECT name FROM managed")]
    for name in mine:
        if vm_state(name) is not None:
            virsh("destroy", name, check=False)
            virsh("undefine", name, "--nvram", "--managed-save", "--snapshots-metadata", check=False)
            n += 1
    return {"removed": n}


# ----------------------------------------------------------------------------- HTTP (visitor portal)
class RateLimiter:
    def __init__(self):
        self.hits, self.lock = {}, threading.Lock()

    def allow(self, key, limit, window):
        now = time.time()
        with self.lock:
            lst = [t for t in self.hits.get(key, []) if t > now - window]
            ok = len(lst) < limit
            if ok:
                lst.append(now)
            self.hits[key] = lst
            return ok


LAUNCH_RL, PROBE_RL = RateLimiter(), RateLimiter()
ASSETS = {"/assets/portal.js": ("portal.js", "text/javascript"),
          "/assets/portal.css": ("portal.css", "text/css")}


class Handler(BaseHTTPRequestHandler):
    server_version = "vmportal"

    def log_message(self, fmt, *a):
        log("%s - %s" % (self.client_address[0], fmt % a))

    def ip(self):
        if C["trust_proxy"]:
            xff = self.headers.get("X-Forwarded-For")
            if xff:
                return xff.split(",")[-1].strip()
        return self.client_address[0]

    def host(self):
        return (self.headers.get("Host") or "localhost").rsplit(":", 1)[0].strip("[]")

    def _headers(self, code, ctype, length):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(length))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy",
                         "default-src 'none'; script-src 'self'; style-src 'self'; "
                         "connect-src 'self'; img-src 'self' data:; base-uri 'none'; form-action 'none'")
        self.end_headers()

    def json(self, obj, code=200):
        b = json.dumps(obj).encode()
        self._headers(code, "application/json", len(b))
        self.wfile.write(b)

    def file(self, name, ctype):
        p = Path(C["web_dir"]) / name
        if not p.is_file():
            return self.json({"error": "not found"}, 404)
        b = p.read_bytes()
        self._headers(200, ctype + "; charset=utf-8", len(b))
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 4096:
            raise Err("request too large", 413)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def guard(self, fn):
        try:
            fn()
        except Err as e:
            self.json({"error": str(e)}, e.code)
        except (json.JSONDecodeError, ValueError):
            self.json({"error": "bad request"}, 400)
        except Exception as e:
            log("unhandled error:", repr(e))
            self.json({"error": "internal error"}, 500)

    def do_GET(self):
        self.guard(self._get)

    def do_POST(self):
        self.guard(self._post)

    def _get(self):
        path = urlparse(self.path).path
        if path in ASSETS:
            return self.file(*ASSETS[path])
        if path == "/" or path.startswith("/i/") or path.startswith("/s/"):
            return self.file("portal.html", "text/html")
        if path == "/healthz":
            return self.json({"ok": True})
        m = re.fullmatch(r"/api/invite/([\w-]{8,64})", path)
        if m:
            if not PROBE_RL.allow(self.ip(), 60, 600):
                raise Err("Too many requests.", 429)
            return self.json(invite_public(m.group(1)))
        m = re.fullmatch(r"/api/session/([\w-]{16,64})", path)
        if m:
            if not PROBE_RL.allow("s" + self.ip(), 600, 600):
                raise Err("Too many requests.", 429)
            return self.json(session_view(get_session(m.group(1)), self.host()))
        self.json({"error": "not found"}, 404)

    def _post(self):
        path = urlparse(self.path).path
        if path == "/api/launch":
            ip = self.ip()
            if not LAUNCH_RL.allow(ip, C["launches_per_hour_per_ip"], 3600):
                raise Err("Too many launches from your address. Try again later.", 429)
            b = self.body()
            token = str(b.get("invite", ""))
            if not re.fullmatch(r"[\w-]{8,64}", token):
                raise Err("This invite link is not valid.", 404)
            return self.json({"session": launch(token, str(b.get("password", "")), ip)})
        m = re.fullmatch(r"/api/session/([\w-]{16,64})/(\w+)", path)
        if m:
            if not PROBE_RL.allow("a" + self.ip(), 300, 600):
                raise Err("Too many requests.", 429)
            return self.json(session_action(get_session(m.group(1)), m.group(2)))
        self.json({"error": "not found"}, 404)


def serve():
    for p in (Path(C["state_dir"]), Path(C["token_dir"])):
        p.mkdir(parents=True, exist_ok=True)
    pool_dir()
    threading.Thread(target=reaper_loop, daemon=True).start()
    srv = ThreadingHTTPServer((C["listen"], int(C["port"])), Handler)
    srv.daemon_threads = True
    if C["tls_cert"] and C["tls_key"]:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(C["tls_cert"], C["tls_key"])
        srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    log(f"vmportal listening on {C['listen']}:{C['port']}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


def exec_websockify():
    cmd = ["websockify", "--web", C["novnc_dir"], "--token-plugin", "TokenFile",
           "--token-source", C["token_dir"]]
    if C["ws_tls"] and C["ws_cert"]:
        cmd += ["--cert", C["ws_cert"]] + (["--key", C["ws_key"]] if C["ws_key"] else [])
    cmd.append(f"0.0.0.0:{C['ws_port']}")
    os.execvp(cmd[0], cmd)


# ----------------------------------------------------------------------------- CLI
API = {
    "status": status, "config-get": config_get, "config-set": config_set,
    "vm-list": vm_list, "vm-action": vm_action, "vm-delete": vm_delete, "vm-console": vm_console,
    "vm-set": vm_set, "vm-media": vm_media, "vm-snap": vm_snap, "vm-create": vm_create, "net-list": net_list,
    "lib-list": lib_list, "lib-rm": lib_rm,
    "upload-begin": upload_begin, "upload-status": upload_status, "upload-finish": upload_finish,
    "upload-abort": upload_abort,
    "template-add": template_add, "template-list": template_list, "template-rm": template_rm,
    "invite-add": invite_add, "invite-list": invite_list, "invite-revoke": invite_revoke,
    "invite-delete": invite_delete,
    "session-list": session_list, "session-kill": lambda id: destroy_session(id, "ended by admin"),
    "job-list": job_list, "job-cancel": job_cancel, "job-dismiss": job_dismiss,
}


def main():
    ap = argparse.ArgumentParser(prog="vmportal")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for n in ("serve", "ws", "status", "template-ls", "invite-ls", "session-ls"):
        sub.add_parser(n)
    s = sub.add_parser("purge-vms")
    s.add_argument("--guests-only", action="store_true")
    s = sub.add_parser("call")
    s.add_argument("command")
    s = sub.add_parser("_work")
    s.add_argument("job")
    s = sub.add_parser("upload-chunk")
    s.add_argument("--id", required=True)
    s.add_argument("--offset", type=int, required=True)
    s = sub.add_parser("invite-add")
    s.add_argument("--template", type=int, required=True)
    s.add_argument("--label", default="")
    s.add_argument("--expires-hours", type=float, default=72, help="0 = never expires")
    s.add_argument("--max-uses", type=int, default=1, help="0 = unlimited")
    s.add_argument("--password", default=os.environ.get("VMPORTAL_INVITE_PASSWORD", ""))
    s = sub.add_parser("session-kill")
    s.add_argument("id")
    a = ap.parse_args()

    load_conf(required=a.cmd in ("serve", "ws"))
    try:
        if a.cmd == "serve":
            return serve()
        if a.cmd == "ws":
            return exec_websockify()
        if a.cmd == "_work":
            return work(a.job)
        if a.cmd == "upload-chunk":
            out = upload_chunk(a.id, a.offset)
        elif a.cmd == "call":
            if a.command not in API:
                raise Err(f"unknown command '{a.command}'")
            raw = sys.stdin.read()
            params = json.loads(raw) if raw.strip() else {}
            out = API[a.command](**params)
        elif a.cmd == "purge-vms":
            out = purge_vms(a.guests_only)
        elif a.cmd == "status":
            out = status()
        elif a.cmd == "template-ls":
            out = template_list()
        elif a.cmd == "invite-ls":
            out = invite_list()
        elif a.cmd == "session-ls":
            out = session_list()
        elif a.cmd == "session-kill":
            out = destroy_session(a.id, "ended by admin")
        elif a.cmd == "invite-add":
            out = invite_add(a.template, a.label, a.expires_hours, a.max_uses, a.password)
        print(json.dumps(out))
    except Err as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)
    except TypeError as e:
        print(f"bad parameters: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
