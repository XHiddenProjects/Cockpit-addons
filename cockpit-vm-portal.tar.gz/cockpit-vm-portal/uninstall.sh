#!/usr/bin/env bash
# Uninstall VM Portal.
#   uninstall.sh            remove the software; keep settings, templates, images and VMs you created
#   uninstall.sh --purge    remove everything, including data, created VMs and the guest network
#   --yes                   do not ask for confirmation (used by the Cockpit page)
# Packages (cockpit, libvirt, novnc, ...) are never removed. VMs made in Cockpit are never touched.
set -uo pipefail

# Re-run from a temp copy: this script lives in a directory that is deleted below.
if [ -z "${VMP_COPY:-}" ]; then
    tmp="$(mktemp /tmp/vmp-uninstall.XXXXXX)" && cp "$0" "$tmp" && VMP_COPY=1 exec bash "$tmp" "$@"
fi
trap 'rm -f "$0"' EXIT

PURGE=0; YES=0
for a in "$@"; do
    case "$a" in
        --purge) PURGE=1 ;;
        --yes|-y) YES=1 ;;
        -h|--help) sed -n '2,7p' "${VMP_SELF:-$0}"; exit 0 ;;
        *) echo "Unknown option: $a" >&2; exit 2 ;;
    esac
done
[ "$(id -u)" = 0 ] || { echo "Run as root (sudo vm-portal-uninstall)"; exit 1; }

if [ "$YES" = 0 ]; then
    [ "$PURGE" = 1 ] && echo "This permanently deletes ALL VM Portal data, including VMs created with it." \
                     || echo "This removes VM Portal and ends all guest sessions (data is kept)."
    read -r -p "Continue? [y/N] " ans
    case "$ans" in y|Y|yes|YES) ;; *) echo "Cancelled."; exit 1 ;; esac
fi

VMP=/usr/lib/vm-portal/vmportal
CONF=/etc/vm-portal/config.json
NET=vmportal
[ -f "$CONF" ] && NET="$(python3 -c "import json;print(json.load(open('$CONF')).get('network','vmportal'))" 2>/dev/null || echo vmportal)"

echo "==> Stopping services"
systemctl disable --now vm-portal.service vm-portal-ws.service vm-portal-nft.service 2>/dev/null || true
nft delete table inet vmportal 2>/dev/null || true

echo "==> Removing guest VMs"
if [ -x "$VMP" ]; then
    if [ "$PURGE" = 1 ]; then "$VMP" purge-vms || true; else "$VMP" purge-vms --guests-only || true; fi
else
    for d in $(virsh -c qemu:///system list --all --name 2>/dev/null | grep '^vmp-' || true); do
        virsh -c qemu:///system destroy "$d" >/dev/null 2>&1
        virsh -c qemu:///system undefine "$d" --nvram >/dev/null 2>&1 || virsh -c qemu:///system undefine "$d" >/dev/null 2>&1
    done
fi

if [ "$PURGE" = 1 ]; then
    echo "==> Removing guest network '$NET'"
    virsh -c qemu:///system net-destroy "$NET" >/dev/null 2>&1 || true
    virsh -c qemu:///system net-undefine "$NET" >/dev/null 2>&1 || true
fi

echo "==> Removing files"
rm -f /etc/systemd/system/vm-portal.service /etc/systemd/system/vm-portal-ws.service /etc/systemd/system/vm-portal-nft.service
rm -rf /usr/share/cockpit/vm-portal /usr/share/vm-portal /usr/lib/vm-portal /run/vm-portal
rm -f /usr/local/bin/vmportal /usr/local/sbin/vm-portal-uninstall
if [ "$PURGE" = 1 ]; then
    rm -rf /etc/vm-portal /var/lib/vm-portal
fi
systemctl daemon-reload
systemctl reset-failed 'vm-portal*' 2>/dev/null || true

echo
if [ "$PURGE" = 1 ]; then
    echo "VM Portal and all of its data have been removed."
else
    echo "VM Portal has been removed. Kept for a later reinstall:"
    echo "  /etc/vm-portal   (settings)"
    echo "  /var/lib/vm-portal   (templates, images, VMs created with it)"
    echo "  libvirt network '$NET'"
    echo "Run again with --purge to delete those too."
fi
