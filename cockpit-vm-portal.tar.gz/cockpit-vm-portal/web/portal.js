"use strict";
const $ = (id) => document.getElementById(id);
const parts = location.pathname.split("/").filter(Boolean);
const mode = parts[0], token = parts[1];
let deadline = 0;

async function api(path, body) {
    const r = await fetch(path, body === undefined ? {} : {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "Something went wrong.");
    return j;
}
const msg = (t, bad) => { const m = $("msg"); m.textContent = t; m.className = bad ? "lead warn" : "lead"; m.hidden = !t; };

async function showInvite() {
    try {
        const i = await api("/api/invite/" + encodeURIComponent(token));
        msg("You have been invited to try a private virtual machine.");
        const dl = $("info");
        dl.replaceChildren();
        for (const [k, v] of [["Image", i.template], ["Resources", `${i.vcpus} vCPU · ${i.memory_mb} MB RAM`],
                              ["Available for", `${i.ttl_minutes} minutes`]]) {
            const dt = document.createElement("dt"); dt.textContent = k;
            const dd = document.createElement("dd"); dd.textContent = v;
            dl.append(dt, dd);
        }
        $("pw-row").hidden = !i.needs_password;
        $("launch").hidden = false;
    } catch (e) { msg(e.message, true); }
}

$("launch").addEventListener("submit", async (ev) => {
    ev.preventDefault();
    $("go").disabled = true;
    msg("Creating your VM… this takes a few seconds.");
    try {
        const r = await api("/api/launch", { invite: token, password: $("pw").value });
        location.replace("/s/" + r.session);
    } catch (e) { msg(e.message, true); $("go").disabled = false; }
});

function render(s) {
    if (s.creating) {
        $("session").hidden = true;
        $("creating").hidden = false;
        $("pbar").style.width = Math.max(4, s.progress) + "%";
        $("pstep").textContent = `${s.step || "Preparing"}… ${Math.round(s.progress)}%`;
        msg("Setting up your private VM. This page updates by itself.");
        return;
    }
    $("creating").hidden = true;
    $("session").hidden = false;
    msg("");
    deadline = Date.now() / 1000 + s.remaining;
    const label = s.ended ? "ended" : s.vm_state;
    $("badge").textContent = label;
    $("badge").className = "badge " + (label === "running" ? "ok" : label === "ended" ? "bad" : "");
    $("note").hidden = !s.note;
    $("note").textContent = s.note || "";
    const run = s.vm_state === "running";
    const c = $("console");
    c.hidden = !run;
    if (run) c.href = s.console_url;
    document.querySelectorAll("[data-act]").forEach((b) => {
        const a = b.dataset.act;
        if (a === "start") b.hidden = s.ended || run || s.vm_state === "in shutdown";
        else if (["shutdown", "reboot", "poweroff"].includes(a)) b.hidden = s.ended || !run;
        else if (a === "extend") b.hidden = !s.can_extend;
        else b.hidden = s.ended;
    });
    if (s.ended) msg("This session has ended" + (s.note ? ": " + s.note : "."), true);
}

async function poll() {
    let creating = false;
    try { const s = await api("/api/session/" + encodeURIComponent(token)); creating = s.creating; render(s); }
    catch (e) { $("session").hidden = true; $("creating").hidden = true; msg(e.message, true); return; }
    setTimeout(poll, creating ? 1200 : 5000);
}

function tick() {
    if (deadline) {
        const s = Math.max(0, Math.round(deadline - Date.now() / 1000));
        $("timer").textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")} left`;
    }
    setTimeout(tick, 1000);
}

document.querySelectorAll("[data-act]").forEach((b) => b.addEventListener("click", async () => {
    const a = b.dataset.act;
    if (a === "end" && !confirm("End the session? Everything in the VM will be deleted.")) return;
    if (a === "reset" && !confirm("Reset the VM to its original state? Your changes will be lost.")) return;
    b.disabled = true;
    try { await api(`/api/session/${encodeURIComponent(token)}/${a}`, {}); } catch (e) { msg(e.message, true); }
    b.disabled = false;
    poll();
}));

if (mode === "i" && token) showInvite();
else if (mode === "s" && token) { poll(); tick(); }
else msg("Open the personal link you were sent to start your virtual machine.");
