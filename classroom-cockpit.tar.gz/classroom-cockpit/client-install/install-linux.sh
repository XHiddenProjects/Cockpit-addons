#!/usr/bin/env bash
set -euo pipefail

# ---- EDIT THESE TWO LINES ----
ADMIN_IP="10.200.0.10"
DLPORT="11099"
# -------------------------------

[ "$(id -u)" = 0 ] || { echo "Run as root: curl -fsSL http://$ADMIN_IP:$DLPORT/install-linux.sh | sudo bash"; exit 1; }
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT

OSPKGS="pkgs-linux.tar.gz"
if curl -fsSL -o "$T/pkgs.tar.gz" "http://$ADMIN_IP:$DLPORT/$OSPKGS" 2>/dev/null && [ -s "$T/pkgs.tar.gz" ]; then
  echo "Installing OS packages from LAN offline bundle (no internet used)..."
  mkdir -p "$T/pkgs"; tar xzf "$T/pkgs.tar.gz" -C "$T/pkgs"
  if   command -v dpkg >/dev/null && ls "$T"/pkgs/*.deb >/dev/null 2>&1; then
    dpkg -i "$T"/pkgs/*.deb || apt-get -f install -y
  elif command -v rpm  >/dev/null && ls "$T"/pkgs/*.rpm >/dev/null 2>&1; then
    rpm -Uvh --nodeps --replacepkgs "$T"/pkgs/*.rpm || dnf install -y "$T"/pkgs/*.rpm
  elif command -v pacman >/dev/null && ls "$T"/pkgs/*.pkg.tar.* >/dev/null 2>&1; then
    pacman -U --noconfirm "$T"/pkgs/*.pkg.tar.*
  else
    echo "Offline package bundle present but no matching package manager found." >&2
  fi
else
  echo "No offline OS package bundle found on admin server - falling back to online install."
  echo "(Prepare one with offline/prepare-linux-packages.sh if this machine has no internet.)"
  if   command -v apt-get >/dev/null; then apt-get update && apt-get install -y python3 python3-pil python3-pil.imagetk python3-tk python3-pyautogui libnotify-bin xdg-utils gnome-screenshot scrot nftables ethtool pulseaudio-utils
  elif command -v dnf     >/dev/null; then dnf install -y python3 python3-pillow python3-pillow-tk python3-tkinter python3-pyautogui libnotify xdg-utils gnome-screenshot scrot nftables ethtool pulseaudio-utils
  elif command -v pacman  >/dev/null; then pacman -S --noconfirm --needed python python-pillow tk python-pyautogui libnotify xdg-utils gnome-screenshot scrot nftables ethtool libpulse
  else echo "Unsupported package manager - install python3, Pillow(+ImageTk), tkinter, pyautogui manually" >&2; fi
fi

if curl -fsSL -o "$T/wheelhouse.tar.gz" "http://$ADMIN_IP:$DLPORT/wheelhouse-linux.tar.gz" 2>/dev/null && [ -s "$T/wheelhouse.tar.gz" ]; then
  mkdir -p "$T/wheelhouse"; tar xzf "$T/wheelhouse.tar.gz" -C "$T/wheelhouse"
  if [ -f "$T/wheelhouse/requirements-wheelhouse.txt" ]; then
    python3 -m pip install --no-index --find-links "$T/wheelhouse" -r "$T/wheelhouse/requirements-wheelhouse.txt" 2>/dev/null || true
  else
    python3 -m pip install --no-index --find-links "$T/wheelhouse" pillow pyautogui 2>/dev/null || true
  fi
fi

curl -fsSL "http://$ADMIN_IP:$DLPORT/agent-bundle.tar.gz" -o "$T/b.tar.gz"
mkdir -p "$T/b"; tar xzf "$T/b.tar.gz" -C "$T/b"
install -d /opt/classroom-agent /etc/classroom
install -m755 "$T/b/classroom_agent.py" /opt/classroom-agent/
install -m600 "$T/b/agent.json" /etc/classroom/agent.json

cat > /etc/systemd/system/classroom-agent.service <<EOF
[Unit]
Description=Classroom agent
After=network-online.target
[Service]
ExecStart=/usr/bin/python3 /opt/classroom-agent/classroom_agent.py
Restart=always
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload && systemctl enable --now classroom-agent
command -v ufw >/dev/null && ufw allow 11100/tcp && ufw allow 11101/udp || true
command -v firewall-cmd >/dev/null && firewall-cmd --permanent --add-port=11100/tcp --add-port=11101/udp && firewall-cmd --reload || true
echo "Classroom agent installed and running."