#!/usr/bin/env python3
"""Classroom agent - runs on every managed workstation (Linux, Windows, macOS)."""
import base64, hashlib, hmac, io, json, os, platform, re, shutil, socket, subprocess, sys, tempfile, threading, time

OS = platform.system()
CFG_PATH = {"Linux": "/etc/classroom/agent.json", "Darwin": "/usr/local/etc/classroom/agent.json",
           "Windows": r"C:\ProgramData\Classroom\agent.json"}[OS]
CFG = json.load(open(CFG_PATH))
SECRET = CFG["secret"].encode(); ADMIN = CFG["admin_ip"]
PORT = CFG.get("port", 11100); DPORT = CFG.get("discovery_port", 11101)
SHARE = CFG.get("share_dir", {"Linux": "/var/lib/classroom/share", "Darwin": "/Users/Shared/Classroom",
                              "Windows": r"C:\ProgramData\Classroom\Share"}[OS])
TMP = tempfile.gettempdir()

# The Scheduled Task (Windows) / LaunchDaemon (macOS) that runs this agent has no
# console, so stdout/stderr normally go nowhere - without this, a misconfigured or
# unreachable agent fails completely silently from the admin's point of view. Log
# next to agent.json, which the installers already made writable for this agent.
LOGF = os.path.join(os.path.dirname(CFG_PATH), "agent.log")
def log(msg):
    try:
        with open(LOGF, "a") as f: f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except OSError: pass
IND_FLAG = os.path.join(TMP, "classroom-indicator.flag")
SHOW_FILE = os.path.join(TMP, "classroom-show.jpg")
for sub in ("handout", "handin"):
    os.makedirs(os.path.join(SHARE, sub), exist_ok=True)
    try: os.chmod(os.path.join(SHARE, sub), 0o1777)
    except OSError: pass

def sh(cmd, timeout=20, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, **kw)

def must(r, what):
    if r.returncode != 0: raise RuntimeError(f"{what} failed: {(r.stderr or r.stdout).strip()}")

def active_user():
    if OS == "Linux":
        for line in sh(["loginctl", "list-sessions", "--no-legend"]).stdout.splitlines():
            sid = line.split()[0]
            p = dict(l.split("=", 1) for l in sh(["loginctl", "show-session", sid, "-p", "Name", "-p", "Type",
                     "-p", "Active", "-p", "User"]).stdout.splitlines() if "=" in l)
            if p.get("Active") == "yes" and p.get("Type") in ("x11", "wayland"): return p["Name"], int(p["User"])
    elif OS == "Darwin":
        u = sh(["stat", "-f%Su", "/dev/console"]).stdout.strip()
        if u and u != "root": return u, int(sh(["id", "-u", u]).stdout)
    else:
        return os.environ.get("USERNAME", ""), 0
    return None, None

def as_user(cmd):
    if OS == "Windows": return cmd
    u, uid = active_user()
    if not u: raise RuntimeError("no active user session")
    if OS == "Darwin": return ["launchctl", "asuser", str(uid), "sudo", "-u", u] + cmd
    xa = f"/run/user/{uid}/gdm/Xauthority"
    env = [f"XDG_RUNTIME_DIR=/run/user/{uid}", f"DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/{uid}/bus",
           "DISPLAY=:0", "WAYLAND_DISPLAY=wayland-0"]
    if os.path.exists(xa): env.append("XAUTHORITY=" + xa)
    return ["runuser", "-u", u, "--", "env"] + env + cmd

def capture():
    if OS == "Windows":
        from PIL import ImageGrab
        b = io.BytesIO(); ImageGrab.grab().save(b, "PNG"); return b.getvalue()
    tmp = os.path.join("/tmp", f"cls-{os.getpid()}-{threading.get_ident()}.png")
    tools = ([["screencapture", "-x", tmp]] if OS == "Darwin" else
             [["grim", tmp], ["gnome-screenshot", "-f", tmp], ["scrot", "-o", tmp], ["import", "-window", "root", tmp]])
    for t in tools:
        if OS != "Darwin" and not shutil.which(t[0]): continue
        try: sh(as_user(t), timeout=10)
        except Exception: continue
        if os.path.exists(tmp) and os.path.getsize(tmp) > 0:
            d = open(tmp, "rb").read(); os.remove(tmp); return d
    raise RuntimeError("no screenshot tool worked (install grim, scrot or gnome-screenshot)")

def shrink(raw, width):
    from PIL import Image
    im = Image.open(io.BytesIO(raw)).convert("RGB"); w, h = im.size
    if width and w > width: im = im.resize((width, int(h * width / w)))
    out = io.BytesIO(); im.save(out, "JPEG", quality=60); return out.getvalue(), w, h

b64 = lambda b: base64.b64encode(b).decode()

UI = r'''
import sys, os, time, tkinter as tk
from PIL import Image, ImageTk
mode, f = sys.argv[1], sys.argv[2]
r = tk.Tk(); r.attributes("-topmost", True)
if mode == "show":
    r.attributes("-fullscreen", True); r.configure(bg="black")
    lab = tk.Label(r, bg="black"); lab.pack(fill="both", expand=True)
else:
    r.overrideredirect(True); r.geometry("+10+10")
    tk.Label(r, text="\u25cf RECORDING", fg="white", bg="#c9190b", font=("sans", 12, "bold"), padx=8, pady=2).pack()
def tick():
    if not os.path.exists(f) or (mode == "show" and time.time() - os.path.getmtime(f) > 15):
        r.destroy(); return
    if mode == "show":
        try:
            im = Image.open(f).resize((max(r.winfo_width(), 1), max(r.winfo_height(), 1)))
            p = ImageTk.PhotoImage(im); lab.configure(image=p); lab.image = p
        except Exception: pass
    r.after(500, tick)
tick(); r.mainloop()
'''
_ui = {}
def start_ui(mode, path):
    pr = _ui.get(mode)
    if pr and pr.poll() is None: return pr
    _ui[mode] = subprocess.Popen(as_user([sys.executable, "-c", UI, mode, path])); return _ui[mode]

def _mac():
    """MAC of the NIC used to reach the admin server (so Wake-on-LAN targets the right card
    on multi-NIC machines); falls back to uuid.getnode()."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect((ADMIN if ADMIN not in ("", "*") else "8.8.8.8", 9))
        local = s.getsockname()[0]; s.close()
        if OS == "Linux":
            for line in sh(["ip", "-o", "-4", "addr", "show"]).stdout.splitlines():
                if f" {local}/" in line:
                    dev = line.split()[1]; return open(f"/sys/class/net/{dev}/address").read().strip()
    except Exception: pass
    import uuid; n = uuid.getnode()
    return ":".join(f"{(n >> i) & 0xff:02x}" for i in range(40, -8, -8))

def a_info(p):
    return {"hostname": socket.gethostname(), "os": OS, "user": active_user()[0] or "", "mac": _mac()}

def enable_wol():
    """Best effort: ask every physical NIC to wake on magic packet. Runs at every agent start
    (i.e. every boot), because the Linux setting doesn't survive a reboot on its own. Windows
    and macOS also need 'Wake on LAN' enabled in the BIOS/NIC settings - see README."""
    try:
        if OS == "Linux" and shutil.which("ethtool"):
            for dev in os.listdir("/sys/class/net"):
                if os.path.exists(f"/sys/class/net/{dev}/device"): sh(["ethtool", "-s", dev, "wol", "g"])
        elif OS == "Windows":
            sh(["powershell", "-NoProfile", "-Command",
                "Get-NetAdapter -Physical | ForEach-Object { Set-NetAdapterPowerManagement -Name $_.Name -WakeOnMagicPacket Enabled }"])
        elif OS == "Darwin": sh(["pmset", "-a", "womp", "1"])
    except Exception as e: log(f"WoL setup skipped: {e}")

def a_thumb(p):
    jpg, w, h = shrink(capture(), int(p.get("width", 320))); return {"jpg": b64(jpg), "w": w, "h": h}

def a_lock(p):
    if OS == "Linux": must(sh(["loginctl", "lock-sessions"]), "lock")
    elif OS == "Windows": subprocess.Popen(["rundll32.exe", "user32.dll,LockWorkStation"])
    else: must(sh(["pmset", "displaysleepnow"]), "lock")

def a_message(p):
    t = str(p["text"])[:500]
    if OS == "Linux": sh(as_user(["notify-send", "-u", "critical", "Message from your instructor", t]))
    elif OS == "Darwin":
        sh(as_user(["osascript", "-e", f'display notification {json.dumps(t)} with title "Instructor"']))
    else: sh(["msg", "*", t])

def a_openurl(p):
    u = str(p["url"])
    if not re.match(r"^https?://\S+$", u): raise ValueError("http(s) URLs only")
    if OS == "Windows": os.startfile(u)
    else: subprocess.Popen(as_user(["open" if OS == "Darwin" else "xdg-open", u]), stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)

def a_power(p):
    cmds = {"Linux": {"reboot": ["systemctl", "reboot"], "poweroff": ["systemctl", "poweroff"]},
            "Darwin": {"reboot": ["shutdown", "-r", "now"], "poweroff": ["shutdown", "-h", "now"]},
            "Windows": {"reboot": ["shutdown", "/r", "/t", "5"], "poweroff": ["shutdown", "/s", "/t", "5"]}}[OS]
    threading.Timer(1, lambda: subprocess.Popen(cmds[p["mode"]])).start()

def a_net(p):
    block = p["mode"] == "block"
    if OS == "Linux":
        sh(["nft", "delete", "table", "inet", "classroom_fw"])
        if block:
            must(sh(["nft", "-f", "-"], input=
                f'table inet classroom_fw {{ chain out {{ type filter hook output priority 0; policy accept; '
                f'oifname "lo" accept; ip daddr {ADMIN} accept; udp dport {{ 67, 68 }} accept; drop }} }}'), "nft")
    elif OS == "Windows":
        if block:
            sh(["netsh", "advfirewall", "firewall", "delete", "rule", "name=ClassroomAdminOut"])
            must(sh(["netsh", "advfirewall", "firewall", "add", "rule", "name=ClassroomAdminOut", "dir=out",
                     "action=allow", f"remoteip={ADMIN}"]), "netsh")
            must(sh(["netsh", "advfirewall", "set", "allprofiles", "firewallpolicy", "blockinbound,blockoutbound"]), "netsh")
        else:
            sh(["netsh", "advfirewall", "set", "allprofiles", "firewallpolicy", "blockinbound,allowoutbound"])
            sh(["netsh", "advfirewall", "firewall", "delete", "rule", "name=ClassroomAdminOut"])
    else:
        if block:
            rules = (f"pass in quick all\npass out quick on lo0 all\npass out quick to {ADMIN}\n"
                     "pass out quick proto udp from any port 68 to any port 67\nblock drop out all\n")
            must(sh(["pfctl", "-E"]), "pfctl"); must(sh(["pfctl", "-f", "-"], input=rules), "pfctl")
        else: sh(["pfctl", "-f", "/etc/pf.conf"]); sh(["pfctl", "-d"])

def _win_audio(mute):
    """Mute/unmute default speakers and microphone via the Windows Core Audio API (pycaw)."""
    from ctypes import cast, POINTER
    from comtypes import CLSCTX_ALL
    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

    def volume(dev):
        ev = getattr(dev, "EndpointVolume", None)
        if ev is not None: return ev
        iface = dev.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
        return cast(iface, POINTER(IAudioEndpointVolume))

    state = 1 if mute else 0
    volume(AudioUtilities.GetSpeakers()).SetMute(state, None)
    try: volume(AudioUtilities.GetMicrophone()).SetMute(state, None)
    except Exception: pass

def a_audio(p):
    mute = p["mode"] == "mute"
    if OS == "Linux":
        sh(as_user(["pactl", "set-sink-mute", "@DEFAULT_SINK@", "1" if mute else "0"]))
        sh(as_user(["pactl", "set-source-mute", "@DEFAULT_SOURCE@", "1" if mute else "0"]))
    elif OS == "Darwin":
        sh(as_user(["osascript", "-e", f"set volume output muted {'true' if mute else 'false'}"]))
        sh(as_user(["osascript", "-e", f"set volume input volume {0 if mute else 75}"]))
    else:
        _win_audio(mute)

def a_webcam(p):
    off = p["mode"] == "off"
    if OS == "Linux":
        if off:
            sh(["modprobe", "-r", "uvcvideo"])
            open("/etc/modprobe.d/classroom-webcam.conf", "w").write("blacklist uvcvideo\ninstall uvcvideo /bin/false\n")
        else:
            if os.path.exists("/etc/modprobe.d/classroom-webcam.conf"): os.remove("/etc/modprobe.d/classroom-webcam.conf")
            sh(["modprobe", "uvcvideo"])
    elif OS == "Windows":
        verb = "Disable" if off else "Enable"
        must(sh(["powershell", "-NoProfile", "-Command",
                 f"Get-PnpDevice -Class Camera,Image | {verb}-PnpDevice -Confirm:$false"]), "pnp")
    else: raise RuntimeError("macOS webcam control requires MDM (Privacy Preferences profile)")

def a_usb(p):
    block = p["mode"] == "block"
    if OS == "Linux":
        conf = "/etc/modprobe.d/classroom-usb.conf"
        if block:
            open(conf, "w").write("install usb-storage /bin/false\n"); sh(["modprobe", "-r", "usb_storage"])
        else:
            if os.path.exists(conf): os.remove(conf)
            sh(["modprobe", "usb_storage"])
    elif OS == "Windows":
        must(sh(["reg", "add", r"HKLM\SYSTEM\CurrentControlSet\Services\USBSTOR", "/v", "Start",
                 "/t", "REG_DWORD", "/d", "4" if block else "3", "/f"]), "reg")
    else: raise RuntimeError("macOS USB control requires MDM")

_last_notice = [0]
def a_input(p):
    if time.time() - _last_notice[0] > 300:
        _last_notice[0] = time.time(); a_message({"text": "Your instructor is now controlling this computer."})
    k = p["kind"]; x, y = int(p.get("x", 0)), int(p.get("y", 0)); t = str(p.get("text", ""))
    # Wheel notches: pyautogui's scroll()/hscroll() take "clicks" - one X11/macOS line each, but
    # on Windows the unit is 1/120th of a notch, so a bare 1 would be an invisible nudge.
    dy = max(-50, min(50, int(p.get("dy", 0)))); dx = max(-50, min(50, int(p.get("dx", 0))))
    unit = 120 if OS == "Windows" else 1
    code = {"click": f"pyautogui.click({x},{y})", "dblclick": f"pyautogui.doubleClick({x},{y})",
            "rclick": f"pyautogui.rightClick({x},{y})", "move": f"pyautogui.moveTo({x},{y})",
            "scroll": f"pyautogui.moveTo({x},{y});pyautogui.scroll({dy * unit});pyautogui.hscroll({dx * unit}) if {dx} else None",
            "type": f"pyautogui.write({t!r},interval=0.02)", "key": f"pyautogui.press({t!r})"}[k]
    must(sh(as_user([sys.executable, "-c", "import pyautogui;pyautogui.FAILSAFE=False;" + code]), 10), "input")

def a_show(p):
    open(SHOW_FILE, "wb").write(base64.b64decode(p["jpg"])); start_ui("show", SHOW_FILE)

def a_show_stop(p):
    if os.path.exists(SHOW_FILE): os.remove(SHOW_FILE)

def a_indicator(p):
    if p.get("on"):
        open(IND_FLAG, "w").close(); pr = start_ui("ind", IND_FLAG); time.sleep(1.5)
        if pr.poll() is not None:
            os.remove(IND_FLAG); raise RuntimeError("could not show recording indicator; not recording")
    elif os.path.exists(IND_FLAG): os.remove(IND_FLAG)

def _name(p):
    n = os.path.basename(str(p.get("name", "")))
    if not n or n.startswith("."): raise ValueError("bad file name")
    return n

def a_put(p):
    path = os.path.join(SHARE, "handout", _name(p)); open(path, "wb").write(base64.b64decode(p["data"]))
    try: os.chmod(path, 0o644)
    except OSError: pass

def a_ls(p): return {"files": [f for f in os.listdir(os.path.join(SHARE, "handin")) if not f.startswith(".")]}
def a_get(p): return {"data": b64(open(os.path.join(SHARE, "handin", _name(p)), "rb").read())}

ACTIONS = {k[2:]: v for k, v in globals().items() if k.startswith("a_")}

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code)
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        try:
            body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
            t = self.headers.get("X-Time", "")
            good = hmac.new(SECRET, (t + self.path).encode() + body, hashlib.sha256).hexdigest()
            src = self.client_address[0]
            if ADMIN not in ("", "*") and src != ADMIN:
                log(f"REJECT {self.path} from {src}: expected admin_ip {ADMIN} (edit /etc/classroom/config.json "
                    f"and agent.json on every enrolled client if the server's real LAN IP differs from this)")
                return self._send(403, {"error": "forbidden"})

            # The signature covers the CALLER's own timestamp (t), not this machine's clock, so
            # whether it matches depends only on whether SECRET (this agent.json) is the same
            # one baked into the admin server's /etc/classroom/config.json at the time this
            # client was enrolled - it is completely independent of clock skew. Keeping these as
            # one generic "auth failed" made the two very different fixes (re-enroll this
            # machine vs. fix its clock) indistinguishable from the admin UI, so split them.
            if not hmac.compare_digest(self.headers.get("X-Sig", ""), good):
                log(f"REJECT {self.path} from {src}: signature mismatch - this client's secret (in "
                    f"{CFG_PATH}) doesn't match the admin server's /etc/classroom/config.json. Re-run this "
                    f"machine's install/enrollment command to pick up the current secret.")
                return self._send(403, {"error": "signature mismatch - this client's secret is out of date; "
                                                  "re-enroll this machine"})
            try: skew = abs(time.time() - float(t))
            except ValueError: skew = float("inf")
            if skew > 90:
                log(f"REJECT {self.path} from {src}: clock skew {skew:.1f}s - this machine's clock/timezone is "
                    f"off; sync it (enable Windows Time / ntpd) and try again")
                return self._send(403, {"error": f"clock skew {skew:.0f}s - sync this machine's clock"})
            fn = ACTIONS.get(self.path[1:])
            if not fn: return self._send(404, {"error": "unknown action"})
            self._send(200, fn(json.loads(body or b"{}") or {}) or {"ok": True})
        except Exception as e:
            log(f"ERROR {self.path}: {e}")
            self._send(500, {"error": str(e)})

def discovery():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("", DPORT))
    while True:
        d, a = s.recvfrom(64)
        if d.strip() == b"CLASSROOM?":
            try: s.sendto(json.dumps(a_info({})).encode(), a)
            except Exception: pass

if __name__ == "__main__":
    log(f"START hostname={socket.gethostname()} os={OS} port={PORT} discovery_port={DPORT} "
        f"expecting admin at {ADMIN} - log file is {LOGF}")
    threading.Thread(target=enable_wol, daemon=True).start()
    threading.Thread(target=discovery, daemon=True).start()
    ThreadingHTTPServer(("0.0.0.0", PORT), H).serve_forever()