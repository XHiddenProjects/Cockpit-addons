#!/bin/sh
# Network Map for Cockpit: uninstaller
#
#   sudo ./uninstall.sh               remove the system-wide install
#   ./uninstall.sh --user             remove the per-user install
#   ./uninstall.sh --all              remove both (system part needs root)
#   ./uninstall.sh --prefix DIR       remove DIR/network-map (matches install --prefix)
#   ./uninstall.sh --dry-run          show what would be removed
#   ./uninstall.sh --help
#
# Only directories that carry Network Map's own marker file (or its manifest) are removed.
# Packages installed with --deps (nmap, lldpd, ...) are left alone because other things may use them.
# Saved labels and notes live in your browser's local storage; clear them with the
# "Clear saved data" button inside Network Map before uninstalling if you want them gone.

set -eu

NAME="network-map"
MODE=""
PREFIX=""
DRY=0

say()  { printf '%s\n' "$*"; }
info() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mwarning:\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 1; }
usage() { sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
    case "$1" in
        --user)     MODE=user ;;
        --system)   MODE=system ;;
        --all)      MODE=all ;;
        --prefix)   [ $# -ge 2 ] || die "--prefix needs a directory"; PREFIX="$2"; shift ;;
        --prefix=*) PREFIX="${1#--prefix=}" ;;
        --dry-run)  DRY=1 ;;
        -h|--help)  usage; exit 0 ;;
        *)          die "unknown option: $1 (try --help)" ;;
    esac
    shift
done

user_base() {
    if [ "$(id -u)" -eq 0 ] && [ -n "${SUDO_USER:-}" ]; then
        h=$(getent passwd "$SUDO_USER" | cut -d: -f6)
        printf '%s\n' "$h/.local/share/cockpit"
    elif [ -n "${HOME:-}" ]; then
        printf '%s\n' "${XDG_DATA_HOME:-$HOME/.local/share}/cockpit"
    fi
}

remove_one() {
    dir="$1/$NAME"
    if [ ! -e "$dir" ]; then say "   not installed: $dir"; return 1; fi
    if [ ! -f "$dir/.installed-by-network-map-installer" ] && ! grep -q '"Network Map"' "$dir/manifest.json" 2>/dev/null; then
        warn "$dir does not look like a Network Map install; leaving it alone."
        return 1
    fi
    info "Removing $dir"
    if [ "$DRY" -eq 1 ]; then say "   [dry-run] rm -rf $dir"; else rm -rf "$dir"; fi
    return 0
}

targets=""
if [ -n "$PREFIX" ]; then
    targets="$PREFIX"
else
    if [ -z "$MODE" ]; then
        if [ "$(id -u)" -eq 0 ]; then MODE=system; else MODE=user; fi
    fi
    case "$MODE" in
        system) targets="/usr/share/cockpit" ;;
        user)   targets=$(user_base) ;;
        all)    targets="/usr/share/cockpit
$(user_base)" ;;
    esac
    case "$MODE" in system|all)
        if [ "$(id -u)" -ne 0 ] && [ -e "/usr/share/cockpit/$NAME" ]; then
            [ "$MODE" = system ] && die "removing the system-wide install needs root. Re-run with sudo."
            warn "skipping /usr/share/cockpit/$NAME (needs root)."
            targets=$(user_base)
        fi ;;
    esac
fi

removed=0
OLDIFS=$IFS
IFS='
'
for base in $targets; do
    [ -n "$base" ] || continue
    if remove_one "$base"; then removed=$((removed + 1)); fi
done
IFS=$OLDIFS

if [ "$removed" -eq 0 ]; then
    say "Nothing was removed."
else
    info "Done. Reload Cockpit in your browser; the Network Map entry will disappear."
fi
say "   Packages installed with --deps (nmap, lldpd, traceroute, snmp) were not touched."
say "   Saved labels/notes remain in your browser until you clear site data for Cockpit."
