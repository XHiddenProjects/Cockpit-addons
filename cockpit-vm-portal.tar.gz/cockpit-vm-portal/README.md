# VM Portal for Cockpit

A VM manager plus a guest portal for Cockpit. It adds a **VM Portal** page where you can:

* **Manage VMs**: create them from an uploaded ISO / OVA / QCOW2 / VMDK / VDI / VHD(X) / IMG / RAW (no need for
  Cockpit's Virtual Machines page), start, shut down, reboot, pause, force off, open a browser console, edit CPU/RAM,
  attach ISOs, snapshot, autostart, delete. VMs created in Cockpit show up too.
* **Share VMs with outsiders**: turn a shut-off VM into a template, create invite links (limited or unlimited in time
  and launches, optional password) and send them out. Each visitor gets their own private, isolated, auto-expiring copy
  they use in a browser, without touching the original VM, the host, or each other.
* **Configure everything in the GUI**: ports, TLS, limits, guest network. No config files to edit.

```
 visitor ──► portal  :8480  (invite link, launch progress, start / stop / reset)
        └──► noVNC   :6080  (console via per-session one-time token) ──► 127.0.0.1:59xx ──► guest VM
 you ─────► Cockpit ► VM Portal   (VMs, images, templates, invites, live sessions, settings, uninstall)
```

## Install / uninstall

```bash
sudo ./install.sh                       # install or upgrade
sudo vm-portal-uninstall                # remove the software, keep settings, templates, images, your VMs
sudo vm-portal-uninstall --purge        # remove everything, including data, VMs created here, guest network
```
The same two options are in the page: **Settings → Remove VM Portal → Uninstall…**.
Packages (cockpit, libvirt, novnc, …) and VMs created in Cockpit are never removed.

## Typical flow

1. **Images → Upload image** (ISO to install an OS, or an OVA / disk image to import). Large files upload in chunks
   with a progress bar; OVA/VMDK/VDI/VHD(X)/RAW are converted to QCOW2 with progress.
2. **Virtual machines → Create VM** (blank disk + ISO, or from an imported disk). Open the **Console** to install the OS.
3. Shut the VM down → **⋮ → Make template for guests…** Choose CPU, RAM, session length, disk write limit, IOPS.
   The disk is cloned once into a read-only golden image (progress shown).
4. **Invite links → New invite link**. Tick *Never expires* and/or *Unlimited launches* if you want an open link.
5. **Live sessions** shows running guests; ended sessions disappear. **End** deletes a guest immediately.

## How a visitor's VM is contained

| Concern | What happens |
|---|---|
| Original VM | Never touched. Its disk is cloned once into a read-only golden image. |
| Other users | Each guest gets its own copy-on-write overlay, new UUID/MAC/NVRAM. Guest NICs use libvirt port isolation. |
| The host | No host devices, shared folders, extra disks or CD-ROMs. VNC is bound to `127.0.0.1` with its own password and reached only through the token proxy. nftables blocks guests from every host port except DHCP/DNS. |
| Your LAN | nftables drops guest traffic to private/link-local ranges (internet only) and blocks outbound SMTP. |
| Resources | Per-template vCPU/RAM, low CPU shares, IOPS cap, disk-write quota (VM force-stopped when exceeded), global cap on concurrent guests. |
| Lifetime | Sessions expire (extendable a limited number of times) and are destroyed with all their data; orphans are cleaned up. |
| Abuse | Rate limits on launches and probes per IP. Invite links can be revoked. |

Deleting a **template** ends its guests, removes its invite links, its golden image and leftover files. The shared
`vmportal` libvirt network is deliberately kept: all templates use it, and an idle network uses no resources.

## Exposing it to the internet (read this)

* **Use TLS** (Settings → Encryption), or terminate TLS in a reverse proxy for ports 8480 and 6080 and tick
  *Behind a reverse proxy*. Console URLs carry a token and VNC password; invite links carry a secret.
* The certificate and key files must be readable by the services (the console proxy runs unprivileged).
* **Do not expose Cockpit (9090) publicly** unless you already do. Visitors only need 8480 and 6080.
* Set **Maximum guest VMs** to fit your RAM; the Overview page shows a capacity check.
* Keep QEMU/libvirt/kernel patched, and do not template VMs that contain secrets: every visitor boots a copy.

## Notes and limits

* Template VMs need a file-backed disk and must be shut off.
* Browser console is VNC. VMs using SPICE (some Cockpit-made VMs) open in Cockpit's own console instead.
* Windows installers have no VirtIO drivers: the *Windows* option in Create VM picks SATA + e1000e for you.
* Uploaded images are checked (type, no backing files) and converted; the original upload is discarded after import.
* The config file `/etc/vm-portal/config.json` is world-readable on purpose (the unprivileged console proxy reads it)
  and holds no secrets. If you ever see *permission denied* for it: `chmod 644 /etc/vm-portal/config.json`.
* SELinux/AppArmor: libvirt labels disks referenced by a VM automatically; images live under `/var/lib/vm-portal`.

## Layout

```
backend/vmportal.py          engine: VM manager, jobs/progress, uploads, templates, invites, guest sessions, HTTP, CLI
cockpit/vm-portal/           Cockpit admin page (follows Cockpit's light/dark theme)
web/                         visitor-facing portal page
deploy/                      systemd units, nftables rules, libvirt network, default config
install.sh  uninstall.sh
```
