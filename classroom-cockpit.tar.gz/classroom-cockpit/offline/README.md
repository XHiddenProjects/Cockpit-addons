# Running the classroom fully offline

The admin host (the one running Cockpit) can be online or offline - it only
needs to reach the student machines over the LAN. The student machines never
need internet at all once their offline bundles are prepared.

1. On an internet-connected machine matching each client OS, run:
   - `prepare-wheelhouse.sh linux` (on matching Linux distro/arch)
   - `prepare-wheelhouse.sh macos` (on a Mac)
   - `prepare-wheelhouse.ps1` (on Windows, same Python version as clients)
   - `prepare-linux-packages.sh` (on the exact Linux distro/release your lab uses)

2. Copy every resulting `*.tar.gz` into `/usr/share/classroom/offline/` on
   the admin host.

3. `systemctl restart classroom-downloads` on the admin host (or just run
   `admin-install.sh` again - it's idempotent).

4. Run the normal install one-liners on each student machine
   (`curl .../install-linux.sh | sudo bash`, etc.). They'll detect the
   offline bundles automatically and never touch the internet. If a bundle
   is missing for an OS, the installer prints a warning and falls back to
   an online install for that machine only.

Re-run step 1 whenever you change which packages the agent needs, or want
to refresh versions.