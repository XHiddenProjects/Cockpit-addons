# Run on an internet-connected Windows x64 box with the same Python version
# you'll have on student machines, then copy wheelhouse-windows.tar.gz to the
# admin server's /usr/share/classroom/offline/.
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$requirements = Join-Path $here "requirements-wheelhouse.txt"
if (-not (Test-Path $requirements)) {
  throw "Missing dependency manifest: $requirements"
}
if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
  Invoke-WebRequest "https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe" -OutFile "$here\python-installer.exe"
  Write-Host "Install python-installer.exe on this packaging PC, then re-run this script."
  exit
}
$w = Join-Path $here "wheelhouse"
if (Test-Path $w) {
  Remove-Item -Recurse -Force $w
}
New-Item -Force -ItemType Directory $w | Out-Null
Copy-Item $requirements (Join-Path $w "requirements-wheelhouse.txt") -Force
python -m pip wheel --wheel-dir $w --requirement $requirements
if ($LASTEXITCODE -ne 0) {
  throw "pip could not build or download every required wheel. Check the Python/platform compatibility and the error above."
}

# `pip wheel` builds wheels for source-only packages and downloads wheels matching
# THIS machine's exact Python minor version and
# bitness (e.g. a pillow wheel built for cp312-win_amd64 is useless to a cp311 or
# 32-bit Python). If the student machines don't match, `pip install --no-index
# --find-links` on them will find this file sitting right there and still refuse it as
# incompatible - which reads exactly like "pip can't find pillow" even though the file
# is present. Recording what this was actually built for lets install-windows.ps1
# catch that mismatch up front instead of failing with a confusing pip error.
$builtFor = & python -c "import sys,struct; print(f'{sys.version_info.major}.{sys.version_info.minor}-{struct.calcsize(chr(80))*8}bit')"
Set-Content -Path (Join-Path $w "python-version.txt") -Value $builtFor -NoNewline
tar -czf "$here\wheelhouse-windows.tar.gz" -C $w .
Write-Host "Built wheelhouse-windows.tar.gz for Python $builtFor."
Write-Host "Copy it to /usr/share/classroom/offline/ on the admin server."
Write-Host "IMPORTANT: every student Windows machine's 'python' must be this same version and bitness, or pip will reject these wheels as incompatible despite them being in the bundle."