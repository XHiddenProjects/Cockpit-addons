#!/usr/bin/env python3
"""
inventory_cli.py - talks to the inventory server's admin API on behalf of
the Cockpit page.

Run as root via cockpit.spawn (superuser: "require"), so it can read the
admin token from a root-only config file - the browser/JS side never
needs to know any secret at all, the same pattern used for the Samba AD DC
module's local-root database access.

Usage:
  inventory_cli.py dashboard
  inventory_cli.py agents
  inventory_cli.py agent <agent_id>
  inventory_cli.py agent-delete <agent_id>
  inventory_cli.py agent-revoke <agent_id>
  inventory_cli.py agent-tags <agent_id> <json-array-of-tags>
  inventory_cli.py jobs
  inventory_cli.py job <job_id>
  inventory_cli.py jobs-clear
  inventory_cli.py job-cancel <job_id> [--agent <agent_id>] [--force]
  inventory_cli.py jobs-cancel-all [--force]
  inventory_cli.py job-rerun <job_id>
  inventory_cli.py create-job   (reads a JSON body from stdin)
  inventory_cli.py enrollment-keys
  inventory_cli.py create-enrollment-key   (reads a JSON body from stdin)
  inventory_cli.py delete-enrollment-key <key_hash>
  inventory_cli.py files
  inventory_cli.py delete-file <file_id>
  inventory_cli.py app-status
  inventory_cli.py uninstall-agents [--wait SECONDS] [--plain]
                                (queues the agent uninstaller on every enrolled host)
  inventory_cli.py uninstall-server [--purge]
                                (starts the detached server + dashboard removal)
  inventory_cli.py upload-file <filename> <platform> <label> <silent_args>
                                (reads raw file bytes from stdin)

Always prints one JSON object to stdout: {"ok": true, "data": ...} or
{"ok": false, "error": "..."} - so the Cockpit-side JS never has to parse
partial/garbled output.
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from urllib import request as urlrequest
from urllib.error import HTTPError, URLError

CONFIG_PATH = Path("/etc/inventory-server/server.env")


def load_config() -> dict:
    cfg = {"INVENTORY_SERVER_URL": "http://127.0.0.1:8787", "INVENTORY_ADMIN_TOKEN": ""}
    if CONFIG_PATH.exists():
        for line in CONFIG_PATH.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            cfg[k.strip()] = v.strip().strip('"').strip("'")
    return cfg


def call(method: str, path: str, body=None):
    cfg = load_config()
    url = cfg["INVENTORY_SERVER_URL"].rstrip("/") + path
    data = json.dumps(body).encode() if body is not None else None
    req = urlrequest.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {cfg['INVENTORY_ADMIN_TOKEN']}")
    with urlrequest.urlopen(req, timeout=15) as resp:
        raw = resp.read()
        return json.loads(raw) if raw else {}


def call_binary(method: str, path: str, data: bytes, headers: dict, timeout: int = 600):
    cfg = load_config()
    url = cfg["INVENTORY_SERVER_URL"].rstrip("/") + path
    req = urlrequest.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/octet-stream")
    req.add_header("Authorization", f"Bearer {cfg['INVENTORY_ADMIN_TOKEN']}")
    for k, v in headers.items():
        req.add_header(k, v)
    with urlrequest.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        return json.loads(raw) if raw else {}


AGENT_UNINSTALL_SCRIPTS = {
    "linux": ("uninstall.sh", "bash", "Linux"),
    "macos": ("uninstall-macos.sh", "bash", "macOS"),
    "windows": ("uninstall.ps1", "powershell", "Windows"),
}
AGENT_UNINSTALL_DELAY = 20   # seconds; lets the agent report the job result before it is removed
ACTIVE_STATUSES = ("pending", "running", "cancelling")


def install_dir() -> Path:
    return Path(load_config().get("INVENTORY_INSTALL_DIR") or "/opt/inventory-server")


def agent_uninstall_script(os_name: str):
    """Returns (script_text, interpreter) for one OS, read from the server's own install_scripts dir."""
    filename, interpreter, _label = AGENT_UNINSTALL_SCRIPTS[os_name]
    path = install_dir() / "server" / "install_scripts" / filename
    if not path.is_file():
        raise FileNotFoundError(f"{path} is missing - re-run scripts/install-server.sh from the new release.")
    text = path.read_text()
    if interpreter == "powershell":
        text += f"\nUninstall-InventoryAgent -DelaySeconds {AGENT_UNINSTALL_DELAY}\n"
    else:
        head, _, rest = text.partition("\n")
        text = f"{head}\nexport INVENTORY_UNINSTALL_DELAY={AGENT_UNINSTALL_DELAY}\n{rest}"
    return text, interpreter


def queue_agent_uninstall() -> list:
    """Creates one uninstall job per OS targeting every enrolled (non-revoked) agent of that OS."""
    agents = call("GET", "/api/admin/agents").get("agents", [])
    jobs = []
    for os_name, (_f, _i, label) in AGENT_UNINSTALL_SCRIPTS.items():
        ids = [a["id"] for a in agents if a.get("os") == os_name]
        if not ids:
            continue
        script, interpreter = agent_uninstall_script(os_name)
        resp = call("POST", "/api/admin/jobs", {
            "name": f"Uninstall inventory agent ({label})",
            "job_type": "script", "script": script, "interpreter": interpreter,
            "target_agent_ids": ids, "timeout_seconds": 120,
        })
        jobs.append({"job_id": resp["job_id"], "os": os_name, "label": label, "count": len(ids)})
    return jobs


def wait_for_jobs(jobs: list, seconds: int, plain: bool) -> bool:
    """Polls until every run is finished or the time is up. Returns True if all succeeded."""
    deadline = time.monotonic() + seconds
    while True:
        results = []
        for j in jobs:
            results += call("GET", f"/api/admin/jobs/{j['job_id']}").get("results", [])
        active = [r for r in results if r["status"] in ACTIVE_STATUSES]
        if not active or time.monotonic() >= deadline:
            break
        time.sleep(5)
    ok = sum(1 for r in results if r["status"] == "success")
    failed = [r for r in results if r["status"] not in ("success",) + ACTIVE_STATUSES]
    if plain:
        print(f"Agents uninstalled: {ok}/{len(results)}")
        for r in failed:
            print(f"  FAILED  {r.get('agent_hostname') or r['agent_id']}: {r['status']}")
        for r in active:
            print(f"  PENDING {r.get('agent_hostname') or r['agent_id']} (offline? it never picked the job up)")
    return not failed and not active


def server_status() -> dict:
    cfg = load_config()
    out = {"install_dir": str(install_dir()), "dashboard_dir": str(Path(__file__).resolve().parent)}
    if shutil.which("systemctl"):
        r = subprocess.run(["systemctl", "is-active", "inventory-server.service"], capture_output=True, text=True)
        out["service_state"] = r.stdout.strip() or "unknown"
    else:
        out["service_state"] = "unknown"
    db_path = cfg.get("INVENTORY_DB")
    out["db_path"] = db_path
    out["db_bytes"] = os.path.getsize(db_path) if db_path and os.path.exists(db_path) else None
    out["uninstaller_present"] = (install_dir() / "scripts" / "uninstall-server.sh").is_file()
    out["agent_scripts_present"] = all(
        (install_dir() / "server" / "install_scripts" / f[0]).is_file() for f in AGENT_UNINSTALL_SCRIPTS.values())
    out["server_url"] = cfg["INVENTORY_SERVER_URL"]
    try:
        agents = call("GET", "/api/admin/agents").get("agents", [])
        out["agents"] = {
            "total": len(agents),
            "online": sum(1 for a in agents if a.get("online")),
            "by_os": {k: sum(1 for a in agents if a.get("os") == k) for k in AGENT_UNINSTALL_SCRIPTS},
        }
    except Exception as e:  # server down: the uninstaller must still be usable
        out["agents"] = None
        out["agents_error"] = str(e)
    return out


def start_server_uninstall(purge: bool) -> dict:
    script = install_dir() / "scripts" / "uninstall-server.sh"
    if not script.is_file():
        raise FileNotFoundError(f"{script} is missing - re-run scripts/install-server.sh from the new release, or run uninstall-server.sh from the release directory.")
    log = "/var/log/inventory-uninstall.log"
    cmd = ["bash", str(script), "--yes", "--delay", "5", "--log", log] + (["--purge"] if purge else [])
    if shutil.which("systemd-run") and os.path.isdir("/run/systemd/system"):
        # own cgroup: survives the inventory-server service and the Cockpit session going away
        subprocess.run(["systemd-run", "--quiet", "--collect", "--no-block",
                        "--unit=inventory-server-uninstall"] + cmd, check=True)
    else:
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    return {"started": True, "log": log, "purge": purge}


def output(ok: bool, data=None, error: str = ""):
    print(json.dumps({"ok": ok, "data": data, "error": error}))


def main():
    if len(sys.argv) < 2:
        output(False, error="No subcommand given")
        sys.exit(1)
    cmd = sys.argv[1]
    args = sys.argv[2:]

    try:
        if cmd == "dashboard":
            output(True, call("GET", "/api/admin/dashboard"))
        elif cmd == "agents":
            output(True, call("GET", "/api/admin/agents"))
        elif cmd == "agent":
            output(True, call("GET", f"/api/admin/agents/{args[0]}"))
        elif cmd == "agent-delete":
            output(True, call("DELETE", f"/api/admin/agents/{args[0]}"))
        elif cmd == "agent-revoke":
            output(True, call("POST", f"/api/admin/agents/{args[0]}/revoke"))
        elif cmd == "agent-tags":
            tags = json.loads(args[1])
            output(True, call("POST", f"/api/admin/agents/{args[0]}/tags", {"tags": tags}))
        elif cmd == "jobs":
            output(True, call("GET", "/api/admin/jobs"))
        elif cmd == "job":
            output(True, call("GET", f"/api/admin/jobs/{args[0]}"))
        elif cmd == "jobs-clear":
            output(True, call("DELETE", "/api/admin/jobs"))
        elif cmd == "job-cancel":
            # job-cancel <job_id> [--agent <agent_id>] [--force]
            body = {"force": "--force" in args, "agent_id": None}
            if "--agent" in args:
                body["agent_id"] = args[args.index("--agent") + 1]
            output(True, call("POST", f"/api/admin/jobs/{args[0]}/cancel", body))
        elif cmd == "jobs-cancel-all":
            output(True, call("POST", "/api/admin/jobs/cancel-all", {"force": "--force" in args}))
        elif cmd == "job-rerun":
            output(True, call("POST", f"/api/admin/jobs/{args[0]}/rerun"))
        elif cmd == "create-job":
            body = json.loads(sys.stdin.read())
            output(True, call("POST", "/api/admin/jobs", body))
        elif cmd == "enrollment-keys":
            output(True, call("GET", "/api/admin/enrollment-keys"))
        elif cmd == "create-enrollment-key":
            body = json.loads(sys.stdin.read())
            output(True, call("POST", "/api/admin/enrollment-keys", body))
        elif cmd == "delete-enrollment-key":
            output(True, call("DELETE", f"/api/admin/enrollment-keys/{args[0]}"))
        elif cmd == "files":
            output(True, call("GET", "/api/admin/files"))
        elif cmd == "delete-file":
            output(True, call("DELETE", f"/api/admin/files/{args[0]}"))
        elif cmd == "upload-file":
            filename, platform_, label, silent_args = args[0], args[1], args[2], args[3]
            raw = sys.stdin.buffer.read()
            headers = {
                "X-Filename": filename,
                "X-Platform": platform_,
                "X-Label": label,
                "X-Silent-Args": silent_args,
            }
            output(True, call_binary("POST", "/api/admin/files", raw, headers))
        elif cmd == "app-status":
            output(True, server_status())
        elif cmd == "uninstall-agents":
            jobs = queue_agent_uninstall()
            all_ok = True
            if "--wait" in args:
                plain = "--plain" in args
                if plain:
                    print(f"Queued the agent uninstaller on {sum(j['count'] for j in jobs)} host(s); waiting for them to check in ...")
                all_ok = wait_for_jobs(jobs, int(args[args.index("--wait") + 1]), plain)
            if "--plain" in args:
                sys.exit(0 if all_ok else 3)
            output(True, {"jobs": jobs})
        elif cmd == "uninstall-server":
            output(True, start_server_uninstall("--purge" in args))
        elif cmd == "config-status":
            cfg = load_config()
            output(True, {
                "server_url": cfg["INVENTORY_SERVER_URL"],
                "has_token": bool(cfg["INVENTORY_ADMIN_TOKEN"]),
                "config_path_exists": CONFIG_PATH.exists(),
            })
        else:
            output(False, error=f"Unknown subcommand: {cmd}")
            sys.exit(1)
    except HTTPError as e:
        try:
            detail = json.loads(e.read()).get("detail", str(e))
        except Exception:
            detail = str(e)
        output(False, error=f"HTTP {e.code}: {detail}")
        sys.exit(1)
    except URLError as e:
        output(False, error=f"Could not reach inventory server: {e.reason}. Check {CONFIG_PATH}.")
        sys.exit(1)
    except FileNotFoundError:
        output(False, error=f"No config at {CONFIG_PATH}. Run the server installer first.")
        sys.exit(1)
    except Exception as e:
        output(False, error=f"{type(e).__name__}: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
