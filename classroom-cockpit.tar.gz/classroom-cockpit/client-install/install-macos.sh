#!/usr/bin/env bash
set -euo pipefail

# ---- EDIT THESE TWO LINES ----
ADMIN_IP="10.200.0.10"
DLPORT="11099"
# -------------------------------

[ "$(id -u)" = 0 ] || { echo "Run with sudo: curl -fsSL http://$ADMIN_IP:$DLPORT/install-macos.sh | sudo bash"; exit 1; }
command -v python3 >/dev/null || { echo "Install Python 3 first (offline .pkg from python.org, or an admin-prepared installer)."; exit 1; }
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT

if curl -fsSL -o "$T/wheelhouse.tar.gz" "http://$ADMIN_IP:$DLPORT/wheelhouse-macos.tar.gz" 2>/dev/null && [ -s "$T/wheelhouse.tar.gz" ]; then
  mkdir -p "$T/wheelhouse"; tar xzf "$T/wheelhouse.tar.gz" -C "$T/wheelhouse"
  if [ -f "$T/wheelhouse/requirements-wheelhouse.txt" ]; then
    python3 -m pip install --no-index --find-links "$T/wheelhouse" -r "$T/wheelhouse/requirements-wheelhouse.txt"
  else
    python3 -m pip install --no-index --find-links "$T/wheelhouse" pillow pyautogui
  fi
else
  echo "No offline wheelhouse-macos.tar.gz on admin server - trying internet pip install."
  echo "(Prepare one with offline/prepare-wheelhouse.sh on a connected Mac if this machine has no internet.)"
  python3 -m pip install --upgrade pillow pyautogui
fi

curl -fsSL "http://$ADMIN_IP:$DLPORT/agent-bundle.tar.gz" -o "$T/b.tar.gz"
mkdir -p "$T/b"; tar xzf "$T/b.tar.gz" -C "$T/b"
mkdir -p /usr/local/classroom-agent /usr/local/etc/classroom
install -m755 "$T/b/classroom_agent.py" /usr/local/classroom-agent/
install -m600 "$T/b/agent.json" /usr/local/etc/classroom/agent.json

cat > /Library/LaunchDaemons/org.classroom.agent.plist <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>org.classroom.agent</string>
<key>ProgramArguments</key><array><string>$(command -v python3)</string><string>/usr/local/classroom-agent/classroom_agent.py</string></array>
<key>RunAtLoad</key><true/><key>KeepAlive</key><true/>
</dict></plist>
EOF

launchctl bootout system /Library/LaunchDaemons/org.classroom.agent.plist 2>/dev/null || true
launchctl bootstrap system /Library/LaunchDaemons/org.classroom.agent.plist
echo "Done. Grant Screen Recording + Accessibility to python3 in System Settings > Privacy & Security (or push a PPPC profile via MDM)."