#!/usr/bin/python3
"""
User attribute editor for the Samba AD DC Cockpit module.

Reads one JSON request on stdin and writes one JSON response on stdout:
  {"cmd": "get",    "username": "alice"}
  {"cmd": "update", "username": "alice", "attrs": {...}, "flags": {...}}

Runs as root and talks to the local sam.ldb through SamDB, so all DSDB modules
run (replication metadata, password/UAC rules), the same as samba-tool does.
"""
import datetime
import json
import sys

# form key -> LDAP attribute. An empty string removes the attribute.
FIELDS = {
    "given": "givenName",
    "initials": "initials",
    "sn": "sn",
    "displayName": "displayName",
    "description": "description",
    "mail": "mail",
    "upn": "userPrincipalName",
    "telephone": "telephoneNumber",
    "mobile": "mobile",
    "title": "title",
    "department": "department",
    "company": "company",
    "office": "physicalDeliveryOfficeName",
    "street": "streetAddress",
    "city": "l",
    "state": "st",
    "postalCode": "postalCode",
    "homeDirectory": "homeDirectory",
    "homeDrive": "homeDrive",
    "profilePath": "profilePath",
    "scriptPath": "scriptPath",
}

UF_ACCOUNTDISABLE = 0x2
UF_DONT_EXPIRE_PASSWD = 0x10000
NEVER_EXPIRES = (0, 9223372036854775807)
EPOCH_DIFF = 11644473600  # seconds between 1601-01-01 and 1970-01-01


def filetime_to_date(v):
    v = int(v or 0)
    if v in NEVER_EXPIRES:
        return ""
    try:
        return (datetime.datetime(1601, 1, 1) + datetime.timedelta(microseconds=v // 10)).strftime("%Y-%m-%d")
    except (OverflowError, ValueError):
        return ""


def date_to_filetime(s):
    d = datetime.datetime.strptime(s, "%Y-%m-%d") + datetime.timedelta(days=1)  # expires at the end of that day
    return int((d - datetime.datetime(1970, 1, 1)).total_seconds() + EPOCH_DIFF) * 10000000


def plan_update(current, attrs, flags):
    """Pure function (unit-testable without Samba).

    current: {ldapAttr: str} of the existing object (only what is set)
    attrs:   {formKey: str}
    flags:   {disabled, neverExpires, mustChange, unlock, expires} (any may be missing)
    -> {ldapAttr: new str value, or None to delete}
    """
    changes = {}
    for key, value in (attrs or {}).items():
        if key not in FIELDS:
            raise ValueError("Unknown field %r" % key)
        value = (value or "").strip()
        if "\n" in value or "\r" in value:
            raise ValueError("%s cannot contain line breaks" % key)
        attr = FIELDS[key]
        if value == (current.get(attr) or ""):
            continue
        changes[attr] = value or None
    flags = flags or {}
    uac = int(current.get("userAccountControl") or 512)
    new = uac
    if "disabled" in flags:
        new = (new | UF_ACCOUNTDISABLE) if flags["disabled"] else (new & ~UF_ACCOUNTDISABLE)
    if "neverExpires" in flags:
        new = (new | UF_DONT_EXPIRE_PASSWD) if flags["neverExpires"] else (new & ~UF_DONT_EXPIRE_PASSWD)
    if new != uac:
        changes["userAccountControl"] = str(new)
    if flags.get("mustChange") is True:
        changes["pwdLastSet"] = "0"
    elif flags.get("mustChange") is False and int(current.get("pwdLastSet") or 1) == 0:
        changes["pwdLastSet"] = "-1"
    if flags.get("unlock"):
        changes["lockoutTime"] = "0"
    if "expires" in flags:
        e = (flags["expires"] or "").strip()
        want = date_to_filetime(e) if e else 0
        have = int(current.get("accountExpires") or 0)
        if (e == "" and have not in NEVER_EXPIRES) or (e != "" and want != have):
            changes["accountExpires"] = str(want if e else 0)
    return changes


def main():
    try:
        req = json.loads(sys.stdin.read() or "{}")
        import ldb
        from samba.auth import system_session
        from samba.param import LoadParm
        from samba.samdb import SamDB

        lp = LoadParm()
        lp.load_default()
        samdb = SamDB(url=lp.samdb_url(), session_info=system_session(lp), lp=lp)
        name = (req.get("username") or "").strip()
        if not name:
            raise ValueError("A username is required")
        wanted = sorted(set(FIELDS.values())) + ["userAccountControl", "pwdLastSet", "accountExpires", "lockoutTime",
                                                  "sAMAccountName", "distinguishedName", "memberOf"]
        res = samdb.search(base=samdb.get_default_basedn(), scope=ldb.SCOPE_SUBTREE, attrs=wanted,
                           expression="(&(objectClass=user)(objectCategory=person)(sAMAccountName=%s))" % ldb.binary_encode(name))
        if not res:
            raise ValueError("User %r not found" % name)
        m = res[0]
        cur = {a: str(m[a][0]) for a in wanted if a in m and a != "memberOf"}

        if req.get("cmd") == "get":
            uac = int(cur.get("userAccountControl") or 512)
            locked = int(cur.get("lockoutTime") or 0) > 0
            out = {"dn": str(m.dn), "fields": {k: cur.get(a, "") for k, a in FIELDS.items()},
                   "flags": {"disabled": bool(uac & UF_ACCOUNTDISABLE), "neverExpires": bool(uac & UF_DONT_EXPIRE_PASSWD),
                             "mustChange": int(cur.get("pwdLastSet") or 1) == 0, "locked": locked,
                             "expires": filetime_to_date(cur.get("accountExpires"))}}
            print(json.dumps({"ok": True, "data": out}))
            return
        if req.get("cmd") == "update":
            changes = plan_update(cur, req.get("attrs"), req.get("flags"))
            if changes:
                msg = ldb.Message()
                msg.dn = m.dn
                for attr, val in changes.items():
                    if val is None:
                        if attr in cur:
                            msg[attr] = ldb.MessageElement([], ldb.FLAG_MOD_DELETE, attr)
                    else:
                        msg[attr] = ldb.MessageElement(val, ldb.FLAG_MOD_REPLACE, attr)
                samdb.modify(msg)
            print(json.dumps({"ok": True, "data": {"changed": sorted(changes)}}))
            return
        raise ValueError("Unknown command")
    except Exception as e:  # noqa: BLE001
        msg = str(e)
        if e.args and isinstance(e.args[0], int) and len(e.args) > 1:  # ldb.LdbError(code, text)
            msg = str(e.args[1])
        print(json.dumps({"ok": False, "error": "%s: %s" % (type(e).__name__, msg)}))


if __name__ == "__main__":
    main()
