/* VM Portal – Cockpit admin page.
 * Talks to the backend through `vmportal call <command>` (JSON in / JSON out) via cockpit.spawn with
 * superuser privileges. Nothing from the backend is ever inserted with innerHTML. */
"use strict";

const BIN = "/usr/lib/vm-portal/vmportal";
const UNINSTALL = "/usr/lib/vm-portal/uninstall.sh";
const CHUNK = 8 * 1024 * 1024;
const ACCEPT = ".iso,.ova,.qcow2,.qcow,.vmdk,.vdi,.vhd,.vhdx,.img,.raw";

const S = { status: null, vms: [], library: [], templates: [], invites: [], sessions: [], jobs: [], config: null };
const uploads = [];
let currentTab = "overview";
let lastJobStates = {};

/* ------------------------------------------------------------------ helpers */
const PROPS = new Set(["value", "checked", "disabled", "selected", "hidden", "multiple", "required", "readOnly"]);
function h(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
        if (v === undefined || v === null || v === false) continue;
        if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
        else if (k === "class") e.className = v;
        else if (k === "style") e.style.cssText = v;   // CSSOM, allowed under Cockpit's CSP
        else if (PROPS.has(k)) e[k] = v;
        else e.setAttribute(k, v === true ? "" : v);
    }
    const add = (k) => {
        if (Array.isArray(k)) k.forEach(add);
        else if (k instanceof Node) e.append(k);
        else if (k !== null && k !== undefined && k !== false) e.append(document.createTextNode(String(k)));
    };
    kids.forEach(add);
    return e;
}
const $ = (id) => document.getElementById(id);

function call(cmd, params) {
    const p = cockpit.spawn([BIN, "call", cmd], { superuser: "require", err: "message" });
    p.input(JSON.stringify(params || {}));
    return p.then((out) => (out.trim() ? JSON.parse(out) : null), (ex) => {
        if (ex.problem === "access-denied" || ex.problem === "not-found") {
            ex.message = ex.problem === "not-found"
                ? "VM Portal backend is not installed (" + BIN + " not found)."
                : "Administrative access is required. Click “Limited access” at the top of Cockpit to turn it on.";
        }
        throw ex;
    });
}

function toast(msg, kind) {
    const t = h("div", { class: "alert toast " + (kind || "ok"), role: "status", onclick: () => t.remove() }, msg);
    $("toasts").append(t);
    if (kind !== "bad") setTimeout(() => t.remove(), 6000);
}
const fail = (ex) => toast((ex && ex.message) || String(ex), "bad");

function fmtBytes(b) {
    if (b === null || b === undefined) return "–";
    const u = ["B", "KB", "MB", "GB", "TB"];
    let i = 0;
    while (b >= 1024 && i < u.length - 1) { b /= 1024; i++; }
    return (b >= 100 || i === 0 ? Math.round(b) : b.toFixed(1)) + " " + u[i];
}
const fmtMB = (mb) => fmtBytes(mb * 1048576);
const fmtTime = (t) => (t ? new Date(t * 1000).toLocaleString() : "Never");
function fmtLeft(t) {
    const s = t - Date.now() / 1000;
    if (s <= 0) return "expiring";
    const d = Math.floor(s / 86400), hh = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60);
    return d ? `${d}d ${hh}h left` : hh ? `${hh}h ${m}m left` : `${m}m left`;
}
const pill = (text, kind) => h("span", { class: "label-pill " + (kind || "plain") }, text);
function bar(pct, kind) {
    const ind = pct === null || pct === undefined;
    return h("div", { class: "progress " + (kind || "") + (ind ? " indet" : ""), role: "progressbar",
        "aria-valuenow": ind ? undefined : Math.round(pct), "aria-valuemin": 0, "aria-valuemax": 100 },
    h("div", { style: ind ? "" : `width:${Math.max(0, Math.min(100, pct))}%` }));
}

function field(label, control, help) {
    return h("label", { class: "field" }, h("span", { class: "l" }, label), control, help ? h("span", { class: "help" }, help) : null);
}
function check(label, checked, help) {
    const input = h("input", { type: "checkbox", checked: !!checked });
    return { input, el: h("label", { class: "field check" }, input, h("div", {}, h("span", { class: "l" }, label), help ? h("div", { class: "help" }, help) : null)) };
}
const num = (v, min, step) => h("input", { type: "number", value: v, min, step: step || 1, required: true });
const text = (v, ph, extra) => h("input", Object.assign({ type: "text", value: v || "", placeholder: ph || "" }, extra || {}));
const select = (opts, val) => {
    const s = h("select", {}, opts.map(([v, l, dis]) => h("option", { value: v, disabled: !!dis }, l)));
    if (val !== undefined) s.value = val;
    return s;
};

/* ------------------------------------------------------------------ dialogs */
const dlg = () => $("dlg");
function closeDlg() { if (dlg().open) dlg().close(); }

function dialog({ title, intro, body, submit, danger, onSubmit, cancel }) {
    const err = h("div", { class: "alert bad", hidden: true });
    const submitBtn = submit ? h("button", { type: "submit", class: danger ? "danger solid" : "primary" }, submit) : null;
    const cancelBtn = h("button", { type: "button", onclick: closeDlg }, cancel || (submit ? "Cancel" : "Close"));
    const form = h("form", { class: "form", novalidate: false, onsubmit: async (ev) => {
        ev.preventDefault();
        if (!onSubmit) return closeDlg();
        err.hidden = true;
        [submitBtn, cancelBtn].forEach((b) => b && (b.disabled = true));
        try {
            const r = await onSubmit();
            if (r !== false) closeDlg();
        } catch (ex) {
            err.textContent = ex.message || String(ex);
            err.hidden = false;
        } finally {
            [submitBtn, cancelBtn].forEach((b) => b && (b.disabled = false));
        }
    } },
    h("div", { class: "dlg-head" }, h("h2", {}, title), intro ? h("p", { class: "muted" }, intro) : null),
    h("div", { class: "dlg-body form" }, err, body),
    h("div", { class: "dlg-foot" }, cancelBtn, submitBtn));
    dlg().replaceChildren(form);
    if (!dlg().open) dlg().showModal();
    const first = form.querySelector("input:not([type=checkbox]):not([type=radio]),select");
    if (first) first.focus();
    return err;
}
function confirmDlg({ title, body, confirm, danger, typed }) {
    return new Promise((resolve) => {
        let done = false;
        const input = typed ? text("", `Type ${typed} to confirm`, { autocomplete: "off" }) : null;
        dialog({ title, body: [h("div", {}, body), input ? field(`Type “${typed}” to confirm`, input) : null],
            submit: confirm || "Confirm", danger,
            onSubmit: () => {
                if (typed && input.value.trim() !== typed) throw new Error(`Please type ${typed} exactly.`);
                done = true;
            } });
        dlg().addEventListener("close", () => resolve(done), { once: true });   // resolve only after it has closed
    });
}
document.addEventListener("close", () => { if (pendingRefresh) refresh(true); }, true);   // <dialog> close events do not bubble
document.addEventListener("click", (ev) => {
    document.querySelectorAll("details.menu[open]").forEach((d) => { if (!d.contains(ev.target)) d.open = false; });
});

/* ------------------------------------------------------------------ activity panel (uploads + background jobs) */
function renderActivity() {
    const box = $("activity");
    const rows = [];
    for (const u of uploads) {
        const pct = (u.sent / u.size) * 100;
        const secs = (Date.now() - u.t0) / 1000;
        const sub = u.state === "uploading"
            ? `Uploading ${fmtBytes(u.sent)} of ${fmtBytes(u.size)}` + (secs > 2 ? ` · ${fmtBytes(u.sent / secs)}/s` : "")
            : u.error || u.state;
        rows.push(h("div", { class: "job" + (u.state === "error" ? " error" : "") },
            h("div", {}, h("div", { class: "t" }, "Upload: " + u.name), h("div", { class: "s" }, sub)),
            bar(u.state === "error" ? 100 : pct, u.state === "error" ? "bad" : ""),
            u.state === "uploading"
                ? h("button", { class: "sm", onclick: () => { u.cancel = true; } }, "Cancel")
                : h("button", { class: "sm", onclick: () => { uploads.splice(uploads.indexOf(u), 1); renderActivity(); } }, "Dismiss")));
    }
    for (const j of S.jobs) {
        const running = j.status === "running" || j.status === "queued";
        if (j.status === "done" && Date.now() / 1000 - j.updated > 8) continue;   // successes fade out by themselves
        const kind = j.status === "error" ? "bad" : j.status === "done" ? "ok" : j.status === "cancelled" ? "warn" : "";
        const sub = j.status === "error" ? j.error : j.status === "done" ? "Completed"
            : j.status === "cancelled" ? "Cancelled" : `${j.step}${j.progress ? ` · ${Math.round(j.progress)}%` : ""}`;
        rows.push(h("div", { class: "job" + (j.status === "error" ? " error" : "") },
            h("div", {}, h("div", { class: "t" }, j.title), h("div", { class: "s" }, sub)),
            bar(running && !j.progress ? null : j.progress, kind),
            running
                ? h("button", { class: "sm", onclick: () => call("job-cancel", { id: j.id }).then(pollJobs, fail) }, "Cancel")
                : h("button", { class: "sm", onclick: () => call("job-dismiss", { id: j.id }).then(pollJobs, fail) }, "Dismiss")));
    }
    box.hidden = rows.length === 0;
    if (rows.length) box.replaceChildren(h("h3", {}, "Activity"), ...rows);
}

let jobTimer = null;
async function pollJobs() {
    clearTimeout(jobTimer);
    try {
        S.jobs = await call("job-list");
    } catch (ex) { S.jobs = []; }
    let reload = false;
    for (const j of S.jobs) {
        const prev = lastJobStates[j.id];
        const fresh = !prev && Date.now() / 1000 - j.updated < 15;   // finished before we ever saw it running
        if ((fresh || (prev && prev !== j.status)) && (j.status === "done" || j.status === "error")) {
            reload = true;
            if (j.status === "done") toast(`${j.title}: completed`, "ok");
        }
        lastJobStates[j.id] = j.status;
    }
    renderActivity();
    if (reload) refresh(true);
    const busy = S.jobs.some((j) => j.status === "running" || j.status === "queued") || uploads.some((u) => u.state === "uploading");
    jobTimer = setTimeout(pollJobs, busy ? 1500 : 8000);
}
const kickJobs = () => pollJobs();

window.addEventListener("beforeunload", (ev) => {
    if (uploads.some((u) => u.state === "uploading")) { ev.preventDefault(); ev.returnValue = ""; }
});

/* ------------------------------------------------------------------ uploads */
function chunkCall(id, offset, data) {
    const p = cockpit.spawn([BIN, "upload-chunk", "--id", id, "--offset", String(offset)],
        { superuser: "require", binary: true, err: "message" });
    p.input(data);
    return p;
}
async function startUpload(file) {
    const u = { name: file.name, size: file.size, sent: 0, state: "uploading", cancel: false, error: "", t0: Date.now() };
    uploads.push(u);
    renderActivity();
    kickJobs();
    try {
        const { id } = await call("upload-begin", { filename: file.name, size: file.size });
        while (u.sent < file.size) {
            if (u.cancel) {
                await call("upload-abort", { id });
                uploads.splice(uploads.indexOf(u), 1);
                renderActivity();
                return;
            }
            const buf = new Uint8Array(await file.slice(u.sent, u.sent + CHUNK).arrayBuffer());
            let off = u.sent, data = buf;
            for (let tries = 0; ; tries++) {
                try { if (data.length) await chunkCall(id, off, data); break; } catch (ex) {
                    if (tries >= 3) throw ex;
                    const st = await call("upload-status", { id });
                    const adv = st.size - off;
                    if (adv < 0 || adv > data.length) throw ex;
                    data = data.subarray(adv);
                    off = st.size;
                }
            }
            u.sent += buf.length;
            renderActivity();
        }
        u.state = "finishing";
        await call("upload-finish", { id });
        uploads.splice(uploads.indexOf(u), 1);
        toast(`${file.name} uploaded. Converting and adding it to the image library…`);
        kickJobs();
    } catch (ex) {
        u.state = "error";
        u.error = ex.message || String(ex);
        renderActivity();
    }
}

function uploadDialog() {
    let file = null;
    const input = h("input", { type: "file", accept: ACCEPT, hidden: true, onchange: () => pick(input.files[0]) });
    const label = h("div", {}, "Drag a file here, or ", h("button", { type: "button", class: "link", onclick: () => input.click() }, "browse"));
    const sub = h("div", { class: "small" }, "ISO installers, OVA appliances, and QCOW2 / VMDK / VDI / VHD / VHDX / IMG / RAW disk images");
    const drop = h("div", { class: "drop", ondragover: (e) => { e.preventDefault(); drop.classList.add("over"); },
        ondragleave: () => drop.classList.remove("over"),
        ondrop: (e) => { e.preventDefault(); drop.classList.remove("over"); pick(e.dataTransfer.files[0]); } }, label, sub, input);
    function pick(f) {
        if (!f) return;
        file = f;
        label.replaceChildren(h("strong", {}, f.name), " · " + fmtBytes(f.size));
    }
    dialog({ title: "Upload an image", intro: "Use this if the VM you want does not exist in Cockpit yet. ISOs are used to install an OS; disk images and OVAs are converted to QCOW2 and become ready-to-run disks.",
        body: [drop, h("p", { class: "muted small" }, "The upload continues in the background while you use the page. Keep this browser tab open until it finishes.")],
        submit: "Upload", onSubmit: () => {
            if (!file) throw new Error("Choose a file first.");
            startUpload(file);
        } });
}

/* ------------------------------------------------------------------ data loading + router */
const TABS = [["overview", "Overview"], ["vms", "Virtual machines"], ["images", "Images"], ["templates", "Templates"],
    ["invites", "Invite links"], ["sessions", "Live sessions"], ["settings", "Settings"]];

const LOAD = {
    overview: async () => { [S.status, S.vms] = await Promise.all([call("status"), call("vm-list")]); },
    vms: async () => { [S.vms, S.status] = await Promise.all([call("vm-list"), S.status ? S.status : call("status")]); },
    images: async () => { S.library = await call("lib-list"); },
    templates: async () => { [S.templates, S.vms] = await Promise.all([call("template-list"), call("vm-list")]); },
    invites: async () => { [S.invites, S.templates, S.status] = await Promise.all([call("invite-list"), call("template-list"), call("status")]); },
    sessions: async () => { S.sessions = await call("session-list"); },
    settings: async () => { [S.config, S.status] = await Promise.all([call("config-get"), call("status")]); },
};
const RENDER = { overview: vOverview, vms: vVms, images: vImages, templates: vTemplates, invites: vInvites, sessions: vSessions, settings: vSettings };

function drawTabs() {
    $("tabs").replaceChildren(...TABS.map(([id, label]) => h("button", { role: "tab", "aria-selected": String(id === currentTab),
        onclick: () => show(id) }, label)));
}
async function show(tab) {
    currentTab = tab;
    drawTabs();
    $("view").replaceChildren(h("div", { class: "empty" }, "Loading…"));
    await refresh(false);
}
let refreshing = false, pendingRefresh = false, rerun = false;
async function refresh(quiet) {
    if (refreshing) { if (!quiet) rerun = true; return; }   // a tab switch must never be dropped
    if (quiet && (dlg().open || document.querySelector("details.menu[open]") || document.activeElement?.closest?.("#view form"))) {
        pendingRefresh = true;   // run it as soon as the dialog / menu is dismissed
        return;
    }
    pendingRefresh = false;
    refreshing = true;
    const tab = currentTab;
    try {
        await LOAD[tab]();
        if (tab === currentTab) $("view").replaceChildren(RENDER[tab]());
    } catch (ex) {
        if (!quiet) $("view").replaceChildren(h("div", { class: "alert bad" }, ex.message || String(ex)));
    } finally {
        refreshing = false;
        if (rerun) { rerun = false; refresh(false); }
    }
}
async function doAction(fn, okMsg) {
    try { const r = await fn(); if (okMsg) toast(okMsg); await refresh(true); return r; } catch (ex) { fail(ex); }
}

async function drawServices() {
    const box = $("svc");
    try {
        const out = await cockpit.spawn(["sh", "-c", "systemctl is-active vm-portal vm-portal-ws; true"], { err: "ignore" });
        const [a, b] = out.trim().split("\n");
        box.replaceChildren(pill("Portal: " + (a === "active" ? "running" : a || "unknown"), a === "active" ? "ok" : "bad"),
            pill("Console proxy: " + (b === "active" ? "running" : b || "unknown"), b === "active" ? "ok" : "bad"));
    } catch (ex) { box.replaceChildren(); }
}

/* ------------------------------------------------------------------ overview */
function stat(label, value, sub, extra) {
    return h("div", { class: "card stat" }, h("div", { class: "label" }, label), h("div", { class: "value" }, value),
        h("div", { class: "muted small" }, sub), extra || null);
}
function portalBase() {
    const st = S.status || {};
    const host = st.public_host || location.hostname;
    const tls = st.tls;
    const dflt = (tls && st.port === 443) || (!tls && st.port === 80);
    return `${tls ? "https" : "http"}://${host}${dflt ? "" : ":" + st.port}`;
}
function vOverview() {
    const st = S.status, vms = S.vms;
    const running = vms.filter((v) => v.state === "running").length;
    const usedPct = st.disk_total ? (st.data_bytes / st.disk_total) * 100 : 0;
    const alerts = [];
    if (!st.kvm) alerts.push(h("div", { class: "alert warn" }, "Hardware virtualisation (/dev/kvm) is not available. VMs will run in slow software emulation."));
    if (!st.network_up) alerts.push(h("div", { class: "alert bad" }, `The guest network “${st.network}” is not running. Visitor VMs cannot start until it is (Settings → Guest network, or run: virsh net-start ${st.network}).`));
    if (!st.tls) alerts.push(h("div", { class: "alert warn" }, "Visitors reach the portal over plain HTTP. Enable TLS in Settings or put a TLS reverse proxy in front before exposing it to the internet."));
    if (!st.public_host) alerts.push(h("div", { class: "alert info" }, "Set the Public host name in Settings so invite links contain the address visitors should use."));
    const guestRam = st.max_sessions * 2048;
    const steps = h("ol", { class: "steps" },
        h("li", {}, "Add a VM: ", h("button", { class: "link", onclick: () => show("vms") }, "use one you already have"), ", or ",
            h("button", { class: "link", onclick: uploadDialog }, "upload an ISO / OVA / disk image"), " and create one."),
        h("li", {}, "Shut it down, then ", h("button", { class: "link", onclick: () => show("templates") }, "turn it into a template"), " with CPU, RAM, time and disk limits."),
        h("li", {}, "Create an ", h("button", { class: "link", onclick: () => show("invites") }, "invite link"), " (limited or unlimited) and send it to your guest."),
        h("li", {}, "Watch and end guest VMs under ", h("button", { class: "link", onclick: () => show("sessions") }, "Live sessions"), "."));
    return h("div", {}, alerts,
        h("div", { class: "grid stats", style: "margin-bottom:16px" },
            stat("Virtual machines", `${running} running`, `${vms.length} total`),
            stat("Guest sessions", `${st.active + st.creating} / ${st.max_sessions}`, st.creating ? `${st.creating} starting` : "visitor VMs right now"),
            stat("Templates", String(st.templates), `${st.invites_active} active invite link${st.invites_active === 1 ? "" : "s"}`),
            stat("Storage", fmtBytes(st.disk_free) + " free", `VM Portal uses ${fmtBytes(st.data_bytes)}`, bar(usedPct, usedPct > 85 ? "bad" : usedPct > 70 ? "warn" : "")),
            stat("Host", `${st.cpus} CPUs`, `${fmtMB(st.mem_avail_mb)} of ${fmtMB(st.mem_total_mb)} RAM free`)),
        h("div", { class: "grid two" },
            h("div", { class: "card" }, h("h2", {}, "Getting started"), steps),
            h("div", { class: "card" }, h("h2", {}, "Capacity check"),
                h("p", { class: "muted" }, `Up to ${st.max_sessions} guest VMs can run at once. At 2 GB each that is about ${fmtMB(guestRam)} of RAM, and this host has ${fmtMB(st.mem_total_mb)}.`),
                guestRam > st.mem_total_mb * 0.8 ? h("div", { class: "alert warn" }, "That could exhaust host memory. Lower “Maximum guest VMs” in Settings or give templates less RAM.") : h("div", { class: "alert ok" }, "Looks reasonable."),
                h("p", { class: "muted small" }, "Visitor link format: " + portalBase() + "/i/…"))));
}

/* ------------------------------------------------------------------ virtual machines */
const STATE_KIND = { running: "ok", "shut off": "plain", paused: "warn", "in shutdown": "warn", crashed: "bad", pmsuspended: "warn" };

function vVms() {
    const head = h("div", { class: "card-head" }, h("div", {}, h("h2", {}, "Virtual machines"),
        h("p", { class: "muted" }, "Every VM on this host, including ones created in Cockpit's Virtual Machines page.")),
    h("div", { class: "toolbar" }, h("button", { onclick: uploadDialog }, "Upload image"),
        h("button", { class: "primary", onclick: () => createVmDialog() }, "Create VM")));
    if (!S.vms.length) {
        return h("div", { class: "card" }, head, h("div", { class: "empty" }, h("h3", {}, "No virtual machines yet"),
            h("p", {}, "Upload an ISO to install an operating system, or import an OVA / disk image."),
            h("button", { class: "primary", onclick: () => createVmDialog() }, "Create your first VM")));
    }
    const rows = S.vms.map((v) => {
        const running = v.state === "running", paused = v.state === "paused";
        const primary = running ? h("button", { class: "sm", onclick: () => doAction(() => call("vm-action", { name: v.name, action: "shutdown" }), "Shutdown signal sent") }, "Shut down")
            : paused ? h("button", { class: "sm", onclick: () => doAction(() => call("vm-action", { name: v.name, action: "resume" })) }, "Resume")
                : h("button", { class: "sm primary", onclick: () => doAction(() => call("vm-action", { name: v.name, action: "start" }), v.name + " started") }, "Start");
        const consoleBtn = h("button", { class: "sm", disabled: !running || v.graphics !== "vnc",
            title: v.graphics !== "vnc" ? "This VM does not use VNC. Use Cockpit's Virtual Machines console." : "", onclick: () => openConsole(v.name) }, "Console");
        const item = (label, fn, cls, dis) => h("button", { class: cls || "", disabled: !!dis, onclick: (e) => { e.target.closest("details").open = false; fn(); } }, label);
        const menu = h("details", { class: "menu" }, h("summary", { "aria-label": "More actions for " + v.name }, "⋮"),
            h("div", { class: "menu-items" },
                item("Reboot", () => doAction(() => call("vm-action", { name: v.name, action: "reboot" })), "", !running),
                item("Pause", () => doAction(() => call("vm-action", { name: v.name, action: "pause" })), "", !running),
                item("Force off", async () => { if (await confirmDlg({ title: `Force off ${v.name}?`, body: "This is like pulling the power cord. Unsaved data in the VM may be lost.", confirm: "Force off", danger: true })) doAction(() => call("vm-action", { name: v.name, action: "poweroff" })); }, "", !running && !paused),
                h("hr"),
                item("Edit CPU and RAM…", () => resourcesDialog(v)),
                item("Installation media…", () => mediaDialog(v)),
                item("Snapshots…", () => snapshotsDialog(v)),
                item(v.autostart ? "Disable start on boot" : "Start on boot", () => doAction(() => call("vm-action", { name: v.name, action: v.autostart ? "autostart-off" : "autostart-on" }))),
                item("Make template for guests…", () => templateDialog(v.name), "", running || paused),
                h("hr"),
                item("Delete…", () => deleteVmDialog(v), "danger")));
        return h("tr", {},
            h("td", {}, h("strong", {}, v.name), h("div", { class: "sub" }, [v.managed ? "Created here" : "", v.autostart ? "starts on boot" : "", v.templates.length ? "template source" : ""].filter(Boolean).join(" · "))),
            h("td", {}, pill(v.state, STATE_KIND[v.state] || "info")),
            h("td", {}, `${v.vcpus} vCPU · ${fmtMB(v.memory_mb)}`),
            h("td", {}, v.disks.length ? v.disks.map((d) => h("div", {}, d.path.split("/").pop() || "disk", d.mb ? h("span", { class: "sub" }, " · " + fmtMB(d.mb) + " used") : null)) : "–",
                v.iso ? h("div", { class: "sub" }, "ISO: " + v.iso.split("/").pop().replace(/^[0-9a-f]{8}_/, "")) : null),
            h("td", {}, v.networks.join(", ") || "–"),
            h("td", { class: "actions" }, h("div", { class: "toolbar", style: "justify-content:flex-end" }, consoleBtn, primary, menu)));
    });
    return h("div", { class: "card" }, head, h("div", { class: "table-wrap" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Name", "State", "Resources", "Storage", "Network", ""].map((x) => h("th", {}, x)))), h("tbody", {}, rows))));
}

async function openConsole(name) {
    const w = window.open("about:blank", "_blank");
    try {
        const c = await call("vm-console", { name });
        const host = c.public_host || location.hostname;
        const path = encodeURIComponent("websockify?token=" + c.token);
        const url = `${c.ws_tls ? "https" : "http"}://${host}:${c.ws_port}/vnc.html?autoconnect=true&resize=scale&path=${path}` +
            (c.password ? "&password=" + encodeURIComponent(c.password) : "");
        if (w) { w.opener = null; w.location.href = url; } else toast("Pop-up blocked. Allow pop-ups for this page and try again.", "warn");
    } catch (ex) { if (w) w.close(); fail(ex); }
}

async function createVmDialog(pre) {
    pre = pre || {};
    let lib, nets;
    try { [lib, nets] = await Promise.all([call("lib-list"), call("net-list")]); S.library = lib; } catch (ex) { return fail(ex); }
    const isos = lib.filter((x) => x.kind === "iso"), disks = lib.filter((x) => x.kind === "disk");
    const name = text("", "my-server", { required: true, maxlength: 48, pattern: "[A-Za-z0-9._\\-]+" });
    const vcpus = num(2, 1), ram = num(2048, 256, 256), size = num(20, 1);
    const isoSel = select([["", "None (boot from disk)"], ...isos.map((i) => [i.id, `${i.name} (${fmtBytes(i.size)})`])], pre.iso_id ? String(pre.iso_id) : (!pre.disk_id && isos.length ? String(isos[0].id) : ""));
    const diskSel = select(disks.length ? disks.map((d) => [d.id, `${d.name} (${fmtBytes(d.size)})`]) : [["", "No disk images uploaded", true]], pre.disk_id ? String(pre.disk_id) : undefined);
    const mode = { new: h("input", { type: "radio", name: "dm", value: "new", checked: !pre.disk_id }), img: h("input", { type: "radio", name: "dm", value: "img", checked: !!pre.disk_id, disabled: !disks.length }) };
    const netNames = nets.length ? nets : [S.status ? S.status.network : "default"];
    const net = select(netNames.map((n) => [n, n]), netNames.includes("default") ? "default" : netNames[0]);
    const os = select([["linux", "Linux / other"], ["windows", "Windows"]]);
    const bus = select([["virtio", "VirtIO (fastest; Linux has the driver)"], ["sata", "SATA (works everywhere, e.g. Windows installer)"]]);
    const nic = select([["virtio", "VirtIO"], ["e1000e", "Intel e1000e (works everywhere)"]]);
    const uefi = check("UEFI firmware", false, "Needed by some modern OSes (Windows 11, many cloud images). Requires the OVMF package.");
    const start = check("Start the VM after creating it", true);
    const auto = check("Start on host boot", false);
    os.addEventListener("change", () => { const w = os.value === "windows"; bus.value = w ? "sata" : "virtio"; nic.value = w ? "e1000e" : "virtio"; });
    diskSel.addEventListener("change", () => {
        const d = disks.find((x) => String(x.id) === diskSel.value);
        if (d && d.hint) { if (d.hint.vcpus) vcpus.value = d.hint.vcpus; if (d.hint.memory_mb) ram.value = d.hint.memory_mb; }
    });
    if (pre.disk_id) diskSel.dispatchEvent(new Event("change"));
    const sizeField = field("New disk size (GB)", size, "Thin-provisioned: only the space actually used is stored.");
    const diskField = field("Disk image", diskSel, "A copy is made, so the original stays in the library.");
    const sync = () => { sizeField.hidden = !mode.new.checked; diskField.hidden = !mode.img.checked; };
    mode.new.addEventListener("change", sync); mode.img.addEventListener("change", sync); sync();
    dialog({ title: "Create virtual machine",
        intro: !lib.length ? "Tip: upload an ISO or a disk image first from the Images tab." : null,
        body: [h("div", { class: "form-grid" }, field("Name", name), field("vCPUs", vcpus), field("RAM (MB)", ram)),
            h("fieldset", {}, h("legend", {}, "Disk"), h("div", { class: "seg" },
                h("label", {}, mode.new, "Blank disk"), h("label", {}, mode.img, "From an uploaded disk image / OVA")), sizeField, diskField),
            field("Installation ISO", isoSel, isos.length ? "Mounted as a virtual CD and booted first." : "No ISOs yet. Upload one from the Images tab."),
            h("div", { class: "form-grid" }, field("Operating system", os), field("Network", net,
                "The “" + (S.status ? S.status.network : "vmportal") + "” network blocks access to your LAN; “default” does not.")),
            h("div", { class: "form-grid" }, field("Disk controller", bus), field("Network card", nic)),
            uefi.el, start.el, auto.el],
        submit: "Create", onSubmit: async () => {
            const r = await call("vm-create", { name: name.value.trim(), vcpus: +vcpus.value, memory_mb: +ram.value,
                iso_id: isoSel.value || null, disk_id: mode.img.checked ? +diskSel.value : null, disk_gb: +size.value,
                network: net.value, os_type: os.value, disk_bus: bus.value, nic_model: nic.value,
                uefi: uefi.input.checked, start: start.input.checked, autostart: auto.input.checked });
            toast("Creating " + name.value.trim() + "…");
            kickJobs();
            return r;
        } });
}

function resourcesDialog(v) {
    const vc = num(v.vcpus, 1), ram = num(v.memory_mb, 64, 64);
    dialog({ title: `CPU and RAM · ${v.name}`, intro: v.state === "running" ? "The VM is running; changes apply after its next full restart." : null,
        body: h("div", { class: "form-grid" }, field("vCPUs", vc), field("RAM (MB)", ram)),
        submit: "Save", onSubmit: async () => { await call("vm-set", { name: v.name, vcpus: +vc.value, memory_mb: +ram.value }); toast("Saved"); await refresh(false); } });
}
async function mediaDialog(v) {
    let lib;
    try { lib = (await call("lib-list")).filter((x) => x.kind === "iso"); } catch (ex) { return fail(ex); }
    const sel = select([["", "Eject (no media)"], ...lib.map((i) => [i.id, i.name])]);
    dialog({ title: `Installation media · ${v.name}`, intro: "Attach an ISO as a virtual CD. It becomes the first boot device; takes effect on the next start.",
        body: [field("ISO", sel, lib.length ? null : "No ISOs in the library. Upload one from the Images tab."), v.iso ? h("p", { class: "muted small" }, "Currently attached: " + v.iso.split("/").pop()) : null],
        submit: "Apply", onSubmit: async () => { await call("vm-media", { name: v.name, library_id: sel.value ? +sel.value : null }); toast("Media updated"); await refresh(false); } });
}
async function snapshotsDialog(v) {
    const list = h("div", {});
    const nm = text("", "before-update", { pattern: "[A-Za-z0-9._\\-]+", maxlength: 40 });
    async function load() {
        try {
            const snaps = await call("vm-snap", { name: v.name, action: "list" });
            list.replaceChildren(...(snaps.length ? snaps.map((s) => h("div", { class: "snap" }, h("strong", {}, s), h("span", { class: "toolbar" },
                h("button", { type: "button", class: "sm", onclick: async () => { if (await confirmDlg({ title: `Revert to ${s}?`, body: "Changes made since this snapshot are lost.", confirm: "Revert", danger: true })) { await call("vm-snap", { name: v.name, action: "revert", snap: s }).then(() => toast("Reverted"), fail); } snapshotsDialog(v); } }, "Revert"),
                h("button", { type: "button", class: "sm danger", onclick: () => call("vm-snap", { name: v.name, action: "delete", snap: s }).then(load, fail) }, "Delete")))) : [h("p", { class: "muted" }, "No snapshots yet.")]));
        } catch (ex) { list.replaceChildren(h("div", { class: "alert bad" }, ex.message)); }
    }
    dialog({ title: `Snapshots · ${v.name}`, body: [list, h("div", { class: "toolbar" }, nm, h("button", { type: "button", class: "primary", onclick: () => {
        if (!nm.value.trim()) return nm.focus();
        call("vm-snap", { name: v.name, action: "create", snap: nm.value.trim() }).then(() => { nm.value = ""; toast("Snapshot created"); return load(); }, fail);
    } }, "Create snapshot")), h("p", { class: "muted small" }, "Snapshots need a QCOW2 disk. VMs with UEFI firmware may not support internal snapshots.")] });
    load();
}
function deleteVmDialog(v) {
    const storage = check("Also delete the VM's disk files", true, "Only files inside VM Portal's or libvirt's image folders that no other VM or template uses are removed.");
    dialog({ title: `Delete ${v.name}?`, intro: "The VM is powered off and removed. This cannot be undone.",
        body: [v.templates.length ? h("div", { class: "alert warn" }, `This VM is the source of template “${v.templates.join(", ")}”. The template keeps its own golden image and keeps working.`) : null, storage.el],
        submit: "Delete VM", danger: true, onSubmit: async () => {
            const r = await call("vm-delete", { name: v.name, storage: storage.input.checked });
            toast(`${v.name} deleted` + (r.removed.length ? ` · ${r.removed.length} disk file(s) removed` : "") + (r.kept.length && storage.input.checked ? ` · ${r.kept.length} kept (shared or outside managed folders)` : ""));
            await refresh(false);
        } });
}

/* ------------------------------------------------------------------ images */
function vImages() {
    const head = h("div", { class: "card-head" }, h("div", {}, h("h2", {}, "Image library"),
        h("p", { class: "muted" }, "Uploaded ISOs and disk images. They stay here untouched; creating a VM copies what it needs.")),
    h("button", { class: "primary", onclick: uploadDialog }, "Upload image"));
    if (!S.library.length) {
        return h("div", { class: "card" }, head, h("div", { class: "empty" }, h("h3", {}, "No images yet"),
            h("p", {}, "Upload an ISO, an OVA, or a QCOW2 / VMDK / VDI / VHD(X) / IMG / RAW disk. You do not need Cockpit's Virtual Machines page."),
            h("button", { class: "primary", onclick: uploadDialog }, "Upload image")));
    }
    const rows = S.library.map((i) => h("tr", {},
        h("td", {}, h("strong", {}, i.name), i.hint && i.hint.vcpus ? h("div", { class: "sub" }, `From OVA: ${i.hint.vcpus} vCPU${i.hint.memory_mb ? " · " + fmtMB(i.hint.memory_mb) : ""}`) : null),
        h("td", {}, pill(i.kind === "iso" ? "ISO installer" : "Disk image", "info")),
        h("td", {}, fmtBytes(i.size) + (i.hint && i.hint.virtual_gb ? ` (${i.hint.virtual_gb} GB virtual)` : "")),
        h("td", {}, fmtTime(i.created)),
        h("td", {}, i.in_use_by ? "VM " + i.in_use_by : "–"),
        h("td", { class: "actions" }, h("div", { class: "toolbar", style: "justify-content:flex-end" },
            h("button", { class: "sm primary", onclick: () => createVmDialog(i.kind === "iso" ? { iso_id: i.id } : { disk_id: i.id }) }, "Create VM"),
            h("button", { class: "sm danger", disabled: !!i.in_use_by, title: i.in_use_by ? "In use by " + i.in_use_by : "", onclick: async () => {
                if (await confirmDlg({ title: `Delete ${i.name}?`, body: "The file is removed from disk.", confirm: "Delete", danger: true })) doAction(() => call("lib-rm", { id: i.id }), "Image deleted");
            } }, "Delete")))));
    return h("div", { class: "card" }, head, h("div", { class: "table-wrap" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Name", "Type", "Size", "Added", "Used by", ""].map((x) => h("th", {}, x)))), h("tbody", {}, rows))));
}

/* ------------------------------------------------------------------ templates */
function templateDialog(preDomain) {
    call("vm-list").then((vms) => {
        S.vms = vms;
        const opts = vms.map((v) => [v.name, v.state === "shut off" ? v.name : `${v.name} (${v.state}: shut it down first)`, v.state !== "shut off"]);
        if (!opts.length) return toast("Create or import a VM first.", "warn");
        const src = select(opts, preDomain);
        const name = text(preDomain ? preDomain.replace(/[^A-Za-z0-9._-]/g, "-") : "", "ubuntu-demo", { required: true, maxlength: 48, pattern: "[A-Za-z0-9._\\-]+" });
        const vc = num(2, 1), ram = num(2048, 256, 256), ttl = num(120, 5), disk = num(20, 1), iops = num(500, 50);
        const sys = check("Give each guest a fresh hostname, machine-id and SSH host keys", false, "Needs libguestfs (virt-sysprep). Linux guests only.");
        dialog({ title: "Create a template from a VM",
            intro: "The VM's disk is cloned once into a read-only golden image. Guests get thin copy-on-write layers on top; your original VM is never touched or started. Progress is shown in the Activity panel.",
            body: [h("div", { class: "form-grid" }, field("Source VM", src), field("Template name", name)),
                h("fieldset", {}, h("legend", {}, "Limits for every guest"), h("div", { class: "form-grid" },
                    field("vCPUs", vc), field("RAM (MB)", ram), field("Session length (min)", ttl, "The VM is deleted when it ends."),
                    field("Disk write limit (GB)", disk, "VM is stopped if exceeded."), field("Disk IOPS cap", iops))), sys.el],
            submit: "Create template", onSubmit: async () => {
                await call("template-add", { name: name.value.trim(), domain: src.value, vcpus: +vc.value, memory_mb: +ram.value,
                    ttl_minutes: +ttl.value, max_disk_gb: +disk.value, iops: +iops.value, sysprep: sys.input.checked });
                toast("Cloning started. Watch the Activity panel.");
                kickJobs();
                show("templates");
            } });
    }, fail);
}
function vTemplates() {
    const head = h("div", { class: "card-head" }, h("div", {}, h("h2", {}, "Templates"),
        h("p", { class: "muted" }, "Guests are launched from these read-only golden images.")),
    h("button", { class: "primary", onclick: () => templateDialog() }, "New template"));
    if (!S.templates.length) {
        return h("div", { class: "card" }, head, h("div", { class: "empty" }, h("h3", {}, "No templates yet"),
            h("p", {}, "Pick a shut-off VM and turn it into something outsiders can launch."), h("button", { class: "primary", onclick: () => templateDialog() }, "New template")));
    }
    const rows = S.templates.map((t) => h("tr", {},
        h("td", {}, h("strong", {}, t.name), h("div", { class: "sub" }, "from " + t.source_domain)),
        h("td", {}, `${t.vcpus} vCPU · ${fmtMB(t.memory_mb)}`),
        h("td", {}, `${t.ttl_minutes} min`),
        h("td", {}, `${t.max_disk_gb} GB writes`, h("div", { class: "sub" }, `${t.iops} IOPS`)),
        h("td", {}, t.owns_golden ? fmtMB(t.golden_mb) : "shares source disk"),
        h("td", {}, `${t.invites} link${t.invites === 1 ? "" : "s"} · ${t.live} live`),
        h("td", { class: "actions" }, h("button", { class: "sm danger", onclick: () => removeTemplate(t) }, "Delete"))));
    return h("div", { class: "card" }, head, h("div", { class: "table-wrap" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Template", "Per guest", "Session", "Limits", "Golden image", "Usage", ""].map((x) => h("th", {}, x)))), h("tbody", {}, rows))));
}
async function removeTemplate(t) {
    const ok = await confirmDlg({ title: `Delete template “${t.name}”?`, confirm: "Delete template", danger: true,
        body: h("div", {}, h("p", {}, "This removes:"), h("ul", {}, h("li", {}, `its golden image${t.golden_mb ? ` (frees ${fmtMB(t.golden_mb)})` : ""}`),
            h("li", {}, `${t.invites} invite link${t.invites === 1 ? "" : "s"} (they stop working)`),
            h("li", {}, t.live ? `${t.live} running guest VM${t.live === 1 ? "" : "s"} and their data (they are ended now)` : "no running guests are affected")),
        h("p", { class: "muted small" }, "Your source VM and the shared guest network are left alone; the network is shared by all templates and uses no resources while idle.")) });
    if (!ok) return;
    doAction(async () => {
        const r = await call("template-rm", { id: t.id, force: true });
        toast(`Template deleted · ${r.sessions_ended} guest(s) ended · ${r.invites_removed} link(s) removed · ${fmtMB(r.freed_mb)} freed`);
    });
}

/* ------------------------------------------------------------------ invites */
function inviteState(i) {
    if (i.revoked) return ["Revoked", "bad"];
    if (i.expires && i.expires * 1000 < Date.now()) return ["Expired", "bad"];
    if (i.max_uses && i.uses >= i.max_uses) return ["Used up", "warn"];
    return ["Active", "ok"];
}
function showLink(url) {
    dialog({ title: "Invite link ready", body: [h("p", {}, "Send this link to your guest:"), h("div", { class: "linkbox" }, h("code", { style: "word-break:break-all;white-space:normal" }, url))],
        submit: "Copy link", cancel: "Close", onSubmit: () => navigator.clipboard.writeText(url).then(() => toast("Link copied"), () => toast("Copy failed. Select the link and copy it manually.", "warn")) });
}
function inviteDialog() {
    if (!S.templates.length) return toast("Create a template first.", "warn");
    const tpl = select(S.templates.map((t) => [t.id, t.name]));
    const label = text("", "e.g. Alice, workshop", { maxlength: 60 });
    const never = check("Never expires", false), hours = num(72, 1);
    const unl = check("Unlimited launches", false), uses = num(1, 1);
    const pw = h("input", { type: "password", autocomplete: "new-password" });
    never.input.addEventListener("change", () => { hours.disabled = never.input.checked; });
    unl.input.addEventListener("change", () => { uses.disabled = unl.input.checked; });
    dialog({ title: "New invite link", intro: "Each launch gives the visitor a fresh private VM that is deleted when its session ends.",
        body: [h("div", { class: "form-grid" }, field("Template", tpl), field("Label", label, "Only you see this.")),
            h("fieldset", {}, h("legend", {}, "Link validity"), h("div", { class: "form-grid" },
                h("div", {}, field("Valid for (hours)", hours), never.el), h("div", {}, field("Maximum launches", uses), unl.el))),
            field("Password (optional)", pw, "Visitors must enter it before launching."),
            h("p", { class: "muted small" }, "Unlimited links can be revoked at any time. The “Maximum guest VMs” limit in Settings still protects the server.")],
        submit: "Create link", onSubmit: async () => {
            const r = await call("invite-add", { template: +tpl.value, label: label.value.trim(), expires_hours: never.input.checked ? 0 : +hours.value,
                max_uses: unl.input.checked ? 0 : +uses.value, password: pw.value });
            await refresh(false);
            showLink(`${portalBase()}/i/${r.token}`);
            return false;
        } });
}
function vInvites() {
    const head = h("div", { class: "card-head" }, h("div", {}, h("h2", {}, "Invite links"), h("p", { class: "muted" }, "Anyone with a link can launch a private VM from its template.")),
        h("button", { class: "primary", onclick: inviteDialog }, "New invite link"));
    if (!S.invites.length) return h("div", { class: "card" }, head, h("div", { class: "empty" }, h("h3", {}, "No invite links yet"), h("p", {}, "Create one and send it to the person who should get a VM.")));
    const rows = S.invites.map((i) => {
        const [st, kind] = inviteState(i), url = `${portalBase()}/i/${i.token}`, live = st === "Active";
        return h("tr", {},
            h("td", {}, h("strong", {}, i.label || "(no label)"), i.has_password ? h("span", { class: "sub" }, " · password") : null),
            h("td", {}, i.template || "(template deleted)"), h("td", {}, pill(st, kind)),
            h("td", {}, `${i.uses} / ${i.max_uses || "∞"}`), h("td", {}, i.expires ? fmtTime(i.expires) : "Never"),
            h("td", {}, live ? h("div", { class: "linkbox" }, h("code", { class: "mono" }, url), h("button", { class: "sm", onclick: () => navigator.clipboard.writeText(url).then(() => toast("Link copied")) }, "Copy")) : h("span", { class: "muted" }, "–")),
            h("td", { class: "actions" }, live ? h("button", { class: "sm danger", onclick: () => doAction(() => call("invite-revoke", { token: i.token }), "Link revoked") }, "Revoke")
                : h("button", { class: "sm", onclick: () => doAction(() => call("invite-delete", { token: i.token })) }, "Remove")));
    });
    return h("div", { class: "card" }, head, h("div", { class: "table-wrap" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Label", "Template", "Status", "Launches", "Expires", "Link", ""].map((x) => h("th", {}, x)))), h("tbody", {}, rows))));
}

/* ------------------------------------------------------------------ live sessions */
function vSessions() {
    const head = h("div", { class: "card-head" }, h("div", {}, h("h2", {}, "Live sessions"), h("p", { class: "muted" }, "Guest VMs running right now. Ended sessions disappear from this list.")));
    if (!S.sessions.length) return h("div", { class: "card" }, head, h("div", { class: "empty" }, h("h3", {}, "No live sessions"), h("p", {}, "Guests will show up here as soon as they launch a VM.")));
    const rows = S.sessions.map((s) => {
        const starting = s.state === "creating";
        return h("tr", {},
            h("td", {}, h("strong", {}, s.id), h("div", { class: "sub" }, s.domain)),
            h("td", {}, s.template || "?", s.invite_label ? h("div", { class: "sub" }, s.invite_label) : null),
            h("td", {}, starting ? h("div", {}, h("div", { class: "sub" }, `${s.step} · ${Math.round(s.progress)}%`), bar(s.progress)) : pill(s.vm_state, STATE_KIND[s.vm_state] || "info")),
            h("td", {}, starting ? "–" : fmtMB(s.disk_mb)), h("td", {}, starting ? "starting" : fmtLeft(s.expires)), h("td", {}, s.ip || ""),
            h("td", { class: "actions" }, h("button", { class: "sm danger", onclick: async () => {
                if (await confirmDlg({ title: `End session ${s.id}?`, body: "The guest VM and all its data are deleted immediately.", confirm: "End session", danger: true })) {
                    S.sessions = S.sessions.filter((x) => x.id !== s.id);
                    $("view").replaceChildren(vSessions());
                    doAction(() => call("session-kill", { id: s.id }), "Session ended");
                }
            } }, "End")));
    });
    return h("div", { class: "card" }, head, h("div", { class: "table-wrap" }, h("table", {},
        h("thead", {}, h("tr", {}, ["Session", "Template", "State", "Disk used", "Time left", "From", ""].map((x) => h("th", {}, x)))), h("tbody", {}, rows))));
}

/* ------------------------------------------------------------------ settings + uninstall */
function vSettings() {
    const c = S.config, f = {};
    const T = (k, ph, extra) => (f[k] = text(c[k], ph, extra));
    const N = (k, min) => (f[k] = h("input", { type: "number", value: c[k], min, required: true }));
    const B = (k, label, help) => { const x = check(label, c[k], help); f[k] = x.input; return x.el; };
    const section = (title, desc, ...kids) => h("div", { class: "card" }, h("h2", {}, title), h("p", { class: "muted" }, desc), h("div", { class: "form" }, kids));
    function collect() {
        const o = {};
        for (const [k, el] of Object.entries(f)) o[k] = el.type === "checkbox" ? el.checked : el.type === "number" ? +el.value : el.value.trim();
        return o;
    }
    async function save(restart) {
        try {
            await call("config-set", { settings: collect() });
            if (restart) {
                await cockpit.spawn(["systemctl", "restart", "vm-portal", "vm-portal-ws"], { superuser: "require", err: "message" });
                toast("Settings saved and services restarted");
                drawServices();
            } else toast("Settings saved. Restart the services for them to take effect.", "info");
            await LOAD.settings();
            $("view").replaceChildren(vSettings());
        } catch (ex) { fail(ex); }
    }
    const form = h("form", { onsubmit: (e) => { e.preventDefault(); save(true); } },
        section("Access", "How visitors reach the portal and the browser console.",
            h("div", { class: "form-grid" },
                field("Public host name", T("public_host", "vm.example.com"), "Name or IP visitors use. Used in invite links and console URLs."),
                field("Listen address", T("listen", "0.0.0.0"), "0.0.0.0 = all interfaces; 127.0.0.1 = only a local reverse proxy."),
                field("Portal port", N("port", 1), "Where visitors open their invite link."),
                field("Console port", N("ws_port", 1), "Browser console (noVNC) port.")),
            B("trust_proxy", "Behind a reverse proxy", "Trust X-Forwarded-For for rate limiting. Only enable this if a proxy you control is in front.")),
        section("Encryption (TLS)", "Turn these on, or terminate TLS in a reverse proxy, before exposing the portal to the internet. Files must be readable by the services.",
            h("div", { class: "form-grid" },
                field("Portal certificate", T("tls_cert", "/etc/ssl/certs/vm.crt")), field("Portal private key", T("tls_key", "/etc/ssl/private/vm.key")),
                field("Console certificate", T("ws_cert", "/etc/ssl/certs/vm.crt")), field("Console private key", T("ws_key", "/etc/ssl/private/vm.key"))),
            B("ws_tls", "Serve the console over TLS (wss://)", "Requires the console certificate. Needed when the portal itself uses HTTPS.")),
        section("Limits", "Protect the host from overload and abuse.",
            h("div", { class: "form-grid" },
                field("Maximum guest VMs", N("max_sessions", 1), "Running at the same time across all templates."),
                field("Launches per hour per visitor IP", N("launches_per_hour_per_ip", 1)),
                field("Time extensions per session", N("max_extensions", 0), "Each adds half a session length."))),
        section("Guest network", "Visitor VMs attach to one isolated libvirt network.",
            h("div", { class: "form-grid" }, field("libvirt network", T("network", "vmportal"), S.status.network_up ? "Running." : "Not running!")),
            B("antispoof", "Block MAC / IP spoofing (libvirt clean-traffic filter)", "Turn off only if guests need static IPs.")),
        h("div", { class: "toolbar" }, h("button", { type: "submit", class: "primary" }, "Save and restart services"),
            h("button", { type: "button", onclick: () => save(false) }, "Save only"),
            h("span", { class: "muted small" }, "Restarting the services does not affect running VMs.")));
    const danger = h("div", { class: "card danger-zone" }, h("h2", {}, "Remove VM Portal"),
        h("p", { class: "muted" }, "Stops the services and removes this page. Cockpit, libvirt and the other packages stay installed."),
        h("button", { class: "danger", onclick: uninstallDialog }, "Uninstall…"));
    return h("div", {}, form, danger);
}
function uninstallDialog() {
    const keep = h("input", { type: "radio", name: "u", checked: true }), purge = h("input", { type: "radio", name: "u" });
    dialog({ title: "Uninstall VM Portal",
        body: [h("fieldset", {}, h("legend", {}, "What should be removed?"),
            h("label", { class: "field check" }, keep, h("div", {}, h("span", { class: "l" }, "Remove the software only"), h("div", { class: "help" }, "Ends all guest sessions and removes services, firewall rules and this page. Keeps your settings, templates, images and the VMs you created, so a reinstall picks up where you left off."))),
            h("label", { class: "field check" }, purge, h("div", {}, h("span", { class: "l" }, "Remove everything (purge)"), h("div", { class: "help" }, "Also deletes settings, templates, invite links, the image library, all VMs created with VM Portal and their disks, and the guest network. VMs you made in Cockpit are not touched.")))),
        h("p", { class: "muted small" }, "Packages such as cockpit, libvirt and novnc are not uninstalled.")],
        submit: "Continue", danger: true, onSubmit: async () => {
            const doIt = purge.checked ? await confirmDlg({ title: "Purge everything?", danger: true, confirm: "Purge and uninstall", typed: "PURGE",
                body: "All VM Portal data, including VMs created here, will be permanently deleted." }) : await confirmDlg({ title: "Uninstall VM Portal?", confirm: "Uninstall", danger: true, body: "Guest sessions will be ended." });
            if (!doIt) return;
            try {
                await cockpit.spawn(["systemd-run", "--unit=vm-portal-uninstall", "--collect", "--no-block", UNINSTALL, "--yes"].concat(purge.checked ? ["--purge"] : []), { superuser: "require", err: "message" });
            } catch (ex) { return fail(ex); }
            $("view").replaceChildren(h("div", { class: "card" }, h("h2", {}, "Uninstalling…"), bar(null), h("p", { class: "muted" }, "VM Portal is being removed. This page will close in a few seconds.")));
            $("tabs").replaceChildren();
            setTimeout(() => cockpit.jump("/system"), 9000);
        } });
}

/* ------------------------------------------------------------------ boot */
drawTabs();
show("overview");
drawServices();
pollJobs();
setInterval(() => { if (!document.hidden) { refresh(true); drawServices(); } }, 10000);
