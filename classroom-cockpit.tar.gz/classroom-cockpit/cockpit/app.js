const CTL = "/usr/share/cockpit/classroom/classroomctl";
const state = { hosts: [], sel: new Set() };
let actor = "admin";
cockpit.user().then(u => { actor = u.name; });

const spawnOpts = () => ({ superuser: "require", err: "message", environ: ["CLASSROOM_ACTOR=" + actor] });
const ctl = args => cockpit.spawn([CTL, ...args], spawnOpts());
// Like ctl(), but also writes `data` to the spawned process's stdin - used for push-data,
// which carries a browser-picked file's bytes (there's no server-side path to pass as an
// argument the way the other classroomctl subcommands take one).
const ctlData = (args, data) => { const p = cockpit.spawn([CTL, ...args], spawnOpts()); p.input(data); return p; };
// Binary variant for recordings: resolves to a Uint8Array instead of a string.
const ctlBin = args => cockpit.spawn([CTL, ...args], { ...spawnOpts(), binary: true });
const call = (ip, action, payload = {}) =>
  ctl(["call", ip, action, JSON.stringify(payload)]).then(JSON.parse);

function toast(msg, danger = false) {
  const sec = document.getElementById("cls-alert-section");
  const box = document.getElementById("cls-alert");
  box.className = "pf-v5-c-alert pf-m-inline" + (danger ? " pf-m-danger" : " pf-m-success");
  document.getElementById("cls-alert-text").textContent = msg;
  sec.hidden = false;
}

const targets = () => (state.sel.size ? [...state.sel] : state.hosts.map(h => h.ip));
const each = fn => Promise.allSettled(targets().map(fn)).then(rs => {
  const bad = rs.filter(r => r.status === "rejected");
  bad.length ? toast(`${bad.length} failed: ` + bad.map(b => b.reason.message || b.reason).join("; "), true)
             : toast("Done.");
});
const sendAll = (action, payload) => each(ip => call(ip, action, payload));

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve((r.result.split(",")[1]) || "");
    r.onerror = () => reject(r.error || new Error("could not read file"));
    r.readAsDataURL(file);
  });
}

// Lightweight modal to replace the browser's own prompt()/confirm() dialogs, which look and
// behave like nothing else on this page. Supports a text/url/textarea field (resolves to its
// trimmed string), a select field (resolves to the chosen value), or a real file field
// (resolves to the File object) - or no field at all, for a plain confirm. Resolves to null
// on cancel/Escape/backdrop click.
function modal({ title, body, field, okLabel = "OK", danger = false }) {
  const dlg = document.querySelector("#cls-modal .cls-modal-dialog");
  const fieldWrap = document.getElementById("cls-modal-field");
  const ok = document.getElementById("cls-modal-ok");
  const cancel = document.getElementById("cls-modal-cancel");
  const root = document.getElementById("cls-modal");
  const bodyEl = document.getElementById("cls-modal-body");

  document.getElementById("cls-modal-title").textContent = title;
  bodyEl.textContent = body || "";
  bodyEl.hidden = !body;
  dlg.classList.toggle("cls-modal-danger", danger);
  ok.textContent = okLabel;
  ok.className = "pf-v5-c-button " + (danger ? "pf-m-danger" : "pf-m-primary");
  fieldWrap.replaceChildren();

  let input = null;
  if (field?.type === "select") {
    input = document.createElement("select");
    input.className = "pf-v5-c-form-control";
    for (const o of field.options) {
      const opt = document.createElement("option");
      opt.value = o.value; opt.textContent = o.label;
      input.appendChild(opt);
    }
  } else if (field?.type === "file") {
    input = document.createElement("input");
    input.type = "file"; input.className = "cls-file-input";
    if (field.accept) input.accept = field.accept;
  } else if (field) {
    input = document.createElement(field.type === "textarea" ? "textarea" : "input");
    input.className = "pf-v5-c-form-control";
    if (field.type !== "textarea") input.type = field.type === "url" ? "url" : "text";
    if (field.placeholder) input.placeholder = field.placeholder;
    if (field.value) input.value = field.value;
  }
  if (input) fieldWrap.appendChild(input);

  return new Promise(resolve => {
    const close = result => { root.hidden = true; document.removeEventListener("keydown", onKey); resolve(result); };
    const confirmIt = () => {
      if (!field) return close(true);
      if (field.type === "file") return close(input.files[0] || null);
      const v = (input.value || "").trim();
      return close(v || null);
    };
    const onKey = e => {
      if (e.key === "Escape") close(null);
      // Enter submits for simple text/url/select fields, but not textarea (needs newlines)
      // or file (Enter there just reopens the OS file picker).
      else if (e.key === "Enter" && (!input || input.tagName === "INPUT" || input.tagName === "SELECT")) {
        e.preventDefault(); confirmIt();
      }
    };
    ok.onclick = confirmIt;
    cancel.onclick = () => close(null);
    root.onclick = e => { if (e.target === root) close(null); };
    document.addEventListener("keydown", onKey);
    root.hidden = false;
    (input || ok).focus();
  });
}

// A restriction is an on/off pair of agent actions rendered as a single switch, rather than
// two separate buttons. Its checked state reflects only what's been sent THIS session (the
// agent doesn't report live mute/webcam/USB/net status back), so a freshly loaded page
// always starts every switch in the unrestricted position regardless of actual device state.
const RESTRICTIONS = [
  { label: "Internet access", onWord: "Allowed", offWord: "Blocked",
    on: () => sendAll("net", { mode: "allow" }), off: () => sendAll("net", { mode: "block" }) },
  { label: "Mic & speakers", onWord: "Unmuted", offWord: "Muted",
    on: () => sendAll("audio", { mode: "unmute" }), off: () => sendAll("audio", { mode: "mute" }) },
  { label: "Webcam", onWord: "On", offWord: "Off",
    on: () => sendAll("webcam", { mode: "on" }), off: () => sendAll("webcam", { mode: "off" }) },
  { label: "USB storage", onWord: "Allowed", offWord: "Blocked",
    on: () => sendAll("usb", { mode: "allow" }), off: () => sendAll("usb", { mode: "block" }) },
];

function buildSwitch({ label, onWord, offWord, on, off }) {
  const row = document.createElement("label");
  row.className = "cls-switch";
  const input = document.createElement("input");
  input.type = "checkbox"; input.className = "cls-switch-input"; input.checked = true;
  const track = document.createElement("span");
  track.className = "cls-switch-track";
  track.appendChild(Object.assign(document.createElement("span"), { className: "cls-switch-thumb" }));
  const text = document.createElement("span");
  text.className = "cls-switch-text";
  const setText = () => { text.textContent = `${label}: ${input.checked ? onWord : offWord}`; };
  setText();
  input.addEventListener("change", () => { setText(); (input.checked ? on : off)(); });
  row.append(input, track, text);
  return row;
}

const GROUPS = [
  ["View", [
    ["button", "Discover", () => discover()],
  ]],
  ["Session", [
    ["button", "Lock", () => sendAll("lock")],
    ["button", "Message", async () => {
      const t = await modal({ title: "Send a message", body: "Shown as an urgent notification on each selected workstation.",
                              field: { type: "textarea", placeholder: "Message text" }, okLabel: "Send" });
      if (t) sendAll("message", { text: t });
    }],
    ["button", "Open website", async () => {
      const u = await modal({ title: "Open a website", body: "Opens this URL in the default browser on each selected workstation.",
                              field: { type: "url", placeholder: "https://example.com" }, okLabel: "Open" });
      if (u) sendAll("openurl", { url: u });
    }],
    ["button", "Broadcast", async () => {
      if (!state.hosts.length) return toast("No workstations discovered yet.", true);
      const s = await modal({ title: "Broadcast a screen", body: "Mirrors one workstation's screen onto every other discovered workstation.",
                              field: { type: "select", options: state.hosts.map(h => ({ value: h.ip, label: `${h.hostname || h.ip} (${h.ip})` })) },
                              okLabel: "Start broadcast" });
      if (!s) return;
      ctl(["broadcast", "start", s, ...state.hosts.map(h => h.ip).filter(i => i !== s)]).catch(e => toast(e.message, true));
    }],
    ["button", "Stop broadcast", () => ctl(["broadcast", "stop"]).catch(e => toast(e.message, true))],
    ["button", "Remote control", () => { const ip = [...state.sel][0]; ip ? viewer(ip) : toast("Select one machine.", true); }],
  ]],
  ["Files", [
    ["button", "Send file", async () => {
      const file = await modal({ title: "Send a file", body: "Copies this file to each selected workstation's handout folder.",
                                 field: { type: "file" }, okLabel: "Send" });
      if (!file) return;
      toast(`Sending ${file.name}...`);
      const b64 = await fileToBase64(file);
      each(ip => ctlData(["push-data", ip, file.name], b64));
    }, "", "Copies a file into each workstation's Handout folder"],
    ["button", "Collect files", async () => {
      // Pulls everything students saved in their "handin" folder onto this server, one subfolder per machine.
      const ips = targets();
      const rs = await Promise.allSettled(ips.map(ip => ctl(["collect", ip])));
      const ok = rs.filter(r => r.status === "fulfilled"), bad = rs.filter(r => r.status === "rejected");
      const n = ok.reduce((t, r) => t + (parseInt(r.value, 10) || 0), 0);
      toast(`Collected ${n} file(s) from ${ok.length} workstation(s) into /srv/classroom/collected/<machine IP>/.` +
            (bad.length ? ` ${bad.length} failed: ` + bad.map(b => b.reason.message || b.reason).join("; ") : ""), bad.length > 0);
    }, "", "Copies the files students put in their Hand-in folder to this server (/srv/classroom/collected/<IP>/)"],
  ]],
  ["Recording", [
    ["button", "Record", () => each(ip => ctl(["record", "start", ip]).then(discover))],
    ["button", "Stop recording", () => each(ip => ctl(["record", "stop", ip]).then(discover))],
  ]],
  ["Power", [
    ["button", "Reboot", async () => {
      if (await modal({ title: "Reboot workstations?", body: "This restarts every selected workstation immediately.",
                        okLabel: "Reboot", danger: true }))
        sendAll("power", { mode: "reboot" });
    }, "cls-danger-ghost"],
    ["button", "Shut down", async () => {
      if (await modal({ title: "Shut down workstations?", body: "This powers off every selected workstation immediately.",
                        okLabel: "Shut down", danger: true }))
        sendAll("power", { mode: "poweroff" });
    }, "cls-danger-ghost"],
    ["button", "Wake", async () => {
      // Machines that are switched off can't be discovered, so with nothing selected wake
      // every machine this server has ever seen rather than only the (online) ones on screen.
      if (state.sel.size) return each(ip => ctl(["wake", ip]));
      try { toast(`Wake signal sent to ${(await ctl(["wake-all"])).trim()} machine(s).`); }
      catch (e) { toast(e.message, true); }
    }],
  ]],
];

const bar = document.getElementById("cls-toolbar-items");
for (const [groupName, items] of GROUPS) {
  const group = document.createElement("div");
  group.className = "cls-toolbar-group";

  const label = document.createElement("span");
  label.className = "cls-toolbar-group-label";
  label.textContent = groupName;
  group.appendChild(label);

  const row = document.createElement("div");
  row.className = "cls-toolbar-group-buttons";
  for (const [, itemLabel, fn, extraClass, tip] of items) {
    const b = document.createElement("button");
    if (tip) b.title = tip;
    b.className = "pf-v5-c-button pf-m-secondary pf-m-small" + (extraClass ? " " + extraClass : "");
    b.type = "button"; b.textContent = itemLabel; b.onclick = fn;
    row.appendChild(b);
  }
  group.appendChild(row);
  bar.appendChild(group);
}

// Restrictions get their own group of switches rather than a wall of on/off buttons.
{
  const group = document.createElement("div");
  group.className = "cls-toolbar-group";
  const label = document.createElement("span");
  label.className = "cls-toolbar-group-label";
  label.textContent = "Restrictions";
  group.appendChild(label);
  const list = document.createElement("div");
  list.className = "cls-switch-list";
  for (const r of RESTRICTIONS) list.appendChild(buildSwitch(r));
  group.appendChild(list);
  bar.appendChild(group);
}

function updateSelectionHint() {
  const hint = document.getElementById("cls-selection-hint");
  hint.textContent = state.sel.size
    ? `${state.sel.size} of ${state.hosts.length} workstation(s) selected - actions below apply to them.`
    : "No workstations selected - actions below apply to all of them.";
}

function render() {
  const grid = document.getElementById("cls-grid");
  document.getElementById("cls-empty").hidden = state.hosts.length > 0;
  document.getElementById("cls-count").textContent = state.hosts.length;
  updateSelectionHint();
  grid.replaceChildren();
  for (const h of state.hosts) {
    const card = document.createElement("div");
    card.className = "pf-v5-c-card pf-m-compact cls-card" + (state.sel.has(h.ip) ? " pf-m-selected" : "");

    const thumbWrap = document.createElement("div");
    thumbWrap.className = "cls-thumb-wrap";
    const img = document.createElement("img");
    img.className = "cls-thumb"; img.id = "t-" + h.ip.replaceAll(".", "_"); img.alt = h.hostname || h.ip;
    thumbWrap.appendChild(img);

    const mark = document.createElement("div");
    mark.className = "cls-select-mark";
    thumbWrap.appendChild(mark);

    if (h.recording) {
      const rec = document.createElement("div");
      rec.className = "cls-rec-badge";
      rec.innerHTML = '<span class="cls-rec-dot"></span>REC';
      thumbWrap.appendChild(rec);
    }

    const body = document.createElement("div");
    body.className = "pf-v5-c-card__body cls-card-body";
    const title = document.createElement("div");
    title.className = "cls-card-title";
    title.textContent = h.hostname || h.ip;
    const sub = document.createElement("div");
    sub.className = "cls-card-sub";
    const dot = document.createElement("span");
    dot.className = "cls-status-dot " + (h.user ? "cls-online" : "cls-idle");
    const osChip = document.createElement("span");
    osChip.className = "cls-os-chip"; osChip.textContent = h.os || "?";
    const text = document.createElement("span");
    text.textContent = `${h.ip} • ${h.user || "no session"}`;
    sub.append(dot, osChip, text);
    body.append(title, sub);

    card.append(thumbWrap, body);
    card.onclick = () => { state.sel.has(h.ip) ? state.sel.delete(h.ip) : state.sel.add(h.ip); render(); refreshThumbs(); };
    grid.appendChild(card);
  }
}

async function discover() {
  toast("Scanning network...");
  state.hosts = JSON.parse(await ctl(["discover"]));
  toast(`${state.hosts.length} workstation(s) found.`);
  render(); refreshThumbs();
}

let busy = false;
async function refreshThumbs() {
  if (busy || !state.hosts.length || activeTab !== "ws" || document.getElementById("cls-viewer").hidden === false) return;
  busy = true;
  try {
    const map = JSON.parse(await ctl(["thumbs", ...state.hosts.map(h => h.ip)]));
    for (const [ip, jpg] of Object.entries(map)) {
      const img = document.getElementById("t-" + ip.replaceAll(".", "_"));
      if (img && jpg) img.src = "data:image/jpeg;base64," + jpg;
    }
  } catch (e) { toast(e.message, true); }
  busy = false;
}

function viewer(ip) {
  const v = document.getElementById("cls-viewer"), img = v.querySelector("img");
  const host = state.hosts.find(h => h.ip === ip);
  document.getElementById("cls-vtitle").textContent = host ? `${host.hostname || ip} (${ip})` : ip;
  let live = true, dims = { w: 1, h: 1 }, refreshSoon = null;
  v.hidden = false;
  const frame = async () => {
    try { const j = await call(ip, "thumb", { width: 1280 }); img.src = "data:image/jpeg;base64," + j.jpg; dims = j; }
    catch (e) { toast(e.message, true); }
  };
  (async () => {
    while (live) {
      await frame();
      await new Promise(r => { refreshSoon = r; setTimeout(r, 700); });   // an input wakes this early
    }
  })();

  // Pointer position -> pixel on the remote screen (the image is scaled to fit the page).
  const pos = e => {
    const r = img.getBoundingClientRect();
    return { x: Math.round((e.clientX - r.left) / r.width * dims.w), y: Math.round((e.clientY - r.top) / r.height * dims.h) };
  };
  let lastErr = 0;
  const send = payload => call(ip, "input", payload).then(() => setTimeout(() => refreshSoon && refreshSoon(), 250))
    .catch(x => { if (Date.now() - lastErr > 3000) { lastErr = Date.now(); toast(x.message, true); } });

  // A double-click fires click, click, dblclick in the browser; hold the single click back briefly so
  // the remote machine gets one "double-click" rather than click + click + double-click.
  let clickT = null;
  img.onclick = e => { const p = pos(e); clearTimeout(clickT); clickT = setTimeout(() => send({ kind: "click", ...p }), 220); };
  img.ondblclick = e => { clearTimeout(clickT); send({ kind: "dblclick", ...pos(e) }); };
  // Right-click: suppress the browser's own menu and open the context menu on the remote machine.
  img.oncontextmenu = e => { e.preventDefault(); send({ kind: "rclick", ...pos(e) }); };

  // Scroll wheel / trackpad. Deltas are normalised to wheel "notches", accumulated, and flushed at
  // most ~12x/s so a fast flick doesn't fire a remote command per DOM event. Direction is flipped:
  // browser deltaY>0 means "content moves up" (scroll down), but pyautogui's positive = scroll up.
  let acc = { x: 0, y: 0 }, at = null, wheelBusy = false;
  const flush = () => {
    at = null;
    if (wheelBusy) { at = setTimeout(flush, 80); return; }
    const take = k => { const c = Math.abs(acc[k]) >= 0.4 ? Math.round(acc[k]) || Math.sign(acc[k]) : 0; acc[k] -= c; return c; };
    const dy = -take("y"), dx = take("x");
    if (!dy && !dx) return;
    wheelBusy = true;
    send({ kind: "scroll", dy, dx, ...lastPos }).finally(() => { wheelBusy = false; });
  };
  let lastPos = { x: 0, y: 0 };
  img.onwheel = e => {
    e.preventDefault();
    lastPos = pos(e);
    const unit = e.deltaMode === 1 ? 1 : e.deltaMode === 2 ? 10 : 1 / 100;
    acc.y += e.deltaY * unit; acc.x += e.deltaX * unit;
    if (!at) at = setTimeout(flush, 80);
  };

  document.getElementById("cls-vsend").onclick = () => {
    const t = document.getElementById("cls-vtext"); call(ip, "input", { kind: "type", text: t.value }).catch(x => toast(x.message, true)); t.value = "";
  };
  document.getElementById("cls-vkey").onclick = () => send({ kind: "key", text: "enter" });
  document.getElementById("cls-vclose").onclick = () => {
    live = false; clearTimeout(at); v.hidden = true;
    img.onclick = img.ondblclick = img.oncontextmenu = img.onwheel = null;
  };
}


/* ======================================================================================
 * Tabs
 * ==================================================================================== */
let activeTab = "ws";
const TAB_LOADERS = { rec: () => loadRecordings(), audit: () => loadAudit(), sched: () => loadSchedule() };
function showTab(name) {
  activeTab = name;
  for (const t of document.querySelectorAll(".cls-tab")) {
    const on = t.dataset.tab === name;
    t.setAttribute("aria-selected", on); t.tabIndex = on ? 0 : -1;
    document.getElementById("panel-" + t.dataset.tab).hidden = !on;
  }
  // alerts belong to whichever tab produced them
  document.getElementById("cls-alert-section").hidden = true;
  TAB_LOADERS[name] && TAB_LOADERS[name]();
  if (name === "ws") refreshThumbs();
}
document.querySelector(".cls-tabs").addEventListener("click", e => {
  const t = e.target.closest(".cls-tab"); if (t) showTab(t.dataset.tab);
});
document.querySelector(".cls-tabs").addEventListener("keydown", e => {
  const tabs = [...document.querySelectorAll(".cls-tab")], i = tabs.indexOf(document.activeElement);
  if (i < 0 || !["ArrowLeft", "ArrowRight"].includes(e.key)) return;
  const n = tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
  showTab(n.dataset.tab); n.focus();
});

/* ---------- helpers shared by the three new tabs ---------- */
const el = (tag, props = {}, ...kids) => {
  const n = Object.assign(document.createElement(tag), props);
  n.append(...kids.filter(k => k != null)); return n;
};
const fmtSize = b => b >= 1073741824 ? (b / 1073741824).toFixed(1) + " GB" : b >= 1048576 ? (b / 1048576).toFixed(1) + " MB"
                   : b >= 1024 ? Math.round(b / 1024) + " KB" : b + " B";
const fmtDur = t => {
  if (t == null) return "-"; t = Math.round(t);
  const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = t % 60;
  return h ? `${h}h ${m}m` : m ? `${m}m ${String(s).padStart(2, "0")}s` : `${s}s`;
};
const fmtWhen = iso => new Date(iso).toLocaleString([], { dateStyle: "medium", timeStyle: "medium" });
const matches = (q, ...fields) => !q || fields.join(" ").toLowerCase().includes(q.toLowerCase());
function download(filename, blob) {
  const a = el("a", { href: URL.createObjectURL(blob), download: filename });
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

/* ======================================================================================
 * Recordings: list / play / download / delete
 * ==================================================================================== */
let recs = [], recSel = new Set(), recTimer = null;

async function loadRecordings() {
  try { recs = JSON.parse(await ctl(["rec-list"])); } catch (e) { return toast(e.message, true); }
  recSel = new Set([...recSel].filter(n => recs.some(r => r.name === n)));
  renderRecordings();
  // keep the list live while any recording is still running (its size/length grow)
  clearTimeout(recTimer);
  if (recs.some(r => r.active) && activeTab === "rec") recTimer = setTimeout(loadRecordings, 5000);
}

function renderRecordings() {
  const q = document.getElementById("rec-filter").value, body = document.getElementById("rec-body");
  const rows = recs.filter(r => matches(q, r.hostname, r.ip, r.user, r.actor, fmtWhen(r.started)));
  body.replaceChildren();
  document.getElementById("rec-empty").hidden = rows.length > 0;
  document.getElementById("rec-empty").textContent = recs.length
    ? "No recordings match the filter." : "No recordings yet. Select a workstation and press Record.";
  for (const r of rows) {
    const cb = el("input", { type: "checkbox", checked: recSel.has(r.name), disabled: r.active });
    cb.setAttribute("aria-label", "Select recording");
    cb.onchange = () => { cb.checked ? recSel.add(r.name) : recSel.delete(r.name); syncRecButtons(); };
    const play = el("button", { className: "pf-v5-c-button pf-m-secondary pf-m-small", type: "button", textContent: "Play", disabled: r.active && r.kind === "mp4" });
    play.onclick = () => openRecording(r);
    const del = el("button", { className: "pf-v5-c-button pf-m-secondary pf-m-small cls-danger-ghost", type: "button", textContent: "Delete", disabled: r.active });
    del.onclick = () => deleteRecordings([r]);
    const who = el("div", { className: "cls-cell-main" }, r.hostname || r.ip);
    const sub = el("div", { className: "cls-cell-sub" }, r.hostname ? r.ip : "", r.user ? (r.hostname ? " • " : "") + r.user : "");
    body.appendChild(el("tr", {},
      el("td", { className: "cls-col-check" }, cb),
      el("td", {}, who, sub),
      el("td", {}, fmtWhen(r.started), r.active ? el("span", { className: "cls-chip cls-chip-rec" }, "● Recording") : null),
      el("td", {}, r.kind === "frames" && r.active ? fmtDur(r.duration) + "…" : fmtDur(r.duration)),
      el("td", {}, fmtSize(r.size)),
      el("td", {}, r.actor || "-"),
      el("td", { className: "cls-col-actions" }, play, del)));
  }
  syncRecButtons();
}
function syncRecButtons() {
  document.getElementById("rec-delete-sel").disabled = !recSel.size;
  document.getElementById("rec-delete-sel").textContent = recSel.size ? `Delete selected (${recSel.size})` : "Delete selected";
  const selectable = recs.filter(r => !r.active);
  const all = document.getElementById("rec-all");
  all.checked = selectable.length > 0 && selectable.every(r => recSel.has(r.name));
  all.indeterminate = !all.checked && recSel.size > 0;
}
document.getElementById("rec-all").onchange = e => {
  recSel = new Set(e.target.checked ? recs.filter(r => !r.active).map(r => r.name) : []); renderRecordings();
};
document.getElementById("rec-filter").oninput = renderRecordings;
document.getElementById("rec-refresh").onclick = loadRecordings;
document.getElementById("rec-delete-sel").onclick = () => deleteRecordings(recs.filter(r => recSel.has(r.name)));

async function deleteRecordings(list) {
  if (!list.length) return false;
  const one = list.length === 1;
  const ok = await modal({ title: one ? "Delete this recording?" : `Delete ${list.length} recordings?`, danger: true, okLabel: "Delete",
    body: one ? `${list[0].hostname || list[0].ip}, ${fmtWhen(list[0].started)}. This can't be undone.`
              : "They will be permanently removed from the server. This can't be undone." });
  if (!ok) return false;
  const rs = await Promise.allSettled(list.map(r => ctl(["rec-delete", r.name])));
  const bad = rs.filter(r => r.status === "rejected");
  bad.length ? toast(`${bad.length} could not be deleted: ` + bad.map(b => b.reason.message).join("; "), true)
             : toast(one ? "Recording deleted." : `${list.length} recordings deleted.`);
  list.forEach(r => recSel.delete(r.name));
  await loadRecordings();
  return bad.length < list.length;
}

// ---- player dialog
let curPlayer = null;
async function openRecording(r) {
  const m = document.getElementById("cls-rec-modal"), host = document.getElementById("cls-rec-player");
  const dl = document.getElementById("cls-rec-download");
  document.getElementById("cls-rec-title").textContent = `${r.hostname || r.ip} - ${fmtWhen(r.started)}`;
  document.getElementById("cls-rec-sub").textContent =
    [r.ip, r.user && "user " + r.user, r.actor && "recorded by " + r.actor, fmtSize(r.size)].filter(Boolean).join(" • ");
  m.hidden = false; dl.hidden = r.kind !== "mp4";
  host.replaceChildren(el("div", { className: "cls-player-loading" }, "Opening…"));

  let bytesP = null;
  const getVideo = () => (bytesP ||= ctlBin(["rec-read", r.name]));
  dl.onclick = async () => {
    dl.disabled = true;
    try { download(`${r.hostname || r.ip}-${r.name.slice(-15)}.mp4`, new Blob([await getVideo()], { type: "video/mp4" })); }
    catch (e) { toast(e.message, true); }
    dl.disabled = false;
  };
  document.getElementById("cls-rec-delete").onclick = async () => { if (await deleteRecordings([r])) closeRecording(); };
  document.getElementById("cls-rec-close").onclick = closeRecording;
  m.onclick = e => { if (e.target === m) closeRecording(); };

  try {
    const info = r.kind === "frames" ? JSON.parse(await ctl(["rec-info", r.name])) : null;
    if (m.hidden) return;                                         // closed while loading
    curPlayer = createPlayer(host, {
      kind: r.kind, info, loadVideo: getVideo,
      loadFrame: i => ctlBin(["rec-frame", r.name, String(i)]),
    });
  } catch (e) { host.replaceChildren(el("div", { className: "cls-player-loading cls-player-error" }, e.message || String(e))); }
}
function closeRecording() {
  if (curPlayer) { curPlayer.destroy(); curPlayer = null; }
  document.getElementById("cls-rec-modal").hidden = true;
  document.getElementById("cls-rec-player").replaceChildren();
}
document.addEventListener("keydown", e => {
  if (e.key !== "Escape" || document.getElementById("cls-rec-modal").hidden || !document.getElementById("cls-modal").hidden) return;
  const ex = document.querySelector(".cls-player.cls-expanded");
  ex ? ex.classList.remove("cls-expanded") : closeRecording();
});

/* ======================================================================================
 * Audit log
 * ==================================================================================== */
let auditRows = [], auditTotal = 0;
const AUDIT_NAMES = { lock: "Lock", message: "Message", openurl: "Open website", power: "Power", net: "Internet access",
  audio: "Mic & speakers", webcam: "Webcam", usb: "USB storage", input: "Remote control", push: "Send file", "push-data": "Send file",
  collect: "Collect files", wake: "Wake", "wake-all": "Wake all", broadcast: "Broadcast", indicator: "Recording indicator" };
const AUDIT_DANGER = /^(power|RECORDING DELETE|AUDIT CLEARED|SCHEDULED SHUTDOWN)/;
function parseAudit(r) {
  const m = r.text.match(/^([A-Za-z_-]+(?: [A-Z]+)*)\s*(.*)$/s);
  let ev = m ? m[1] : r.text, rest = m ? m[2] : "";
  const ip = (r.text.match(/\b\d{1,3}(?:\.\d{1,3}){3}\b/) || [""])[0];
  if (ip) rest = rest.replace(ip + "-", "").replace(ip, "").trim();
  const name = AUDIT_NAMES[ev] || (ev === ev.toUpperCase() ? ev.charAt(0) + ev.slice(1).toLowerCase() : ev);
  return { ...r, event: name, raw: ev, ip, details: rest.replace(/^\{\}$/, "") };
}

async function loadAudit() {
  try { const j = JSON.parse(await ctl(["audit", "1000"])); auditTotal = j.total; auditRows = j.rows.map(parseAudit); }
  catch (e) { return toast(e.message, true); }
  renderAudit();
}
function renderAudit() {
  const q = document.getElementById("audit-filter").value, body = document.getElementById("audit-body");
  const rows = auditRows.filter(r => matches(q, r.actor, r.event, r.ip, r.details, r.t));
  body.replaceChildren();
  document.getElementById("audit-empty").hidden = rows.length > 0;
  document.getElementById("audit-empty").textContent = auditRows.length ? "No entries match the filter." : "The audit log is empty.";
  document.getElementById("audit-sub").textContent = auditTotal > auditRows.length
    ? `Newest ${auditRows.length} of ${auditTotal} entries shown (Export CSV includes only what is shown).`
    : `Every action taken from this console, newest first. ${auditTotal} entr${auditTotal === 1 ? "y" : "ies"}.`;
  for (const r of rows) {
    body.appendChild(el("tr", {},
      el("td", { className: "cls-nowrap" }, fmtWhen(r.t)),
      el("td", {}, r.actor),
      el("td", {}, el("span", { className: "cls-chip" + (AUDIT_DANGER.test(r.raw) ? " cls-chip-danger" : "") }, r.event)),
      el("td", { className: "cls-nowrap" }, r.ip || "-"),
      el("td", { className: "cls-details", title: r.details }, r.details)));
  }
}
document.getElementById("audit-filter").oninput = renderAudit;
document.getElementById("audit-refresh").onclick = loadAudit;
document.getElementById("audit-export").onclick = () => {
  const q = s => `"${String(s).replaceAll('"', '""')}"`;
  const csv = ["Time,User,Action,Machine,Details", ...auditRows.map(r => [r.t, r.actor, r.event, r.ip, r.details].map(q).join(","))].join("\n");
  download(`classroom-audit-${new Date().toISOString().slice(0, 10)}.csv`, new Blob([csv], { type: "text/csv" }));
};
document.getElementById("audit-clear").onclick = async () => {
  if (!await modal({ title: "Delete the audit log?", danger: true, okLabel: "Delete log",
        body: `This permanently erases all ${auditTotal} entries. The deletion itself will be recorded as the first entry of the new log.` })) return;
  try { await ctl(["audit-clear"]); toast("Audit log deleted."); loadAudit(); } catch (e) { toast(e.message, true); }
};

/* ======================================================================================
 * Schedule: wake / shut down all machines on a timetable (executed by classroom-scheduler.service)
 * ==================================================================================== */
const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];            // index == Python weekday()
let sched = { enabled: false, entries: [] };

{ // day toggles in the add form
  const box = document.getElementById("sched-days");
  DAYS.forEach((d, i) => {
    const cb = el("input", { type: "checkbox", value: i, checked: i < 5 });
    box.appendChild(el("label", { className: "cls-day" }, cb, el("span", {}, d)));
  });
}
const daysText = days => {
  const d = [...days].sort();
  if (d.length === 7) return "Every day";
  if (d.join() === "0,1,2,3,4") return "Mon-Fri";
  if (d.join() === "5,6") return "Sat, Sun";
  return d.map(i => DAYS[i]).join(", ");
};

async function loadSchedule() {
  try {
    const j = JSON.parse(await ctl(["schedule-get"])); sched = { enabled: j.enabled, entries: j.entries || [] };
    document.getElementById("sched-now").textContent = `${j.now} ${j.tz}`;
    const warn = document.getElementById("sched-warn");
    warn.hidden = j.scheduler_running;
    warn.textContent = j.scheduler_running ? "" :
      "The scheduler service isn't running, so nothing below will fire. On the admin server run: sudo systemctl enable --now classroom-scheduler";
    const k = JSON.parse(await ctl(["known"])), withMac = k.filter(m => m.mac).length;
    document.getElementById("sched-known").textContent =
      `${k.length} machine(s) known to this server; ${withMac} can be woken (Wake-on-LAN needs a MAC address, learned the first time a machine is discovered while on). ` +
      "Shutdown is sent to every known machine that is on. Wake-on-LAN must also be enabled in each computer's BIOS/UEFI.";
  } catch (e) { toast(e.message, true); }
  renderSchedule();
}
function renderSchedule() {
  const en = document.getElementById("sched-enabled");
  en.checked = sched.enabled;
  document.getElementById("sched-enabled-text").textContent = sched.enabled ? "Schedule on" : "Schedule off";
  const body = document.getElementById("sched-body"); body.replaceChildren();
  document.getElementById("sched-empty").hidden = sched.entries.length > 0;
  const sorted = [...sched.entries].sort((a, b) => a.time.localeCompare(b.time));
  for (const e of sorted) {
    const on = el("input", { type: "checkbox", checked: e.enabled !== false });
    on.setAttribute("aria-label", "Enabled");
    on.onchange = () => { e.enabled = on.checked; saveSchedule(); };
    const del = el("button", { className: "pf-v5-c-button pf-m-secondary pf-m-small cls-danger-ghost", type: "button", textContent: "Remove" });
    del.onclick = () => { sched.entries = sched.entries.filter(x => x.id !== e.id); saveSchedule(); };
    body.appendChild(el("tr", { className: e.enabled === false ? "cls-row-off" : "" },
      el("td", { className: "cls-col-check" }, on),
      el("td", {}, el("span", { className: "cls-chip" + (e.action === "poweroff" ? " cls-chip-danger" : " cls-chip-ok") },
                      e.action === "poweroff" ? "Shut down all" : "Wake all")),
      el("td", { className: "cls-nowrap" }, e.time),
      el("td", {}, daysText(e.days)),
      el("td", {}, e.action === "poweroff" && e.warn ? `${e.warn} min before` : "-"),
      el("td", { className: "cls-col-actions" }, del)));
  }
}
async function saveSchedule() {
  try { await ctlData(["schedule-set"], JSON.stringify(sched)); renderSchedule(); }
  catch (e) { toast(e.message, true); loadSchedule(); }
}
document.getElementById("sched-enabled").onchange = e => { sched.enabled = e.target.checked; saveSchedule(); };
document.getElementById("sched-action").onchange = e =>
  { document.getElementById("sched-warn-wrap").hidden = e.target.value !== "poweroff"; };
document.getElementById("sched-add").onclick = () => {
  const action = document.getElementById("sched-action").value, time = document.getElementById("sched-time").value;
  const days = [...document.querySelectorAll("#sched-days input:checked")].map(c => +c.value);
  if (!time) return toast("Pick a time.", true);
  if (!days.length) return toast("Pick at least one day.", true);
  sched.entries.push({ id: Date.now().toString(36), action, time, days, enabled: true,
                       warn: action === "poweroff" ? +document.getElementById("sched-warnmin").value : 0 });
  if (!sched.enabled) { sched.enabled = true; }             // adding a first entry means you want it running
  saveSchedule();
};


discover();
setInterval(refreshThumbs, 5000);
