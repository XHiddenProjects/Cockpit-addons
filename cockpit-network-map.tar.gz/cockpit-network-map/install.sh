#!/bin/sh
# Network Map for Cockpit: installer
#
#   sudo ./install.sh                 system-wide install (/usr/share/cockpit/network-map)
#   ./install.sh --user               current user only (~/.local/share/cockpit/network-map)
#   sudo ./install.sh --deps          also install nmap, lldpd, traceroute, snmp
#   ./install.sh --prefix DIR         install under DIR (DIR/network-map); for packaging/testing
#   ./install.sh --dry-run            show what would happen
#   ./install.sh --help
#
# Safe to re-run: upgrading replaces the previous copy. Nothing outside the target
# directory is modified, except packages when --deps is given.

set -eu

NAME="network-map"
SRC_DIR=$(cd "$(dirname "$0")" && pwd)
SRC="$SRC_DIR/$NAME"
MODE=""
PREFIX=""
DEPS=0
DRY=0
ASSUME_YES=0

say()  { printf '%s\n' "$*"; }
info() { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mwarning:\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 1; }

usage() { sed -n '2,12p' "$0" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
    case "$1" in
        --user)     MODE=user ;;
        --system)   MODE=system ;;
        --prefix)   [ $# -ge 2 ] || die "--prefix needs a directory"; PREFIX="$2"; shift ;;
        --prefix=*) PREFIX="${1#--prefix=}" ;;
        --deps)     DEPS=1 ;;
        --dry-run)  DRY=1 ;;
        -y|--yes)   ASSUME_YES=1 ;;
        -h|--help)  usage; exit 0 ;;
        *)          die "unknown option: $1 (try --help)" ;;
    esac
    shift
done

[ -f "$SRC/manifest.json" ] || die "cannot find $SRC/manifest.json. Run install.sh from the extracted folder."

# ---- decide where to install --------------------------------------------------
if [ -n "$PREFIX" ]; then
    BASE="$PREFIX"
else
    if [ -z "$MODE" ]; then
        if [ "$(id -u)" -eq 0 ]; then MODE=system; else MODE=user; fi
    fi
    if [ "$MODE" = system ]; then
        [ "$(id -u)" -eq 0 ] || die "system-wide install needs root. Re-run with sudo, or use --user."
        BASE=/usr/share/cockpit
    else
        # when run through sudo, --user means the invoking user, not root
        if [ "$(id -u)" -eq 0 ] && [ -n "${SUDO_USER:-}" ]; then
            HOME_DIR=$(getent passwd "$SUDO_USER" | cut -d: -f6)
        else
            HOME_DIR="${HOME:-}"
        fi
        [ -n "$HOME_DIR" ] && [ -d "$HOME_DIR" ] || die "cannot determine home directory"
        BASE="${XDG_DATA_HOME:-$HOME_DIR/.local/share}/cockpit"
        [ -n "${SUDO_USER:-}" ] && BASE="$HOME_DIR/.local/share/cockpit"
    fi
fi
DEST="$BASE/$NAME"
VERSION=$(sed -n 's/.*VERSION = "\([^"]*\)".*/\1/p' "$SRC/core.js" | head -n1)
[ -n "$VERSION" ] || VERSION=unknown

run() { if [ "$DRY" -eq 1 ]; then say "   [dry-run] $*"; else "$@"; fi; }

# ---- optional dependencies -----------------------------------------------------
install_deps() {
    [ "$(id -u)" -eq 0 ] || die "--deps needs root (use sudo)."
    if   command -v apt-get >/dev/null 2>&1; then PM="apt-get install -y";  PKGS="nmap lldpd traceroute snmp"
    elif command -v dnf     >/dev/null 2>&1; then PM="dnf install -y";      PKGS="nmap lldpd traceroute net-snmp-utils"
    elif command -v yum     >/dev/null 2>&1; then PM="yum install -y";      PKGS="nmap lldpd traceroute net-snmp-utils"
    elif command -v zypper  >/dev/null 2>&1; then PM="zypper --non-interactive install"; PKGS="nmap lldpd traceroute net-snmp"
    elif command -v pacman  >/dev/null 2>&1; then PM="pacman -S --noconfirm --needed"; PKGS="nmap lldpd traceroute net-snmp"
    else warn "no supported package manager found; install nmap, lldpd, traceroute and snmp yourself."; return 0
    fi
    info "Installing optional tools: $PKGS"
    if [ "$DRY" -eq 1 ]; then say "   [dry-run] $PM $PKGS"; return 0; fi
    # shellcheck disable=SC2086
    $PM $PKGS || warn "some packages failed to install; the extension still works with what is available."
    if command -v systemctl >/dev/null 2>&1 && systemctl list-unit-files lldpd.service >/dev/null 2>&1; then
        systemctl enable --now lldpd >/dev/null 2>&1 || warn "could not start lldpd (not required)."
    fi
}

report_tools() {
    info "Optional tools on this machine:"
    for t in nmap lldpctl traceroute snmpwalk; do
        if command -v "$t" >/dev/null 2>&1; then say "   [x] $t"; else say "   [ ] $t"; fi
    done
    command -v cockpit-bridge >/dev/null 2>&1 || [ -d /usr/share/cockpit/base1 ] || \
        warn "Cockpit does not appear to be installed here (no cockpit-bridge / base1). The files will be installed anyway."
}

# ---- install ---------------------------------------------------------------------
info "Network Map $VERSION"
info "Installing to $DEST"

if [ -e "$DEST" ] && [ ! -f "$DEST/manifest.json" ]; then
    die "$DEST exists but is not a Network Map install. Refusing to overwrite."
fi

# stage next to the destination so replacement is atomic-ish and a failure never leaves half an install
run mkdir -p "$BASE"
STAGE="$BASE/.$NAME.new.$$"
OLD="$BASE/.$NAME.old.$$"
cleanup() { rm -rf "$STAGE" "$OLD" 2>/dev/null || true; }
trap cleanup EXIT INT TERM

if [ "$DRY" -eq 1 ]; then
    say "   [dry-run] copy $SRC -> $DEST"
else
    mkdir -p "$STAGE"
    cp -R "$SRC"/. "$STAGE"/
    find "$STAGE" -type d -exec chmod 755 {} +
    find "$STAGE" -type f -exec chmod 644 {} +
    printf '%s\n' "$VERSION" > "$STAGE/.installed-by-network-map-installer"
    if [ -e "$DEST" ]; then mv "$DEST" "$OLD"; fi
    mv "$STAGE" "$DEST"
    rm -rf "$OLD"
fi

[ "$DEPS" -eq 1 ] && install_deps
report_tools

info "Done."
if [ -z "$PREFIX" ]; then
    say "   Open Cockpit (https://localhost:9090), log in, and pick \"Network Map\" in the sidebar."
    say "   Turn on \"Administrative access\" in the top bar so scans can run with privileges."
    [ "$DEPS" -eq 0 ] && say "   For best results: sudo $0 --deps   (installs nmap, lldpd, traceroute, snmp)"
    say "   No restart is needed. If the entry does not show up, run: cockpit-bridge --packages | grep network-map"
    say "   To remove it later: ./uninstall.sh"
fi
