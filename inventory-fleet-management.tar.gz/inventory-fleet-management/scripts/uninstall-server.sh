#!/bin/bash
# Uninstalls the inventory server + Cockpit dashboard, and optionally the
# agents on every enrolled host first.
#
# Usage: sudo ./scripts/uninstall-server.sh [options]
#   --with-agents      first push an uninstall job to every enrolled agent
#                      (Linux, macOS and Windows) and wait for them to finish
#   --wait SECONDS     how long to wait for agents (default 180; agents only
#                      pick the job up on their next check-in)
#   --purge            also delete the database, admin token and approved files
#   --yes              don't ask for confirmation
#   --install-dir DIR  server install dir (default: from server.env, else /opt/inventory-server)
#   --delay SECONDS    sleep before removing anything (used by the Cockpit page)
#   --log FILE         append output to FILE
#
# Agent data in /var/lib/inventory-server is kept unless --purge is passed.
set -euo pipefail

main() {
  local PURGE=0 YES=0 WITH_AGENTS=0 WAIT=180 DELAY=0 LOG="" INSTALL_DIR=""
  local CONFIG_DIR="/etc/inventory-server"
  local DB_DIR="/var/lib/inventory-server"
  local DASHBOARD_DIR="/usr/share/cockpit/inventory-dashboard"
  local SCRIPT_DIR
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

  while [ $# -gt 0 ]; do
    case "$1" in
      --purge) PURGE=1; shift ;;
      --yes|-y) YES=1; shift ;;
      --with-agents) WITH_AGENTS=1; shift ;;
      --wait) WAIT="$2"; shift 2 ;;
      --delay) DELAY="$2"; shift 2 ;;
      --log) LOG="$2"; shift 2 ;;
      --install-dir) INSTALL_DIR="$2"; shift 2 ;;
      *) echo "Unknown argument: $1" >&2; exit 1 ;;
    esac
  done

  if [ "$(id -u)" -ne 0 ]; then
    echo "Run this as root (sudo)." >&2
    exit 1
  fi
  [ -n "$LOG" ] && exec >>"$LOG" 2>&1

  if [ -z "$INSTALL_DIR" ] && [ -f "$CONFIG_DIR/server.env" ]; then
    INSTALL_DIR="$(sed -n 's/^INVENTORY_INSTALL_DIR=//p' "$CONFIG_DIR/server.env" | tail -n1 | tr -d "\"'")"
  fi
  INSTALL_DIR="${INSTALL_DIR:-/opt/inventory-server}"
  case "$INSTALL_DIR" in
    ''|/|/usr|/usr/*|/etc|/var|/home|/root|/opt) echo "Refusing to remove unsafe install dir: '$INSTALL_DIR'" >&2; exit 1 ;;
  esac

  if [ "$YES" != "1" ] && [ -t 0 ]; then
    echo "This will remove the inventory server and Cockpit dashboard$([ "$WITH_AGENTS" = 1 ] && echo ", and uninstall the agent on every enrolled host")$([ "$PURGE" = 1 ] && echo ", and DELETE the database, admin token and approved files")."
    read -r -p "Type 'yes' to continue: " answer
    [ "$answer" = "yes" ] || { echo "Aborted."; exit 1; }
  fi

  [ "$DELAY" -gt 0 ] && sleep "$DELAY"

  if [ "$WITH_AGENTS" = "1" ]; then
    echo "== Uninstalling agents on enrolled hosts =="
    local CLI=""
    for c in "$INSTALL_DIR/scripts/inventory_cli.py" "$SCRIPT_DIR/../inventory-dashboard/inventory_cli.py" "$DASHBOARD_DIR/inventory_cli.py"; do
      [ -f "$c" ] && { CLI="$c"; break; }
    done
    if [ -z "$CLI" ]; then
      echo "Warning: inventory_cli.py not found - skipping agent uninstall." >&2
    elif ! python3 "$CLI" uninstall-agents --wait "$WAIT" --plain; then
      echo "Warning: could not finish uninstalling every agent (see above). Continuing with the server removal." >&2
      echo "Hosts that did not confirm still have the agent; remove it there with the OS uninstall script (README)." >&2
    fi
  fi

  echo "== Removing server =="
  systemctl disable --now inventory-server.service 2>/dev/null || true
  rm -f /etc/systemd/system/inventory-server.service
  systemctl daemon-reload

  echo "== Removing dashboard =="
  rm -rf "$DASHBOARD_DIR"
  systemctl try-restart cockpit.socket 2>/dev/null || true

  if [ "$PURGE" = "1" ]; then
    rm -rf "$DB_DIR" "$CONFIG_DIR"
    echo "Removed server, dashboard, database, and config."
  else
    echo "Removed server and dashboard. Database + admin token kept in $DB_DIR and $CONFIG_DIR (use --purge to delete those too)."
  fi
  # Last: this script (and the CLI it used) may live in the install dir.
  rm -rf "$INSTALL_DIR"
}

# Everything runs inside main() and we exit right after, so bash has parsed the
# whole script before it deletes its own copy under the install dir.
main "$@"
exit $?
