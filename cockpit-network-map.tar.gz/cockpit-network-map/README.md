# Network Map for Cockpit (v2)

Scans the LANs and VLANs your host can reach and draws them as an interactive lab diagram: zones, switches, routers,
hypervisors, SIEM boxes, attacker and target machines.

## Install / uninstall

```bash
tar xzf cockpit-network-map.tar.gz && cd cockpit-network-map

sudo ./install.sh            # system-wide (/usr/share/cockpit/network-map)
./install.sh --user          # only for you (~/.local/share/cockpit/network-map)
sudo ./install.sh --deps     # also installs nmap, lldpd, traceroute, snmp (apt, dnf, yum, zypper, pacman)
./install.sh --dry-run       # show what would happen

sudo ./uninstall.sh          # remove system-wide install
./uninstall.sh --user        # remove per-user install
./uninstall.sh --all
```

No Cockpit restart is needed. Open Cockpit, enable **Administrative access**, and choose **Network Map**.
The installer replaces any previous version cleanly, refuses to touch a directory that isn't its own, and the
uninstaller only removes directories it recognises. Packages added by `--deps` are left in place.

## Using it

1. **Networks** (left): every LAN and VLAN sub-interface on this host is listed with its VLAN ID, subnet and gateway.
   Statically routed networks are found from the routing table. Tick the ones to scan, or add a subnet manually.
2. **Scan selected networks.** Depth: discovery only, top-100 ports (default), or deep (services + OS).
3. **Views**
   - **Zones**: one box per network/VLAN, colour-coded, with a purpose tag (Management, Attack, Target, DMZ, ...).
     A dashed link joins the same device seen in several VLANs.
   - **Topology**: Internet → upstream hops → gateway → networks → switches → devices.
   - **Inventory**: sortable table of every device. **VLANs**: networks and VLANs configured on this host.
4. **Inspector** (right): select a device or network to set a label, a role (Attacker, Target, SIEM, Firewall, ...)
   and notes. These are stored in your browser and survive rescans.
5. **Export**: SVG, PNG, Markdown lab report, CSV inventory, JSON.
6. **VLAN helper**: generates (never runs) the `ip` or `nmcli` commands to join a VLAN from this host.

## What it can and cannot see

A host can only scan networks it has an interface in. To see more VLANs, give this machine a trunk port and add
VLAN sub-interfaces (the VLAN helper writes the commands), or scan from a host that already has them.

| Source | Gives you | Needs |
|---|---|---|
| `ip addr/route`, `bridge vlan` | LANs, VLAN IDs, gateways, routed networks | nothing |
| nmap | hosts, MAC vendor, ports, OS guess | `nmap` |
| LLDP | the switch/router physically cabled to this host, with port | `lldpd` on this host and LLDP on the switch |
| traceroute | upstream hops past the gateway | `traceroute` |
| SNMP v2c (read-only community) | which switch port each device is on, VLAN names | `snmp` and SNMP enabled on switches |

Without LLDP/SNMP the wiring between switches and devices is a best guess; the device list and VLAN/subnet
structure stay accurate. The SNMP community is used only for the scan and is never saved.

## Tests

```bash
node tests/test.js                                   # core logic and rendering
NODE_PATH=/path/to/jsdom/node_modules node tests/ui-smoke.js   # UI against a fake cockpit
```

Only scan networks you own or are authorised to test. Subnets larger than /20 are refused.
