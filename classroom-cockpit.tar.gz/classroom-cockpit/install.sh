#!/usr/bin/env bash
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "run as root"; exit 1; }
HERE=$(cd "$(dirname "$0")" && pwd)

#if   command -v apt-get >/dev/null; then apt-get update && apt-get install -y cockpit python3; apt-get install -y ffmpeg || true
#elif command -v dnf     >/dev/null; then dnf install -y cockpit python3; dnf install -y ffmpeg || true
#elif command -v zypper  >/dev/null; then zypper -n install cockpit python3; zypper -n install ffmpeg || true
#elif command -v pacman  >/dev/null; then pacman -S --noconfirm --needed cockpit python ffmpeg
#else echo "Install cockpit + python3 manually on this admin host, then re-run."; fi

install -d /usr/share/cockpit/classroom /usr/share/classroom/agent /usr/share/classroom/downloads \
           /usr/share/classroom/offline /etc/classroom /var/lib/classroom/recordings /srv/classroom/collected
cp "$HERE"/cockpit/manifest.json "$HERE"/cockpit/classroom.css "$HERE"/cockpit/pf-fallback.css \
   "$HERE"/cockpit/index.html "$HERE"/cockpit/app.js "$HERE"/cockpit/theme.js "$HERE"/cockpit/player.js \
   /usr/share/cockpit/classroom/
install -m755 "$HERE/bin/classroomctl.py" /usr/share/cockpit/classroom/classroomctl
ln -sf /usr/share/cockpit/classroom/classroomctl /usr/local/sbin/classroomctl
cp "$HERE"/agent/classroom_agent.py /usr/share/classroom/agent/

# classroomctl and classroom_agent.py are run directly via their '#!/usr/bin/env python3'
# shebang (systemd ExecStart, and the Scheduled Task/LaunchDaemon on enrolled clients).
# If either file ever picks up Windows line endings (editing on Windows, git
# core.autocrlf, a zip tool that converts on extract, ...) the shebang line becomes
# 'python3\r', env looks for a program literally named that, and everything that
# depends on it - the admin UI's backend and every enrolled agent - fails outright.
# Strip any stray \r unconditionally so this can never silently break the install again.
sed -i 's/\r$//' /usr/share/cockpit/classroom/classroomctl /usr/share/classroom/agent/classroom_agent.py

if [ ! -f /etc/classroom/config.json ]; then
  SECRET=$(python3 -c 'import secrets;print(secrets.token_hex(32))')

  # Every enrolled client is pinned (firewall + HMAC check) to this IP, so getting it
  # wrong here is the #1 cause of "nothing works" on a client, and it fails silently.
  # `ip route get 1.1.1.1` finds the interface used to reach the INTERNET, which is
  # wrong on a server that has a separate interface for the classroom/lab subnet -
  # a very common setup. Offer a choice whenever more than one candidate IP exists.
  mapfile -t CANDIDATE_IPS < <(ip -4 -o addr show scope global | sed -n 's#.* inet \([0-9.]*\)/.*#\1#p')
  if [ -n "${CLASSROOM_ADMIN_IP:-}" ]; then
    ADMIN_IP="$CLASSROOM_ADMIN_IP"
  elif [ "${#CANDIDATE_IPS[@]}" -gt 1 ] && [ -t 0 ]; then
    echo "This server has more than one network address:"
    select ip in "${CANDIDATE_IPS[@]}"; do [ -n "${ip:-}" ] && ADMIN_IP="$ip" && break; done
    echo "Using $ADMIN_IP - this must be the address reachable from the student machines' subnet."
  else
    ADMIN_IP=$(ip -4 route get 1.1.1.1 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p')
    ADMIN_IP="${ADMIN_IP:-${CANDIDATE_IPS[0]:-}}"
  fi
  if [ -z "${ADMIN_IP:-}" ]; then
    echo "Could not determine this server's LAN IP. Re-run with CLASSROOM_ADMIN_IP=<ip> $0" >&2
    exit 1
  fi
  if [ "${#CANDIDATE_IPS[@]}" -gt 1 ] && [ ! -t 0 ]; then
    echo "NOTE: multiple network addresses found and this isn't an interactive shell, so" >&2
    echo "defaulting admin_ip to $ADMIN_IP. If student machines are on a different" >&2
    echo "subnet than that, re-run with CLASSROOM_ADMIN_IP=<correct ip> $0 instead." >&2
  fi

  BC=$(ip -4 -o addr show scope global | sed -n 's/.* brd \([0-9.]*\).*/"\1"/p' | paste -sd,)
  cat > /etc/classroom/config.json <<EOF
{
  "secret": "$SECRET",
  "admin_ip": "$ADMIN_IP",
  "broadcast": [${BC:+$BC,}"255.255.255.255"],
  "recording_retention_days": 30
}
EOF
  chmod 600 /etc/classroom/config.json
fi

cat > /etc/systemd/system/classroom-downloads.service <<EOF
[Unit]
Description=Classroom agent downloads (unauthenticated, LAN-only)
After=network-online.target
[Service]
ExecStart=/usr/local/sbin/classroomctl serve-downloads
Restart=always
[Install]
WantedBy=multi-user.target
EOF
# Runs the wake/shutdown timetable set on the Schedule tab. Must run even when nobody has
# the Cockpit page open, hence its own service rather than anything in the browser.
cat > /etc/systemd/system/classroom-scheduler.service <<EOF
[Unit]
Description=Classroom wake/shutdown scheduler
After=network-online.target
[Service]
ExecStart=/usr/local/sbin/classroomctl scheduler
Restart=always
[Install]
WantedBy=multi-user.target
EOF
# Two things that can otherwise make this package look broken/unstyled in the browser
# even though every file is in place correctly:
command -v restorecon >/dev/null && restorecon -Rv /usr/share/cockpit/classroom >/dev/null 2>&1 || true
systemctl daemon-reload && systemctl enable classroom-downloads classroom-scheduler && systemctl restart classroom-downloads classroom-scheduler && systemctl enable --now cockpit.socket
systemctl restart cockpit.socket 2>/dev/null || true  # picks up a brand-new package's manifest.json
command -v ufw >/dev/null && ufw allow 11099/tcp || true
command -v firewall-cmd >/dev/null && firewall-cmd --permanent --add-port=11099/tcp && firewall-cmd --reload || true

ADMIN_IP=$(python3 -c "import json;print(json.load(open('/etc/classroom/config.json'))['admin_ip'])")
cat <<EOF

Installed. Open https://$(hostname -f):9090 -> "Classroom".

This server will identify itself to clients as $ADMIN_IP. Every client (Windows
especially, which firewalls its agent port down to exactly this address) will
silently ignore every command if that's wrong for your classroom's subnet - verify
it now with 'ip -4 addr' before enrolling machines, and re-run this installer with
CLASSROOM_ADMIN_IP=<correct ip> $0 if it needs fixing (existing enrolled clients
would then need re-enrolling so they pick up the corrected agent-bundle.tar.gz).

OFFLINE CLASSROOMS: if student machines have no internet, run the scripts in
offline/ first on a connected machine of each OS and drop the resulting
*.tar.gz files into /usr/share/classroom/offline/ on this server, then
restart classroom-downloads (systemctl restart classroom-downloads).
See offline/README.md.

Run ONE of these on each workstation to install the agent:

  Linux:   curl -fsSL http://$ADMIN_IP:11099/install-linux.sh | sudo bash
  macOS:   curl -fsSL http://$ADMIN_IP:11099/install-macos.sh | sudo bash
  Windows (elevated PowerShell):
           iwr http://$ADMIN_IP:11099/install-windows.ps1 -UseBasicParsing | iex

Note: port 11099 serves the shared secret unauthenticated on the LAN - restrict it
to your classroom VLAN/subnet, or disable "classroom-downloads" after enrolling
all machines (systemctl disable --now classroom-downloads).
EOF
