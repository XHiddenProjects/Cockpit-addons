#Requires -RunAsAdministrator
param([switch]$Purge)
$ErrorActionPreference = "SilentlyContinue"

Stop-ScheduledTask -TaskName ClassroomAgent
Unregister-ScheduledTask -TaskName ClassroomAgent -Confirm:$false
Remove-NetFirewallRule -DisplayName "Classroom Agent TCP"
Remove-NetFirewallRule -DisplayName "Classroom Agent UDP"
Remove-Item -Recurse -Force "$env:ProgramFiles\ClassroomAgent"

if ($Purge) {
  Remove-Item -Recurse -Force "C:\ProgramData\Classroom"
  Write-Host "Purged: agent and config removed."
} else {
  Write-Host "Agent removed. Config kept at C:\ProgramData\Classroom (re-run with -Purge to remove it too)."
}