/* Run: node tests/test.js [outdir]   (writes sample SVGs to outdir if given) */
"use strict";
const assert = require("assert");
const fs = require("fs");
const path = require("path");
const C = require("../network-map/core.js");

const ifaces = [
    { ifname: "lo", addr_info: [{ family: "inet", local: "127.0.0.1", prefixlen: 8, scope: "host" }] },
    { ifname: "eth0", address: "aa:bb:cc:00:00:05", operstate: "UP", addr_info: [{ family: "inet", local: "192.168.1.5", prefixlen: 24, scope: "global" }] },
    { ifname: "eth0.10", link: "eth0", address: "aa:bb:cc:00:00:05", linkinfo: { info_kind: "vlan", info_data: { protocol: "802.1Q", id: 10 } }, addr_info: [{ family: "inet", local: "10.10.10.5", prefixlen: 24, scope: "global" }] },
    { ifname: "eth0.20", link: "eth0", address: "aa:bb:cc:00:00:05", linkinfo: { info_kind: "vlan", info_data: { protocol: "802.1Q", id: 20 } }, addr_info: [{ family: "inet", local: "10.10.20.5", prefixlen: 24, scope: "global" }] },
    { ifname: "eth0.30", link: "eth0", linkinfo: { info_kind: "vlan", info_data: { id: 30 } }, addr_info: [] },
    { ifname: "docker0", address: "02:42:00:00:00:01", linkinfo: { info_kind: "bridge" }, addr_info: [{ family: "inet", local: "172.17.0.1", prefixlen: 16, scope: "global" }] },
];
const routes = [
    { dst: "default", gateway: "192.168.1.1", dev: "eth0", metric: 100 },
    { dst: "192.168.1.0/24", dev: "eth0", scope: "link" },
    { dst: "10.99.0.0/24", gateway: "192.168.1.254", dev: "eth0" },
];
const bridgeVlans = [{ ifname: "br0", vlans: [{ vlan: 10, flags: ["PVID", "Egress Untagged"] }, { vlan: 20 }] }];

/* ---------- zones ---------- */
const info = C.buildZones(ifaces, routes, bridgeVlans);
const zone = id => info.zones.find(z => z.id === id);
assert.strictEqual(info.defaultGateway, "192.168.1.1");
assert.strictEqual(info.defaultDev, "eth0");
assert.strictEqual(info.zones.length, 5);
assert.strictEqual(zone("eth0:192.168.1.0/24").kind, "physical");
assert.strictEqual(zone("eth0:192.168.1.0/24").gateway, "192.168.1.1");
assert.strictEqual(zone("eth0.10:10.10.10.0/24").kind, "vlan");
assert.strictEqual(zone("eth0.10:10.10.10.0/24").vlan, 10);
assert.strictEqual(zone("docker0:172.17.0.0/16").kind, "virtual");
assert.strictEqual(zone("docker0:172.17.0.0/16").scan, false);
assert.strictEqual(zone("route:10.99.0.0/24").kind, "routed");
assert.strictEqual(zone("route:10.99.0.0/24").gateway, "192.168.1.254");
assert(info.hostVlans.some(v => v.iface === "eth0.30" && v.vlan === 30), "VLAN sub-interface without IP listed");
assert(info.hostVlans.some(v => v.iface === "br0" && v.vlan === 10 && /PVID/.test(v.source)), "bridge VLANs listed");
console.log("zones ok");

/* ---------- parsers ---------- */
const fdbText = [
    ".1.3.6.1.2.1.17.4.3.1.2.0.17.34.51.68.85 = INTEGER: 5",
    ".1.3.6.1.2.1.17.4.3.1.2.0.17.34.51.68.86 = INTEGER: 0",
    ".1.3.6.1.2.1.17.7.1.2.2.1.2.20.170.187.204.0.0.50 = INTEGER: 7",
].join("\n");
const fdb = C.parseFdb(fdbText);
assert.strictEqual(fdb.ports.get("00:11:22:33:44:55"), "5");
assert(!fdb.ports.has("00:11:22:33:44:56"), "port 0 skipped");
assert.strictEqual(fdb.ports.get("aa:bb:cc:00:00:32"), "7");
assert.strictEqual(fdb.vlans.get("aa:bb:cc:00:00:32"), 20);
assert.strictEqual(C.parseVlanNames('.1.3.6.1.2.1.17.7.1.4.3.1.1.20 = STRING: "Servers"').get(20), "Servers");
assert.deepStrictEqual(C.parseTraceroute("traceroute to 1.1.1.1\n 1  192.168.1.1  1 ms\n 2  * \n 3  100.64.0.1  9 ms"), ["192.168.1.1", "100.64.0.1"]);
const lldp = C.parseLldp({ lldp: { interface: [{ eth0: { chassis: { sw1: { id: { type: "mac", value: "00:11:22:33:44:55" }, "mgmt-ip": ["192.168.1.2", "fe80::1"], descr: "Core switch", capability: [{ type: "Bridge", enabled: true }, { type: "Router", enabled: false }] } }, port: { id: { value: "Gi1/0/3" }, descr: "uplink3" }, vlan: { "vlan-id": "1", pvid: true } } }] } });
assert.strictEqual(lldp.length, 1);
assert.strictEqual(lldp[0].ip, "192.168.1.2");
assert.deepStrictEqual(lldp[0].caps, ["bridge"]);
assert.strictEqual(lldp[0].port, "uplink3");
console.log("parsers ok");

/* ---------- model + topology ---------- */
const model = C.createModel(info);
for (const z of model.zones.values()) if (z.kind !== "virtual") z.scanned = true;
const Z0 = "eth0:192.168.1.0/24", Z10 = "eth0.10:10.10.10.0/24", Z20 = "eth0.20:10.10.20.0/24", ZR = "route:10.99.0.0/24";
const add = (z, ip, p) => C.upsertNode(model, z, ip, Object.assign({ sources: ["nmap"] }, p));
add(Z0, "192.168.1.5", { mac: "aa:bb:cc:00:00:05", hostname: "labhost", local: true, forcedType: "server" });
add(Z0, "192.168.1.1", { mac: "aa:bb:cc:00:01:01", vendor: "Ubiquiti Networks", hostname: "edge-gw" });
add(Z0, "192.168.1.2", { mac: "00:11:22:33:44:55", vendor: "Cisco Systems", hostname: "core-sw" });
add(Z0, "192.168.1.20", { mac: "aa:bb:cc:00:00:20", vendor: "Apple", hostname: "iphone-anna" });
add(Z0, "192.168.1.30", { mac: "aa:bb:cc:00:00:30", vendor: "Brother", ports: [{ port: 9100, service: "jetdirect" }] });
add(Z10, "10.10.10.5", { mac: "aa:bb:cc:00:00:05", hostname: "labhost", local: true, forcedType: "server" });
add(Z10, "10.10.10.1", { mac: "aa:bb:cc:00:01:01", hostname: "edge-gw" });
add(Z10, "10.10.10.50", { mac: "aa:bb:cc:00:10:50", hostname: "kali-01" });
add(Z10, "10.10.10.60", { mac: "aa:bb:cc:00:10:60", hostname: "metasploitable", ports: [{ port: 21 }, { port: 22 }, { port: 80 }] });
for (let i = 70; i < 90; i++) add(Z10, "10.10.10." + i, { mac: "aa:bb:cc:00:10:" + i, ports: [{ port: 22 }] });
add(Z20, "10.10.20.5", { mac: "aa:bb:cc:00:00:05", hostname: "labhost", local: true, forcedType: "server" });
add(Z20, "10.10.20.10", { mac: "aa:bb:cc:00:20:10", hostname: "wazuh", ports: [{ port: 5601 }, { port: 9200 }] });
add(Z20, "10.10.20.11", { mac: "aa:bb:cc:00:20:11", hostname: "pve1", ports: [{ port: 8006 }, { port: 22 }] });
add(Z20, "10.10.20.12", { mac: "aa:bb:cc:00:20:12", vendor: "VMware", hostname: "win-dc", os: "Microsoft Windows Server 2022", ports: [{ port: 445 }, { port: 389 }] });
add(ZR, "10.99.0.7", { mac: "", hostname: "remote-host", ports: [{ port: 22 }] });
add(ZR, "192.168.1.254", { hostname: "" }); // gateway to routed net lives in the main zone
model.nodes.delete(C.nodeId(ZR, "192.168.1.254"));
add(Z0, "192.168.1.254", { mac: "aa:bb:cc:00:02:54", vendor: "Juniper", hostname: "dc-router" });

const fdbs = new Map();
fdbs.set(C.nodeId(Z0, "192.168.1.2"), {
    ports: new Map([["aa:bb:cc:00:00:20", "7"], ["aa:bb:cc:00:00:30", "8"], ["aa:bb:cc:00:01:01", "1"], ["aa:bb:cc:00:00:05", "2"], ["aa:bb:cc:00:10:50", "2"], ["aa:bb:cc:00:10:60", "2"]]),
    vlans: new Map([["aa:bb:cc:00:00:20", 1], ["aa:bb:cc:00:00:30", 1]]),
});
C.buildTopology(model, { lldp, hops: ["192.168.1.1", "100.64.0.1", "203.0.113.9"], fdbs, vlanNames: new Map([[10, "Attack"], [20, "Servers"]]) });

const n = (z, ip) => model.nodes.get(C.nodeId(z, ip));
assert.strictEqual(C.effType(n(Z0, "192.168.1.1")), "router", "default gw is router");
assert.strictEqual(C.effType(n(Z0, "192.168.1.2")), "switch");
assert.strictEqual(C.effType(n(Z0, "192.168.1.30")), "printer");
assert.strictEqual(C.effType(n(Z0, "192.168.1.20")), "mobile");
assert.strictEqual(C.effType(n(Z10, "10.10.10.50")), "attacker");
assert.strictEqual(C.effType(n(Z10, "10.10.10.60")), "target");
assert.strictEqual(C.effType(n(Z20, "10.10.20.10")), "siem");
assert.strictEqual(C.effType(n(Z20, "10.10.20.11")), "hypervisor");
assert.strictEqual(C.effType(n(Z20, "10.10.20.12")), "server");
assert.strictEqual(n(Z0, "192.168.1.5").uplinkId, n(Z0, "192.168.1.2").id, "local host attached to LLDP switch");
assert.strictEqual(n(Z0, "192.168.1.20").uplinkId, n(Z0, "192.168.1.2").id, "SNMP attaches phone to switch");
assert.strictEqual(n(Z0, "192.168.1.20").uplinkPort, "port 7");
assert.deepStrictEqual(model.upstream, ["100.64.0.1", "203.0.113.9"], "gateway hop removed from upstream");
assert.strictEqual(model.vlanNames[20], "Servers");
console.log("topology ok");

/* ---------- annotations ---------- */
const ann = { nodes: { [C.nodeKey(n(Z10, "10.10.10.60"))]: { label: "DVWA box", role: "target", notes: "Intentionally vulnerable" } }, zones: { [C.zoneKey(model.zones.get(Z10))]: { name: "Attack net", purpose: "Attack" } } };
C.applyAnnotations(model, ann);
assert.strictEqual(C.displayName(n(Z10, "10.10.10.60")), "DVWA box");
assert.strictEqual(model.zones.get(Z10).purpose, "Attack");
assert(/Attack net/.test(C.toMarkdown(model)));
assert(C.toCsv(model).split("\n").length > 20);
const again = C.deserialize(C.serialize(model));
assert.strictEqual(again.nodes.size, model.nodes.size);
assert.strictEqual(C.summary(model).zones, 4);
console.log("annotations/reports ok");

/* ---------- render ---------- */
const sample = process.argv[2];
for (const [tname, theme] of Object.entries(C.THEMES)) {
    const rz = C.renderZones(model, { theme, selected: n(Z0, "192.168.1.2").id });
    const rt = C.renderTree(model, { theme });
    for (const r of [rz, rt]) {
        assert(isFinite(r.w) && isFinite(r.h) && r.w > 0 && r.h > 0);
        assert(!/NaN|undefined/.test(r.inner), "no NaN/undefined in svg");
    }
    assert(/data-node=/.test(rz.inner) && /data-zone=/.test(rz.inner));
    if (sample) {
        fs.mkdirSync(sample, { recursive: true });
        fs.writeFileSync(path.join(sample, `zones-${tname}.svg`), C.standaloneSvg(rz, theme));
        fs.writeFileSync(path.join(sample, `tree-${tname}.svg`), C.standaloneSvg(rt, theme));
    }
}
// search filter dims non-matches
assert(/opacity="0.25"/.test(C.renderZones(model, { theme: C.THEMES.light, query: "kali" }).inner));
console.log("render ok");
console.log("ALL TESTS PASSED");
