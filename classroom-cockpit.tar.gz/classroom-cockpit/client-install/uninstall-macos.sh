#!/usr/bin/env bash
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "run with sudo"; exit 1; }

launchctl bootout system /Library/LaunchDaemons/org.classroom.agent.plist 2>/dev/null || true
rm -f /Library/LaunchDaemons/org.classroom.agent.plist
rm -rf /usr/local/classroom-agent

if [ "${1:-}" = "--purge" ]; then
  rm -rf /usr/local/etc/classroom
  echo "Purged: agent and config removed."
else
  echo "Agent removed. Config kept at /usr/local/etc/classroom (re-run with --purge to remove it too)."
fi