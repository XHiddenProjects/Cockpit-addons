# Inventory agent uninstaller for Windows (works for both the Python agent and the .exe agent).
#
# NOTE: like install.ps1, this has NOT been run on a real Windows machine -
# verify it on a test host first.
#
# Usage (elevated PowerShell):
#   iwr -useb <server>/agent/uninstall.ps1 | iex
#   Uninstall-InventoryAgent
#
# -DelaySeconds N schedules the removal N seconds ahead in a separate one-time
# SYSTEM scheduled task and returns immediately, so the agent can still report
# a job result before it is stopped and deleted (the server's "Uninstall" job uses this).

function Uninstall-InventoryAgent {
    [CmdletBinding()]
    param(
        [string]$InstallDir = "$env:ProgramFiles\InventoryAgent",
        [int]$DelaySeconds = 0
    )

    $ErrorActionPreference = "Stop"

    $currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Error "Run this from an elevated (Administrator) PowerShell prompt."
        return
    }

    $stateDir = Join-Path $env:ProgramData "inventory-agent"
    $helperDir = Join-Path $env:ProgramData "inventory-agent-uninstall"
    $helper = Join-Path $helperDir "cleanup.ps1"
    New-Item -ItemType Directory -Force -Path $helperDir | Out-Null

    # The cleanup lives outside the install and state dirs so it can delete them.
    $cleanup = @"
`$ErrorActionPreference = 'SilentlyContinue'
Stop-ScheduledTask -TaskName 'InventoryAgent'
Unregister-ScheduledTask -TaskName 'InventoryAgent' -Confirm:`$false
Get-CimInstance Win32_Process | Where-Object {
    (`$_.ExecutablePath -and `$_.ExecutablePath -like '$InstallDir\*') -or
    (`$_.CommandLine -and `$_.CommandLine -like '*$InstallDir*inventory_agent.py*')
} | ForEach-Object { Stop-Process -Id `$_.ProcessId -Force }
for (`$i = 0; `$i -lt 10; `$i++) {
    Remove-Item -LiteralPath '$InstallDir' -Recurse -Force
    Remove-Item -LiteralPath '$stateDir' -Recurse -Force
    if (-not ((Test-Path -LiteralPath '$InstallDir') -or (Test-Path -LiteralPath '$stateDir'))) { break }
    Start-Sleep -Seconds 2
}
Unregister-ScheduledTask -TaskName 'InventoryAgentUninstall' -Confirm:`$false
Remove-Item -LiteralPath '$helperDir' -Recurse -Force
"@
    Set-Content -Path $helper -Value $cleanup -Encoding UTF8

    if ($DelaySeconds -le 0) {
        Write-Host "Removing inventory agent ..."
        & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $helper
        Write-Host "Inventory agent removed."
        return
    }

    $taskName = "InventoryAgentUninstall"
    $action = New-ScheduledTaskAction -Execute "powershell.exe" `
        -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$helper`""
    $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddSeconds($DelaySeconds)
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -LogonType ServiceAccount -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    if (Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger `
        -Principal $principal -Settings $settings -Description "Removes the Inventory agent" | Out-Null
    Write-Host "Inventory agent removal scheduled in ${DelaySeconds}s."
}
