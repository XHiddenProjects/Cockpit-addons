/* Network Map UI: talks to the host through cockpit.spawn, delegates all logic to NMCore. */
/* global cockpit, NMCore */
(function () {
    "use strict";

    const C = NMCore;
    const $ = id => document.getElementById(id);
    const esc = C.esc;

    const state = {
        host: { zones: [], defaultGateway: "", defaultDev: "", hostVlans: [] },
        extra: [],                 // manually added subnets
        picked: new Set(),
        model: null,
        view: "zones",
        selected: null,            // node id or "zone:<id>"
        query: "",
        pz: { x: 0, y: 0, k: 1 },
        render: null,
        scanning: false,
        abort: false,
        procs: new Set(),
        ann: { nodes: {}, zones: {} },
        sort: { col: "ip", dir: 1 },
        ifnames: [],
    };

    /* ---------- storage ---------- */
    const store = {
        get(k, d) { try { const v = window.localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
        set(k, v) { try { window.localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage unavailable */ } },
        raw(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
        setRaw(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* ignore */ } },
        del(k) { try { window.localStorage.removeItem(k); } catch (e) { /* ignore */ } },
    };

    /* ---------- cockpit helpers ---------- */
    function run(argv, opts, input) {
        const p = cockpit.spawn(argv, Object.assign({ superuser: "try", err: "message" }, opts || {}));
        if (input !== undefined) p.input(input);
        state.procs.add(p);
        const done = () => state.procs.delete(p);
        p.then(done, done);
        return p;
    }
    const has = cmd => run(["sh", "-c", "command -v " + cmd + " >/dev/null 2>&1"], { err: "ignore" }).then(() => true, () => false);
    const log = m => { const l = $("log"); l.textContent += m + "\n"; l.scrollTop = l.scrollHeight; };
    const setStatus = m => { $("status").textContent = m; };
    const isDark = () => {
        const cl = document.documentElement.classList;
        if (cl.contains("pf-v5-theme-dark") || cl.contains("pf-v6-theme-dark")) return true;
        if (cl.contains("pf-v5-theme-light") || cl.contains("pf-v6-theme-light")) return false;
        return !!(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
    };
    const theme = () => (isDark() ? C.THEMES.dark : C.THEMES.light);

    /* ---------- host discovery (interfaces, routes) ---------- */
    async function loadHost() {
        const info = { zones: [], defaultGateway: "", defaultDev: "", hostVlans: [] };
        try {
            const ifaces = JSON.parse(await run(["ip", "-j", "-d", "addr", "show"]));
            let routes = [];
            try { routes = JSON.parse(await run(["ip", "-j", "-4", "route", "show"])); } catch (e) { log("ip route failed: " + (e.message || e)); }
            let bv = [];
            try { bv = JSON.parse(await run(["bridge", "-j", "vlan", "show"], { err: "ignore" })); } catch (e) { /* no bridge tool / no vlans */ }
            Object.assign(info, C.buildZones(ifaces, routes, bv));
            state.ifnames = ifaces.map(i => i.ifname).filter(n => n && n !== "lo" && !/^(veth|docker|br-|virbr)/.test(n));
        } catch (e) {
            log("Could not read network configuration: " + (e.message || e));
        }
        for (const cidr of state.extra) {
            if (info.zones.some(z => z.cidr === cidr)) continue;
            info.zones.push({ id: "manual:" + cidr, cidr, prefix: Number(cidr.split("/")[1]), iface: "", parent: "", vlan: null, kind: "routed", localIp: "", localMac: "", gateway: "", name: "", purpose: "", source: "manual", state: "", scan: true, scanned: false });
        }
        state.host = info;
        const saved = store.get("nm.picked", null);
        state.picked = new Set(saved ? saved.filter(id => info.zones.some(z => z.id === id)) : info.zones.filter(z => z.scan && z.source !== "route").map(z => z.id));
        renderSidebar();
    }

    /* ---------- sidebar ---------- */
    function annZone(z) { return (state.ann.zones || {})[C.zoneKey(z)] || {}; }
    function renderSidebar() {
        const list = $("zone-list");
        list.innerHTML = "";
        if (!state.host.zones.length) { list.innerHTML = '<p class="nm-hint">No IPv4 networks found on this host. Add a subnet below.</p>'; }
        for (const z0 of C.orderedZones({ zones: new Map(state.host.zones.map(z => [z.id, z])), defaultDev: state.host.defaultDev })) {
            const z = Object.assign({}, z0, { name: annZone(z0).name || "" });
            const row = document.createElement("div");
            row.className = "nm-zone" + (state.selected === "zone:" + z.id ? " sel" : "");
            row.style.setProperty("--zc", C.zoneColor(z));
            row.dataset.zone = z.id;
            const too = z.prefix < 20;
            row.innerHTML = `<input type="checkbox" ${state.picked.has(z.id) ? "checked" : ""} ${too ? "disabled" : ""} aria-label="Scan ${esc(z.cidr)}">` +
                `<div><span class="nm-pill">${esc(C.zoneBadge(z).text)}</span><b>${esc(C.zoneTitle(z))}</b>` +
                `<span class="meta">${esc(z.cidr)}${z.iface && z.kind !== "routed" ? " · " + esc(z.iface) : ""}${z.gateway ? " · gw " + esc(z.gateway) : ""}${too ? " · too large (&gt;/20)" : ""}</span></div>`;
            list.appendChild(row);
        }
        const lg = $("legend");
        lg.innerHTML = "";
        for (const k of C.RANK) {
            const s = document.createElement("span");
            s.innerHTML = `<i style="background:${C.TYPES[k].color}"></i>${esc(C.TYPES[k].label)}`;
            lg.appendChild(s);
        }
    }

    /* ---------- nmap / tool output ---------- */
    function parseNmap(xml) {
        const doc = new DOMParser().parseFromString(xml, "text/xml");
        const hosts = [];
        doc.querySelectorAll("host").forEach(h => {
            const st = h.querySelector(":scope > status");
            if (st && st.getAttribute("state") !== "up") return;
            const o = { ports: [] };
            h.querySelectorAll(":scope > address").forEach(a => {
                const t = a.getAttribute("addrtype");
                if (t === "ipv4") o.ip = a.getAttribute("addr");
                if (t === "mac") { o.mac = C.normMac(a.getAttribute("addr")); o.vendor = a.getAttribute("vendor") || ""; }
            });
            const hn = h.querySelector(":scope > hostnames > hostname");
            if (hn) o.hostname = hn.getAttribute("name");
            const os = h.querySelector(":scope > os > osmatch");
            if (os) o.os = os.getAttribute("name");
            h.querySelectorAll(":scope > ports > port").forEach(p => {
                const s = p.querySelector(":scope > state");
                if (s && s.getAttribute("state") === "open") {
                    const sv = p.querySelector(":scope > service");
                    o.ports.push({
                        port: Number(p.getAttribute("portid")), proto: p.getAttribute("protocol"),
                        service: sv ? sv.getAttribute("name") || "" : "",
                        product: sv ? [sv.getAttribute("product"), sv.getAttribute("version")].filter(Boolean).join(" ") : "",
                    });
                }
            });
            if (o.ip) hosts.push(o);
        });
        return hosts;
    }

    const checkAbort = () => { if (state.abort) throw new Error("Scan stopped"); };

    async function discoverZone(model, z, haveNmap) {
        checkAbort();
        if (haveNmap) {
            log("nmap host discovery: " + z.cidr + (z.iface && z.source === "local" ? " via " + z.iface : ""));
            const argv = ["nmap", "-sn"].concat(z.source === "local" && z.iface ? ["-e", z.iface] : [], ["-oX", "-", z.cidr]);
            const xml = await run(argv);
            for (const h of parseNmap(xml)) C.upsertNode(model, z.id, h.ip, { ip: h.ip, mac: h.mac, vendor: h.vendor, hostname: h.hostname, sources: ["nmap"] });
        } else {
            log("nmap not installed; ping sweep of " + z.cidr + " (no vendor info)");
            await run(["sh", "-c", "xargs -P 100 -I{} ping -c1 -W1 -q {} >/dev/null 2>&1; true"], {}, C.cidrHosts(z.cidr).join("\n") + "\n");
        }
    }

    async function readNeighbours(model, zones) {
        try {
            const neigh = JSON.parse(await run(["ip", "-j", "-4", "neigh", "show"]));
            for (const n of neigh) {
                if (!n.lladdr || !n.dst || (n.state || []).includes("FAILED")) continue;
                const z = zones.find(zz => zz.iface === n.dev && C.inCidr(n.dst, zz.cidr)) || zones.find(zz => C.inCidr(n.dst, zz.cidr));
                if (z) C.upsertNode(model, z.id, n.dst, { ip: n.dst, mac: C.normMac(n.lladdr), sources: ["arp"] });
            }
        } catch (e) { log("ip neigh failed: " + (e.message || e)); }
    }

    async function portScan(model, depth) {
        const nodes = [...model.nodes.values()].filter(n => n.ip && !n.local);
        const targets = [...new Set(nodes.map(n => n.ip))];
        if (!targets.length) return;
        const args = ["nmap", "-Pn", "-n", "--open", "-T4", "-oX", "-"].concat(
            depth === "deep" ? ["-sV", "--version-light", "-O", "--osscan-limit", "--top-ports", "1000"] : ["--top-ports", "100"], ["-iL", "-"]);
        log("Port scan (" + depth + ") of " + targets.length + " host(s)…");
        try {
            const xml = await run(args, {}, targets.join("\n") + "\n");
            for (const h of parseNmap(xml)) for (const n of nodes) if (n.ip === h.ip) { n.ports = h.ports; if (h.os) n.os = h.os; }
        } catch (e) { if (state.abort) throw e; log("Port scan failed: " + (e.message || e)); }
    }

    async function readLldp() {
        if (!await has("lldpctl")) { log("lldpctl not installed: LLDP skipped (install lldpd to see directly cabled switches)."); return []; }
        try { const r = C.parseLldp(JSON.parse(await run(["lldpctl", "-f", "json"]))); log("LLDP neighbours: " + r.length); return r; } catch (e) { log("lldpctl failed: " + (e.message || e)); return []; }
    }
    async function readUpstream() {
        if (!await has("traceroute")) { log("traceroute not installed: upstream hops skipped."); return []; }
        try { return C.parseTraceroute(await run(["traceroute", "-n", "-m", "6", "-w", "1", "-q", "1", "1.1.1.1"], { err: "ignore" })); } catch (e) { return []; }
    }

    async function readSnmp(model, community) {
        const fdbs = new Map();
        let vlanNames = new Map();
        if (!community) return { fdbs, vlanNames };
        if (!await has("snmpwalk")) { log("snmpwalk not installed (package snmp / net-snmp-utils): SNMP skipped."); return { fdbs, vlanNames }; }
        C.classifyAll(model);
        const targets = [...model.nodes.values()].filter(n => n.ip && !n.local && (["switch", "ap", "router", "firewall"].includes(C.effType(n)) || (n.ports || []).some(p => p.port === 161)));
        const walk = (ip, oid) => run(["snmpwalk", "-v2c", "-c", community, "-On", "-t", "2", "-r", "1", ip, oid], { err: "ignore" }).catch(() => "");
        for (const n of targets) {
            checkAbort();
            setStatus("SNMP: " + n.ip + "…");
            const text = (await walk(n.ip, "1.3.6.1.2.1.17.7.1.2.2.1.2")) + "\n" + (await walk(n.ip, "1.3.6.1.2.1.17.4.3.1.2"));
            const f = C.parseFdb(text);
            if (f.ports.size) { fdbs.set(n.id, f); log("SNMP " + n.ip + ": " + f.ports.size + " MAC entries"); } else log("SNMP " + n.ip + ": no forwarding table");
            const names = C.parseVlanNames(await walk(n.ip, "1.3.6.1.2.1.17.7.1.4.3.1.1"));
            for (const [id, nm] of names) vlanNames.set(id, nm);
        }
        return { fdbs, vlanNames };
    }

    /* ---------- scan ---------- */
    async function scan() {
        if (state.scanning) return;
        const picked = state.host.zones.filter(z => state.picked.has(z.id) && z.prefix >= 20);
        if (!picked.length) { setStatus("Select at least one network to scan."); return; }
        state.scanning = true; state.abort = false;
        $("btn-scan").hidden = true; $("btn-stop").hidden = false;
        $("log").textContent = "";
        const depth = $("depth").value, community = $("snmp").value.trim();
        try {
            const model = C.createModel(state.host);
            picked.forEach(z => { model.zones.get(z.id).scanned = true; });
            const haveNmap = await has("nmap");
            let i = 0;
            for (const z of picked) { setStatus(`Discovering ${z.cidr} (${++i}/${picked.length})…`); await discoverZone(model, z, haveNmap); }
            await readNeighbours(model, picked);

            // this host in every local zone, and gateways we know about
            let myname = "";
            try { myname = (await run(["hostname"])).trim(); } catch (e) { /* ignore */ }
            for (const z of picked) {
                if (z.localIp) C.upsertNode(model, z.id, z.localIp, { ip: z.localIp, mac: z.localMac, hostname: myname, local: true, forcedType: "server", sources: ["local"] });
                if (z.gateway && C.inCidr(z.gateway, z.cidr)) C.upsertNode(model, z.id, z.gateway, { ip: z.gateway, sources: ["route"] });
            }
            log("Found " + model.nodes.size + " device(s) in " + picked.length + " network(s).");

            if (depth !== "discovery") {
                if (haveNmap) { setStatus("Identifying devices…"); await portScan(model, depth); } else log("Port scan skipped (nmap missing).");
            }
            checkAbort();
            setStatus("Reading LLDP and upstream route…");
            const [lldp, hops] = await Promise.all([readLldp(), readUpstream()]);
            const { fdbs, vlanNames } = await readSnmp(model, community);
            checkAbort();

            C.buildTopology(model, { lldp, hops, fdbs, vlanNames });
            model.scannedAt = new Date().toISOString();
            finalize(model);
            state.model = model;
            store.setRaw("nm.model", C.serialize(model));
            state.selected = null;
            state.pz.fitted = false;
            renderAll(true);
            setStatus(`Done: ${model.nodes.size} devices in ${C.visibleZones(model).length} networks.`);
        } catch (e) {
            log("Scan failed: " + (e.message || e));
            setStatus(state.abort ? "Scan stopped." : "Scan failed. See log.");
        } finally {
            state.scanning = false; state.abort = false;
            $("btn-scan").hidden = false; $("btn-stop").hidden = true;
        }
    }
    function stopScan() {
        state.abort = true;
        for (const p of state.procs) { try { p.close("terminated"); } catch (e) { /* ignore */ } }
    }

    function finalize(model) {
        C.applyAnnotations(model, state.ann);
        for (const z of model.zones.values()) if (!z.name && z.vlan != null && model.vlanNames[z.vlan]) z.name = model.vlanNames[z.vlan];
    }

    /* ---------- rendering ---------- */
    function renderAll(fit) {
        renderSummary();
        renderSidebar();
        const v = state.view;
        $("view-map").hidden = !(v === "zones" || v === "topology");
        $("view-inventory").hidden = v !== "inventory";
        $("view-vlans").hidden = v !== "vlans";
        document.querySelectorAll(".nm-tabs button").forEach(b => b.classList.toggle("active", b.dataset.view === v));
        if (v === "zones" || v === "topology") renderMap(fit); else if (v === "inventory") renderInventory(); else renderVlans();
        renderInspector();
    }

    function renderSummary() {
        const el = $("summary"), m = state.model;
        if (!m) { el.innerHTML = '<div class="nm-stat"><b>–</b><span>no scan yet</span></div>'; $("subtitle").textContent = "Cyber-lab topology"; return; }
        const s = C.summary(m);
        const infra = (s.counts.router || 0) + (s.counts.firewall || 0) + (s.counts.switch || 0) + (s.counts.ap || 0);
        const vlans = C.visibleZones(m).filter(z => z.vlan != null).length;
        const stat = (n, l) => `<div class="nm-stat"><b>${n}</b><span>${l}</span></div>`;
        el.innerHTML = stat(s.zones, "networks") + stat(vlans, "VLANs") + stat(s.hosts, "devices") + stat(infra, "network devices") + stat(s.counts.target || 0, "targets") + stat(s.counts.attacker || 0, "attacker boxes");
        $("subtitle").textContent = "Last scan " + (m.scannedAt ? new Date(m.scannedAt).toLocaleString() : "");
    }

    function renderMap(fit) {
        const m = state.model;
        const empty = !m || !m.nodes.size;
        $("empty").hidden = !empty;
        $("viewport").innerHTML = "";
        if (empty) { state.render = null; return; }
        const opts = { theme: theme(), selected: state.selected, query: state.query };
        state.render = state.view === "topology" ? C.renderTree(m, opts) : C.renderZones(m, opts);
        $("viewport").innerHTML = state.render.inner;
        if (fit || !state.pz.fitted) fitView(); else applyView();
    }

    function sortedRows() {
        const rows = C.inventoryRows(state.model);
        const q = C.matcher(state.query);
        const f = q ? rows.filter(r => q(state.model.nodes.get(r.id))) : rows;
        const { col, dir } = state.sort;
        return f.slice().sort((a, b) => {
            if (col === "ip") return dir * ((a.ip ? C.ip2n(a.ip) : 0) - (b.ip ? C.ip2n(b.ip) : 0));
            return dir * String(a[col] || "").localeCompare(String(b[col] || ""), undefined, { numeric: true });
        });
    }
    function renderInventory() {
        const el = $("view-inventory");
        if (!state.model) { el.innerHTML = '<p class="nm-placeholder">Run a scan to build the inventory.</p>'; return; }
        const cols = [["zone", "Network"], ["vlan", "VLAN"], ["ip", "IP"], ["name", "Name"], ["type", "Type"], ["mac", "MAC"], ["vendor", "Vendor"], ["uplink", "Uplink"], ["ports", "Open ports"], ["notes", "Notes"]];
        let h = '<table class="nm-table"><thead><tr>' + cols.map(([k, l]) => `<th data-sort="${k}">${l}${state.sort.col === k ? (state.sort.dir > 0 ? " ▲" : " ▼") : ""}</th>`).join("") + "</tr></thead><tbody>";
        for (const r of sortedRows()) {
            const n = state.model.nodes.get(r.id), z = state.model.zones.get(n.zone);
            h += `<tr data-id="${esc(r.id)}"><td><span class="nm-dot" style="background:${C.zoneColor(z)}"></span>${esc(r.zone)}</td><td>${esc(r.vlan)}</td><td class="mono">${esc(r.ip)}</td><td>${esc(r.name)}${n.local ? ' <span class="nm-tag">this host</span>' : ""}</td>` +
                `<td>${esc(r.role || r.type)}</td><td class="mono">${esc(r.mac)}</td><td>${esc(r.vendor)}</td><td>${esc(r.uplink)}</td><td class="mono">${esc(r.ports)}</td><td>${esc(r.notes)}</td></tr>`;
        }
        el.innerHTML = h + "</tbody></table>";
    }

    function renderVlans() {
        const el = $("view-vlans");
        const m = state.model, host = state.host;
        const zoneRows = (m ? C.orderedZones(m) : C.orderedZones({ zones: new Map(host.zones.map(z => [z.id, z])), defaultDev: host.defaultDev }));
        let h = '<div class="nm-section-title">Networks (LANs, VLANs, routed)</div><table class="nm-table"><thead><tr><th>Network</th><th>VLAN</th><th>Kind</th><th>Subnet</th><th>Interface</th><th>Gateway</th><th>Purpose</th><th>Devices</th></tr></thead><tbody>';
        for (const z0 of zoneRows) {
            const z = Object.assign({}, z0, { name: z0.name || annZone(z0).name || "", purpose: z0.purpose || annZone(z0).purpose || "" });
            const cnt = m ? C.zoneNodes(m, z.id).length : "–";
            h += `<tr data-zone="${esc(z.id)}" data-id="zone:${esc(z.id)}"><td><span class="nm-dot" style="background:${C.zoneColor(z)}"></span>${esc(C.zoneTitle(z))}</td><td>${z.vlan == null ? "" : z.vlan}</td><td>${esc(z.kind)}</td><td class="mono">${esc(z.cidr)}</td><td class="mono">${esc(z.iface)}</td><td class="mono">${esc(z.gateway)}</td><td>${esc(z.purpose)}</td><td>${cnt}</td></tr>`;
        }
        h += "</tbody></table>";
        h += '<div class="nm-section-title">VLANs configured on this host</div>';
        if (host.hostVlans.length) {
            h += '<table class="nm-table"><thead><tr><th>Interface</th><th>VLAN</th><th>Parent</th><th>Address</th><th>Source</th></tr></thead><tbody>' +
                host.hostVlans.map(v => `<tr><td class="mono">${esc(v.iface)}</td><td>${v.vlan}</td><td class="mono">${esc(v.parent)}</td><td class="mono">${esc(v.ip)}</td><td>${esc(v.source)}</td></tr>`).join("") + "</tbody></table>";
        } else h += '<p class="nm-hint">No VLAN sub-interfaces or bridge VLANs on this host. Use the <b>VLAN helper</b> to generate the commands for joining one.</p>';
        const names = m ? Object.entries(m.vlanNames || {}) : [];
        if (names.length) {
            h += '<div class="nm-section-title">VLAN names read from switches (SNMP)</div><table class="nm-table"><thead><tr><th>VLAN</th><th>Name</th></tr></thead><tbody>' +
                names.sort((a, b) => a[0] - b[0]).map(([id, n]) => `<tr><td>${esc(id)}</td><td>${esc(n)}</td></tr>`).join("") + "</tbody></table>";
        }
        el.innerHTML = h;
    }

    /* ---------- inspector ---------- */
    function saveAnn(kind, key, patch) {
        const bucket = state.ann[kind] || (state.ann[kind] = {});
        const cur = Object.assign({}, bucket[key] || {}, patch);
        for (const k of Object.keys(cur)) if (!cur[k]) delete cur[k];
        if (Object.keys(cur).length) bucket[key] = cur; else delete bucket[key];
        store.set("nm.ann", state.ann);
        if (state.model) { finalize(state.model); store.setRaw("nm.model", C.serialize(state.model)); }
        renderAll(false);
    }

    function renderInspector() {
        const el = $("inspector"), m = state.model, sel = state.selected;
        if (!m || !sel) {
            el.innerHTML = '<h2>Inspector</h2><p class="nm-placeholder">Select a device or network to see details, add a label, a role and notes.</p>';
            return;
        }
        if (sel.startsWith("zone:")) {
            const z = m.zones.get(sel.slice(5));
            if (!z) { el.innerHTML = ""; return; }
            const ns = C.zoneNodes(m, z.id);
            el.innerHTML = `<h2>Network</h2><div class="nm-card-head"><span class="nm-pill" style="--zc:${C.zoneColor(z)}">${esc(C.zoneBadge(z).text)}</span><h3>${esc(C.zoneTitle(z))}</h3></div>` +
                `<dl class="nm-kv"><dt>Subnet</dt><dd class="mono">${esc(z.cidr)}</dd><dt>Interface</dt><dd class="mono">${esc(z.iface || "–")}</dd><dt>Gateway</dt><dd class="mono">${esc(z.gateway || "–")}</dd><dt>Kind</dt><dd>${esc(z.kind)}</dd><dt>Devices</dt><dd>${ns.length}</dd></dl>` +
                `<label class="nm-field">Name<input class="nm-input" id="i-zname" value="${esc(annZone(z).name || "")}" placeholder="${esc(z.iface || z.cidr)}"></label>` +
                `<label class="nm-field">Purpose<select class="nm-input" id="i-zpurpose"><option value="">(none)</option>${C.PURPOSES.map(p => `<option ${annZone(z).purpose === p ? "selected" : ""}>${esc(p)}</option>`).join("")}</select></label>`;
            $("i-zname").addEventListener("change", e => saveAnn("zones", C.zoneKey(z), { name: e.target.value.trim() }));
            $("i-zpurpose").addEventListener("change", e => saveAnn("zones", C.zoneKey(z), { purpose: e.target.value }));
            return;
        }
        const n = m.nodes.get(sel);
        if (!n) { el.innerHTML = ""; return; }
        const z = m.zones.get(n.zone), ty = C.TYPES[C.effType(n)];
        const up = n.uplinkId && m.nodes.get(n.uplinkId);
        const kv = [["IP", n.ip], ["MAC", n.mac], ["Vendor", n.vendor], ["Hostname", n.hostname], ["OS guess", n.os], ["Network", z ? C.zoneTitle(z) + " (" + z.cidr + ")" : ""], ["VLAN", z && z.vlan != null ? z.vlan : (n.vlanSeen != null ? n.vlanSeen + " (seen on switch)" : "")],
            ["Uplink", up ? C.displayName(up) + (n.uplinkPort ? " · " + n.uplinkPort : "") : ""], ["Info", n.descr], ["Seen by", (n.sources || []).filter((v, i, a) => a.indexOf(v) === i).join(", ")],
            ["Open ports", (n.ports || []).map(p => p.port + (p.service ? "/" + p.service : "") + (p.product ? " (" + p.product + ")" : "")).join(", ")]].filter(r => r[1] !== "" && r[1] !== undefined);
        el.innerHTML = `<h2>Device</h2><div class="nm-card-head"><span class="nm-dot" style="background:${ty.color};width:12px;height:12px"></span><h3>${esc(C.displayName(n))}</h3>${n.local ? '<span class="nm-tag">this host</span>' : ""}</div>` +
            `<dl class="nm-kv">${kv.map(([k, v]) => `<dt>${esc(k)}</dt><dd class="${k === "IP" || k === "MAC" ? "mono" : ""}">${esc(v)}</dd>`).join("")}<dt>Detected</dt><dd>${esc(C.TYPES[n.type].label)}</dd></dl>` +
            `<label class="nm-field">Label<input class="nm-input" id="i-label" value="${esc(n.label)}" placeholder="${esc(n.hostname || n.ip)}"></label>` +
            `<label class="nm-field">Role<select class="nm-input" id="i-role"><option value="">Auto (${esc(C.TYPES[n.type].label)})</option>${C.ASSIGNABLE.map(r => `<option value="${r}" ${n.role === r ? "selected" : ""}>${esc(C.TYPES[r].label)}</option>`).join("")}</select></label>` +
            `<label class="nm-field">Notes<textarea class="nm-input" id="i-notes" placeholder="Credentials location, purpose, scenario…">${esc(n.notes)}</textarea></label>`;
        const key = C.nodeKey(n);
        $("i-label").addEventListener("change", e => saveAnn("nodes", key, { label: e.target.value.trim() }));
        $("i-role").addEventListener("change", e => saveAnn("nodes", key, { role: e.target.value }));
        $("i-notes").addEventListener("change", e => saveAnn("nodes", key, { notes: e.target.value.trim() }));
    }

    function select(id) { state.selected = id; renderAll(false); }

    /* ---------- pan / zoom ---------- */
    function applyView() { const v = state.pz; $("viewport").setAttribute("transform", `translate(${v.x},${v.y}) scale(${v.k})`); }
    function fitView() {
        const c = $("view-map"), r = state.render;
        if (!r || !c.clientWidth) return;
        const k = Math.min(c.clientWidth / r.w, c.clientHeight / r.h, 1.15);
        state.pz = { k, x: (c.clientWidth - r.w * k) / 2, y: Math.max(8, (c.clientHeight - r.h * k) / 2), fitted: true };
        applyView();
    }
    function zoomBy(f, cx, cy) {
        const c = $("view-map"), v = state.pz;
        cx = cx === undefined ? c.clientWidth / 2 : cx; cy = cy === undefined ? c.clientHeight / 2 : cy;
        const k = Math.min(4, Math.max(0.08, v.k * f));
        v.x = cx - (cx - v.x) * (k / v.k); v.y = cy - (cy - v.y) * (k / v.k); v.k = k; v.fitted = true;
        applyView();
    }
    function initCanvas() {
        const c = $("view-map");
        let drag = null, moved = false;
        c.addEventListener("mousedown", e => { if (e.button !== 0) return; drag = { sx: e.clientX, sy: e.clientY, x: state.pz.x, y: state.pz.y }; moved = false; });
        window.addEventListener("mouseup", () => { drag = null; c.classList.remove("dragging"); });
        window.addEventListener("mousemove", e => {
            if (!drag) return;
            const dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
            if (Math.abs(dx) + Math.abs(dy) > 4) { moved = true; c.classList.add("dragging"); }
            if (moved) { state.pz.x = drag.x + dx; state.pz.y = drag.y + dy; state.pz.fitted = true; applyView(); }
        });
        c.addEventListener("wheel", e => { e.preventDefault(); const r = c.getBoundingClientRect(); zoomBy(e.deltaY < 0 ? 1.15 : 1 / 1.15, e.clientX - r.left, e.clientY - r.top); }, { passive: false });
        c.addEventListener("click", e => {
            if (moved) { moved = false; return; }
            const nd = e.target.closest("[data-node]"), zn = e.target.closest("[data-zone]");
            if (nd) select(nd.getAttribute("data-node"));
            else if (zn) select("zone:" + zn.getAttribute("data-zone"));
            else if (state.selected) select(null);
        });
        $("z-in").addEventListener("click", () => zoomBy(1.25));
        $("z-out").addEventListener("click", () => zoomBy(0.8));
        $("z-fit").addEventListener("click", fitView);
        window.addEventListener("resize", () => { if (!state.pz.userMoved) fitView(); });
    }

    /* ---------- export ---------- */
    function download(name, mime, data) {
        const a = document.createElement("a");
        const url = URL.createObjectURL(data instanceof Blob ? data : new Blob([data], { type: mime }));
        a.href = url; a.download = name;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(url), 2000);
    }
    function doExport(kind) {
        const m = state.model;
        if (!m) { setStatus("Nothing to export yet. Run a scan first."); return; }
        const stamp = new Date().toISOString().slice(0, 10);
        try {
            if (kind === "svg" || kind === "png") {
                const opts = { theme: C.THEMES.light, query: "" };
                const r = state.view === "topology" ? C.renderTree(m, opts) : C.renderZones(m, opts);
                const svg = C.standaloneSvg(r, C.THEMES.light, "Network map");
                if (kind === "svg") { download(`network-map-${stamp}.svg`, "image/svg+xml", svg); return; }
                const img = new Image();
                img.onload = () => {
                    const scale = Math.min(2, 8000 / Math.max(r.w, r.h));
                    const cv = document.createElement("canvas");
                    cv.width = Math.round(r.w * scale); cv.height = Math.round(r.h * scale);
                    const ctx = cv.getContext("2d"); ctx.scale(scale, scale); ctx.drawImage(img, 0, 0);
                    cv.toBlob(b => b && download(`network-map-${stamp}.png`, "image/png", b), "image/png");
                };
                img.onerror = () => setStatus("PNG export failed. Use SVG instead.");
                img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
            } else if (kind === "md") download(`lab-report-${stamp}.md`, "text/markdown", C.toMarkdown(m));
            else if (kind === "csv") download(`inventory-${stamp}.csv`, "text/csv", C.toCsv(m));
            else if (kind === "json") download(`network-map-${stamp}.json`, "application/json", C.serialize(m));
        } catch (e) { setStatus("Export failed: " + (e.message || e)); }
    }

    /* ---------- VLAN helper ---------- */
    function vlanCommands() {
        const parent = $("vh-parent").value, id = Number($("vh-id").value), addr = $("vh-addr").value.trim(), mode = $("vh-mode").value;
        if (!/^[A-Za-z0-9._:-]{1,15}$/.test(parent) || !(id >= 1 && id <= 4094) || !/^\d+\.\d+\.\d+\.\d+\/\d{1,2}$/.test(addr)) return "# Enter a valid parent interface, VLAN ID (1-4094) and address/prefix.";
        const ifn = parent + "." + id;
        if (mode === "nmcli") {
            return [`sudo nmcli connection add type vlan con-name vlan${id} ifname ${ifn} dev ${parent} id ${id} ipv4.method manual ipv4.addresses ${addr}`,
                `sudo nmcli connection up vlan${id}`, "", "# undo", `sudo nmcli connection delete vlan${id}`].join("\n");
        }
        return [`sudo ip link add link ${parent} name ${ifn} type vlan id ${id}`, `sudo ip addr add ${addr} dev ${ifn}`, `sudo ip link set ${ifn} up`, "", "# undo", `sudo ip link del ${ifn}`].join("\n");
    }
    function openVlanHelper() {
        const sel = $("vh-parent");
        sel.innerHTML = state.ifnames.filter(n => !n.includes(".")).map(n => `<option>${esc(n)}</option>`).join("") || "<option>eth0</option>";
        $("vh-out").value = vlanCommands();
        const d = $("vlan-dialog");
        if (d.showModal) d.showModal(); else d.setAttribute("open", "");
    }

    /* ---------- init ---------- */
    function init() {
        state.ann = store.get("nm.ann", { nodes: {}, zones: {} });
        state.extra = store.get("nm.extra", []);

        document.querySelectorAll(".nm-tabs button").forEach(b => b.addEventListener("click", () => { state.view = b.dataset.view; state.pz.fitted = false; renderAll(true); }));
        $("btn-scan").addEventListener("click", scan);
        $("btn-stop").addEventListener("click", stopScan);
        $("btn-reload").addEventListener("click", async () => { await loadHost(); renderAll(false); });
        $("btn-vlan").addEventListener("click", openVlanHelper);
        $("export").addEventListener("change", e => { if (e.target.value) doExport(e.target.value); e.target.value = ""; });
        $("btn-log").addEventListener("click", () => { const l = $("log"); l.hidden = !l.hidden; $("btn-log").textContent = l.hidden ? "Show log" : "Hide log"; });
        $("btn-clear").addEventListener("click", () => {
            ["nm.ann", "nm.model", "nm.picked", "nm.extra"].forEach(store.del);
            state.ann = { nodes: {}, zones: {} }; state.extra = []; state.model = null; state.selected = null;
            loadHost().then(() => { renderAll(true); setStatus("Saved data cleared."); });
        });
        $("search").addEventListener("input", e => { state.query = e.target.value; renderAll(false); });

        $("zone-list").addEventListener("click", e => {
            const row = e.target.closest(".nm-zone");
            if (!row) return;
            const id = row.dataset.zone;
            if (e.target.matches("input[type=checkbox]")) {
                if (e.target.checked) state.picked.add(id); else state.picked.delete(id);
                store.set("nm.picked", [...state.picked]);
                return;
            }
            if (state.model && state.model.zones.has(id) && (state.model.zones.get(id).scanned)) select("zone:" + id);
        });
        $("add-form").addEventListener("submit", e => {
            e.preventDefault();
            const v = $("add-cidr").value.trim();
            if (!/^\d+\.\d+\.\d+\.\d+\/\d{1,2}$/.test(v) || v.split("/")[0].split(".").some(o => Number(o) > 255) || Number(v.split("/")[1]) < 20 || Number(v.split("/")[1]) > 30) {
                setStatus("Enter a subnet like 10.20.0.0/24 (prefix between /20 and /30)."); return;
            }
            const cidr = C.cidrNet(v.split("/")[0], Number(v.split("/")[1]));
            if (!state.extra.includes(cidr)) { state.extra.push(cidr); store.set("nm.extra", state.extra); }
            $("add-cidr").value = "";
            loadHost().then(() => { state.picked.add("manual:" + cidr); store.set("nm.picked", [...state.picked]); renderSidebar(); });
        });

        ["vh-parent", "vh-id", "vh-addr", "vh-mode"].forEach(id => $(id).addEventListener("input", () => { $("vh-out").value = vlanCommands(); }));
        $("vh-copy").addEventListener("click", () => {
            const ta = $("vh-out");
            ta.select();
            let ok = false;
            try { ok = document.execCommand("copy"); } catch (e) { /* ignore */ }
            if (!ok && navigator.clipboard) navigator.clipboard.writeText(ta.value).catch(() => {});
        });
        $("view-inventory").addEventListener("click", e => {
            const th = e.target.closest("th[data-sort]");
            if (th) { const c = th.dataset.sort; state.sort = { col: c, dir: state.sort.col === c ? -state.sort.dir : 1 }; renderInventory(); return; }
            const tr = e.target.closest("tr[data-id]");
            if (tr) { state.selected = tr.dataset.id; renderInspector(); }
        });
        $("view-vlans").addEventListener("click", e => {
            const tr = e.target.closest("tr[data-id]");
            if (tr && state.model && state.model.zones.has(tr.dataset.zone) && state.model.zones.get(tr.dataset.zone).scanned) { state.selected = tr.dataset.id; renderInspector(); }
        });

        initCanvas();
        // re-render on theme changes
        new MutationObserver(() => renderMap(false)).observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
        if (window.matchMedia) { const mq = window.matchMedia("(prefers-color-scheme: dark)"); if (mq.addEventListener) mq.addEventListener("change", () => renderMap(false)); }

        // restore the previous scan
        try {
            const raw = store.raw("nm.model");
            if (raw) { const m = C.deserialize(raw); if (m) { finalize(m); state.model = m; } }
        } catch (e) { /* corrupted saved model: ignore */ }

        loadHost().then(async () => {
            renderAll(true);
            const tools = await Promise.all(["nmap", "lldpctl", "traceroute", "snmpwalk"].map(async c => c + ((await has(c)) ? " ✓" : " ✗")));
            log("Network Map " + C.VERSION + ". Optional tools: " + tools.join("   "));
            setStatus(state.model ? "Showing the last saved scan." : "Ready.");
        });
    }

    document.addEventListener("DOMContentLoaded", init);
}());
