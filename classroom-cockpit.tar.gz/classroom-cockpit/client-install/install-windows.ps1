#Requires -RunAsAdministrator
$ErrorActionPreference = "Stop"

# ---- EDIT THESE TWO LINES ----
$admin  = "10.200.0.10"
$dlport = 11099
# -------------------------------

if (-not (Get-Command pythonw -ErrorAction SilentlyContinue)) {
  throw "Python is not installed. Run offline/prepare-wheelhouse.ps1's python-installer.exe first (this machine itself never needs internet)."
}

$t = New-TemporaryFile; Remove-Item $t; New-Item -ItemType Directory $t | Out-Null
$wheelhouse = $null
try {
  Invoke-WebRequest "http://$admin`:$dlport/wheelhouse-windows.tar.gz" -OutFile "$t\wheelhouse.tar.gz" -UseBasicParsing -ErrorAction Stop
  New-Item -ItemType Directory "$t\wheelhouse" | Out-Null
  tar -xzf "$t\wheelhouse.tar.gz" -C "$t\wheelhouse"
  $wheelhouse = "$t\wheelhouse"
} catch { Write-Warning "No wheelhouse-windows.tar.gz on admin server - pip will need internet." }

# pip only accepts wheels matching THIS machine's exact Python minor version/bitness.
# If the wheelhouse was built on a different one, pip will see e.g. pillow-12.3.0 sitting
# right there in the folder and still refuse it as incompatible - which looks exactly
# like "pip can't find pillow" even though the file is present. Catch that up front.
$here_ver = & python -c "import sys,struct; print(f'{sys.version_info.major}.{sys.version_info.minor}-{struct.calcsize(chr(80))*8}bit')"
if ($wheelhouse -and (Test-Path "$wheelhouse\python-version.txt")) {
  $built_for = Get-Content "$wheelhouse\python-version.txt" -Raw
  if ($built_for -ne $here_ver) {
    Write-Warning "wheelhouse-windows.tar.gz was built for Python $built_for but this machine has Python $here_ver - pip will likely reject these wheels as incompatible. Re-run prepare-wheelhouse.ps1 on a machine with Python $here_ver, or install that version here instead."
  }
}

try {
  if ($wheelhouse) {
    if (Test-Path "$wheelhouse\requirements-wheelhouse.txt") {
      python -m pip install --no-index --find-links $wheelhouse --requirement "$wheelhouse\requirements-wheelhouse.txt"
    } else {
      python -m pip install --no-index --find-links $wheelhouse pillow pyautogui pycaw comtypes
    }
  } else {
    python -m pip install --upgrade pillow pyautogui pycaw comtypes
  }
} catch {
  throw "pip install failed (this machine is Python $here_ver). If you're using an offline wheelhouse bundle, this almost always means it was built for a different Python version/bitness (see any warning above) - re-run prepare-wheelhouse.ps1 on a machine with Python $here_ver installed. Original error: $_"
}

$dir = "$env:ProgramFiles\ClassroomAgent"
New-Item -Force -ItemType Directory $dir, "C:\ProgramData\Classroom" | Out-Null
Invoke-WebRequest "http://$admin`:$dlport/agent-bundle.tar.gz" -OutFile "$t\b.tar.gz" -UseBasicParsing
New-Item -ItemType Directory "$t\b" | Out-Null
tar -xzf "$t\b.tar.gz" -C "$t\b"
Copy-Item "$t\b\classroom_agent.py" $dir -Force
Copy-Item "$t\b\agent.json" "C:\ProgramData\Classroom\agent.json" -Force

New-NetFirewallRule -DisplayName "Classroom Agent TCP" -Direction Inbound -Protocol TCP -LocalPort 11100 -RemoteAddress $admin -Action Allow -ErrorAction SilentlyContinue | Out-Null
New-NetFirewallRule -DisplayName "Classroom Agent UDP" -Direction Inbound -Protocol UDP -LocalPort 11101 -Action Allow -ErrorAction SilentlyContinue | Out-Null

$pyw = (Get-Command pythonw).Source
$act = New-ScheduledTaskAction -Execute $pyw -Argument "`"$dir\classroom_agent.py`""
$trg = New-ScheduledTaskTrigger -AtLogOn
$pri = New-ScheduledTaskPrincipal -GroupId "BUILTIN\Users" -RunLevel Highest
Register-ScheduledTask -TaskName ClassroomAgent -Action $act -Trigger $trg -Principal $pri -Force | Out-Null
Start-ScheduledTask -TaskName ClassroomAgent
Remove-Item -Recurse -Force $t
Write-Host "Classroom agent installed."