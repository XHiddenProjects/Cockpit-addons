#!/bin/bash
# Inventory agent uninstaller for Linux (systemd).
# Usage: curl -fsSL <server>/agent/uninstall.sh | sudo bash
#    or: sudo bash uninstall.sh [--install-dir <path>] [--delay <seconds>]
#
# --delay N  schedule the removal N seconds from now in a separate systemd
#            unit and return immediately. The server's "Uninstall" job uses
#            this so the agent can still report the job result before the
#            agent it runs inside is stopped and deleted.
set -euo pipefail

INSTALL_DIR="/opt/inventory-agent"
STATE_DIR="/var/lib/inventory-agent"
UNIT="inventory-agent.service"
DELAY="${INVENTORY_UNINSTALL_DELAY:-0}"

while [ $# -gt 0 ]; do
  case "$1" in
    --install-dir) INSTALL_DIR="$2"; shift 2 ;;
    --delay) DELAY="$2"; shift 2 ;;
    *) echo "Unknown argument: $1" >&2; exit 1 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then
  echo "This uninstaller must be run as root (sudo)." >&2
  exit 1
fi
case "$DELAY" in ''|*[!0-9]*) echo "--delay must be a whole number of seconds." >&2; exit 1 ;; esac
case "$INSTALL_DIR" in
  ''|/|/usr|/usr/*|/etc|/var|/home|/root|/opt) echo "Refusing to remove unsafe install dir: '$INSTALL_DIR'" >&2; exit 1 ;;
esac

# Stop is LAST: if this ever runs inside the agent's own cgroup (no systemd-run),
# stopping the unit also ends the script, so nothing may come after it.
HELPER="$(mktemp /var/tmp/inventory-agent-uninstall.XXXXXX)"
cat > "$HELPER" <<HELPER_EOF
#!/bin/bash
systemctl disable "$UNIT" >/dev/null 2>&1 || true
rm -f "/etc/systemd/system/$UNIT"
rm -rf "$INSTALL_DIR" "$STATE_DIR"
systemctl daemon-reload >/dev/null 2>&1 || true
systemctl stop "$UNIT" >/dev/null 2>&1 || true
systemctl reset-failed "$UNIT" >/dev/null 2>&1 || true
HELPER_EOF
chmod 700 "$HELPER"

if [ "$DELAY" -eq 0 ]; then
  echo "Removing inventory agent ..."
  /bin/bash "$HELPER"
  rm -f "$HELPER"
  echo "Inventory agent removed."
  exit 0
fi

if command -v systemd-run >/dev/null 2>&1 && [ -d /run/systemd/system ]; then
  # A transient unit has its own cgroup, so stopping the agent cannot kill it.
  systemd-run --quiet --collect --unit="inventory-agent-uninstall-$$" --on-active="${DELAY}s" \
    /bin/bash -c "/bin/bash '$HELPER'; rm -f '$HELPER'"
else
  nohup setsid /bin/bash -c "sleep $DELAY; /bin/bash '$HELPER'; rm -f '$HELPER'" >/dev/null 2>&1 &
fi
echo "Inventory agent removal scheduled in ${DELAY}s."
