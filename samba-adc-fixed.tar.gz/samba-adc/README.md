# Samba AD DC — Cockpit module

A Cockpit page for administering a Samba Active Directory Domain Controller
on Debian 13. It's a thin, dependency-free UI over `samba-tool`, `testparm`,
and `systemctl` — no separate daemon, no database of its own, no build step.

## Coverage

Each of these is its own tab:

| Tab | Backed by | Covers |
|---|---|---|
| Overview | `domain info`, `drs showrepl` | Quick health snapshot |
| Domain | `domain info/level/passwordsettings` | Functional level, password & lockout policy |
| Forest | `forest directory_service` | dsHeuristics |
| FSMO | `fsmo show/transfer/seize` | All FSMO roles |
| Sites | `sites …`, `sites subnet …` | Sites and subnets |
| DNS | `dns zonecreate/zonelist/add/delete/query` | Zones and records |
| Users | `user …`, `user_backend.py` | Create/**edit attributes**/delete/enable/disable/unlock/reset password/move/groups, bulk actions, first/last name columns, spreadsheet import |
| Groups | `group …` | Create/delete/members/move, bulk actions |
| Computers | `computer …` | Create/delete/show/list/move, bulk actions |
| Contacts | `contact …` | Create/delete/show/move, bulk actions |
| Organizational Units | `ou …` | Create/delete/rename/move, bulk actions |
| Group Policy | GPMC-style manager + GPME-style editor (see below) | Link order/enforce/block inheritance, inheritance view, Administrative Templates (ADMX), Security Settings, Scripts, Preferences, Settings report |
| SPNs | `spn …` | List/add/delete per account |
| Delegation | `delegation …` | Show, unconstrained/protocol-transition toggles, constrained service delegation |
| ACLs | `dsacl …`, `ntacl …` | Directory-object ACLs by DN, filesystem ACLs by path, sysvol check/reset |
| Server Time | `time` | Query a server's time |
| File Shares | `smb.conf` sections | Add/edit/delete Samba shares, create backing directories, sets real filesystem permissions |
| Configuration | `smb.conf`, `testparm` | Full raw editor, validated before every save |

Passwords (user creation, password reset) are always sent over the
process's stdin, never as a command-line argument, so they never show up in
`ps`. Every `smb.conf` write (Configuration tab and File Shares tab) is
checked with `testparm -s` against a scratch copy before it's allowed to
overwrite the real file, so a bad edit can't take Samba down; a successful
save triggers `systemctl reload` on the selected service.

### Moving objects between OUs

Every "Move" action (Users, Groups, Computers, Contacts, Organizational
Units) opens a visual picker of the actual OU/container tree &mdash; built
from `samba-tool ou list` plus the well-known default containers
(`CN=Users`, `CN=Computers`, `CN=Builtin`) &mdash; so picking a destination
is click-to-select rather than typing an LDAP DN by hand. A "Type a DN
instead" link is still there as a fallback for containers the tree doesn't
know about.

### Bulk actions

Users, Groups, Computers, Contacts, and Organizational Units all have a
checkbox column and a "select all" header checkbox. Selecting one or more
rows reveals a bulk-action bar (Delete, Move&hellip;, and for Users,
Enable/Disable) that runs the action against every selected item, sequentially,
and reports back which ones succeeded and which failed rather than stopping
at the first error.

### First/last name on the Users list

The Users table shows First name and Last name columns (blank/&mdash; when
not set on that account), fetched efficiently with one bulk `ldbsearch`
query against the local database rather than one `samba-tool user show`
call per user. If `ldbsearch` (from the `ldb-tools` package) isn't
available, it automatically falls back to `samba-tool user show` per user,
run with limited concurrency so a large directory doesn't spawn dozens of
escalated processes at once.

### Importing users from a spreadsheet

"Import from spreadsheet&hellip;" on the Users tab accepts .csv, .xlsx,
.xls, or .ods &mdash; parsed entirely in the browser (via a locally-vendored
copy of [SheetJS](https://sheetjs.com), `vendor/xlsx.core.min.js`, Apache-2.0
licensed &mdash; no file ever needs to touch the server just to be read, and
no external network request is made to parse it). After picking a file you
get:

- **A preview** of the first few rows, so you can confirm it parsed correctly.
- **Column mapping**: each target field (Username, First name, Last name,
  Email, Password, Groups) gets a dropdown of the file's actual column
  headers, pre-guessed from common header names (`username`/`sAMAccountName`,
  `first name`/`givenName`, etc.) but fully overridable. Username is the only
  required mapping.
- **Import settings applied to every row**: which OU/container to create the
  accounts in (the same visual tree picker used for Move), a password
  strategy (generate a random password per user, or fall back to one shared
  password for rows without their own), "must change password at next
  logon", and a set of groups to add every imported user to (merged with
  whatever's in each row's own Groups column, if mapped).
- Usernames that already exist are always skipped, never overwritten.

After the import runs, a results dialog lists every row's outcome
(created/skipped/failed, with the reason for skips and failures), and shows
any auto-generated passwords **once** &mdash; there's a "Download results
(CSV)" button to capture them, since they aren't retrievable afterward.
There's also a "Download a CSV template" link on the file-picker step to get
the expected column layout right from the start.


### File share permissions (why Windows said "access denied")

Two things have to line up for a Windows client to get into a share on an
AD DC, and this module now sets up both:

1. **`valid users` must name groups as groups.** In `smb.conf`,
   `valid users = Sales` means a *user* called Sales. A group must be written
   `@"DOMAIN\Sales"`. The share form now writes the correct form
   automatically (it knows which names are users and which are groups), and
   reads existing `@"DOMAIN\Group"` entries back into the picker.
2. **The share needs a Windows (NT) ACL, not just POSIX permissions.**
   Windows clients are gated by the NT ACL that `vfs_acl_xattr` keeps on the
   directory. "Create/fix directory & permissions" now looks up each named
   user/group's SID from the directory (no NSS/winbind name resolution
   needed), writes an NT ACL granting them Modify (or Read for read-only
   shares) with `samba-tool ntacl set`, opens the POSIX mode to `3777` so the
   NT ACL is the real gate, and shows the ACL now on disk so you can verify
   it. Saved shares get `vfs objects = acl_xattr`, `map acl inherit = yes`,
   `store dos attributes = yes` and `acl_xattr:ignore system acls = yes`.
   Any other parameters you added to a share by hand are preserved when the
   share is edited.

The ACL is applied to the share's root directory and inherited by new
content. Existing subfolders keep their old ACLs; use Windows' Security tab
("Replace all child object permissions") to push it down.

After changing access, Windows caches sessions and group tokens: disconnect
the mapped drive (`net use * /delete`), and log off/on if the user was only
just added to the group.

### Windows network discovery and "I can see it but can't open it"

Windows 10/11 find servers through **WS-Discovery** and then open
`\\<announced name>`. Discovery working only proves the *announcement*
reached the client; opening the server needs several other things. The
**Configuration → File sharing & network discovery** card runs checks for each:

| Check | What goes wrong without it |
|---|---|
| Discovery daemon | Not installed, stopped, or (wsdd2 on an AD DC) refused by systemd, see below |
| TCP 445 listening on the real interface | `bind interfaces only` / `interfaces` mistakes |
| Announced name == NetBIOS/DNS name | Explorer shows the OS hostname; if Samba/DNS know the server by another name, the click goes nowhere |
| Hostname does not resolve to `127.0.1.1` | Debian's default `/etc/hosts` makes Samba hand out an unreachable address |
| A record in AD DNS matches this host | Windows resolves `\\name` through DNS; no record = "network path not found" |
| Firewall (ufw / firewalld / nftables) | The discovery ports pass but TCP 445 is blocked (or the reverse) |
| Each share | Missing path, no Windows ACL yet, unresolvable `valid users` groups, `guest ok` (blocked by Windows 11 24H2) |

Each failing check has a one-click fix where that is safe (install/bind the
daemon, open firewall ports, refresh DNS records). On the **Shares** tab,
**Test access** signs in to a share from the server itself and reports which
layer fails: network, name, authentication, or share/folder permission, so you
can tell a server problem from a client problem.

**Package note (Debian 13):** the Python `wsdd` package is no longer in Debian
stable. Debian 13 ships **`wsdd2`**, which also answers LLMNR (a name-resolution
fallback for clients that do not use this DC for DNS). Debian's `wsdd2.service`
is bound to `smbd.service`, which is disabled on an AD DC, so the module writes a
drop-in (`/etc/systemd/system/wsdd2.service.d/samba-ad-dc.conf`) tying it to
`samba-ad-dc.service` instead. Ports: `wsdd2` needs UDP 3702, TCP 3702 and UDP/TCP
5355; the Python `wsdd`/`wsdd-server` needs UDP 3702 and TCP 5357. Both need TCP 445.

Client side (cannot be checked from the server): domain-joined clients should use
this DC as their DNS server; non-domain clients on a different DNS server can only
resolve the name through LLMNR (wsdd2) or a hosts entry.

### Group Policy

The **Group Policy** tab has two parts that mirror the Windows tools.

**Management (like GPMC):** a tree of the domain, OUs, sites and all GPOs.
Select a domain/OU to see its linked GPOs: change link order, toggle *Enforced*
and *Link enabled*, set *Block inheritance*, unlink, link an existing GPO or
create-and-link a new one. The *Group Policy Inheritance* tab computes the
effective precedence. Selecting a GPO shows *Scope* (where it is linked),
*Details* (versions, status, registered extensions) and *Settings* (a report of
everything configured). GPOs can be created, renamed, enabled/disabled per
computer/user side, and deleted (links are cleaned up).

**Editor (like GPME):** *Edit* opens Computer Configuration / User Configuration:

- **Administrative Templates**: browse categories, filter, *Not configured /
  Enabled / Disabled* with the real option controls (numbers, text, drop-downs,
  checkboxes, lists). Driven by ADMX/ADML, so any vendor's templates work.
  **Templates… → Download & install** fetches Microsoft's official *Administrative
  Templates (.admx) for Windows 11* (which also cover Windows Server of the same
  generation) onto the DC and installs them in the domain **Central Store**
  (`SYSVOL\<domain>\Policies\PolicyDefinitions`), the same thing you would do by hand
  on Windows. With that installed the tree has the same top-level categories as
  `gpedit.msc` (Control Panel, Desktop, Network, Printers, Server, Start Menu and
  Taskbar, System, Windows Components, All Settings) and ~4,500 policies; a small
  built-in set is used until then. Needs `msitools` (installed automatically) and
  internet access on the DC, or copy the `.msi` to the DC and use *An .msi file
  already on this server*. Other vendors' `.admx`/`.adml` can be uploaded, and Samba's
  own templates installed with one button.
- **Security Settings**: password and lockout policy; **Audit Policy** (legacy);
  **User Rights Assignment** (all 45 rights, with user/group lookup);
  **Security Options** (98 settings generated from Windows' own `sceregvl.inf`
  definitions, grouped like Windows, plus UAC/NTLM entries newer than that file);
  **Windows Defender Firewall with Advanced Security** (domain/private/public profile
  settings and logging, inbound and outbound rules); **Advanced Audit Policy
  Configuration** (all 52 subcategories, `audit.csv`).
- **Scripts**: startup/shutdown (computer) and logon/logoff (user), including
  PowerShell scripts; script files are stored in the GPO.
- **Preferences**: Registry items (computer and user) and Drive Maps (user).
- **Health check** (toolbar): verifies every GPO (SYSVOL folder, GPT.INI, AD/SYSVOL
  version, NT ACLs, client-side extensions registered) plus SYSVOL permissions, DNS SRV
  records, time sync, SPNs, firewall ports and each GPO's `gPCFileSysPath`, with
  per-item **Repair** and an **Auto-fix everything on the server** button that, in a
  safe order, defines a missing `[sysvol]`/`[netlogon]` (validated with `testparm`,
  `smb.conf` backed up), restarts a half-running DC service, enables time sync,
  registers missing SPNs, opens the AD ports in ufw/firewalld, runs
  `samba-tool ntacl sysvolreset` and `samba_dnsupdate`, repairs every inconsistent
  GPO and removes links to deleted GPOs, then re-checks.
  **Windows client fix script…** generates a PowerShell script for your domain
  (`client-fix.ps1.tpl`) for the client half of event 1058, which the server cannot
  repair remotely (and a GPO cannot deliver it, because the client cannot read
  SYSVOL): it fixes DNS, resyncs the clock, purges Kerberos tickets, checks/repairs
  the secure channel, tests reading SYSVOL with the real error, and runs `gpupdate`.

Nodes in the tree that this tool cannot edit (Software Settings, Name Resolution
Policy, Deployed Printers, Public Key Policies, AppLocker, Software Restriction,
IPsec, Network List Manager, Folder Redirection, Restricted Groups, System Services,
Registry/File System ACLs, wired/wireless policies, Kerberos, Event Log, QoS) are
shown with an explanation. Edit those from a Windows PC with RSAT
(`gpmc.msc`); changes coexist because both use the standard SYSVOL layout.

Every change is written immediately (like GPME) and bumps the GPO version and
registers the client-side extension so clients actually pick it up.

How it works: the module writes AD objects through the local `sam.ldb` and the
GPO files straight into the SYSVOL folder as root (case-insensitive, because Samba
creates `MACHINE`/`USER` in upper case), then applies the GPO's NT ACL to each new
file, which is what `samba-tool ntacl sysvolreset` does. This needs **no domain
credentials**. (It is deliberate: the DC's machine account is *not* allowed to write
into SYSVOL over SMB, so `samba-tool gpo create/load` with `-P` fails.)

Also not included: security filtering and delegation editing, WMI filters, GPO
backup/restore, and Preference types other than Registry and Drive Maps.
Account/password policy: Samba's AD DC enforces the *domain* password policy from
the directory (`samba-tool domain passwordsettings`), not from the GPO; GPO
account policy only affects local accounts of computers in the linked OU.

**Tested vs. not tested.** The AD/SYSVOL layer, Registry.pol (byte-identical to
Samba's own serialiser), GptTmpl.inf, audit.csv, scripts and the UI were tested
against a real Samba 4.19 DC. Not tested on a real Windows client: that the
firewall rule string format, the audit CSE GUID and the Preferences XML are accepted by
a Windows 11 client (they follow Microsoft's documented formats), nor against
Samba 4.22 (Debian 13). Verify with `gpresult /h report.html` on a client.

### First/last name on the Users list

The Users table shows First name and Last name columns (blank/&mdash; when
not set on that account), fetched efficiently with one bulk `ldbsearch`
query against the local database rather than one `samba-tool user show`
call per user. If `ldbsearch` (from the `ldb-tools` package) isn't
available, it automatically falls back to `samba-tool user show` per user,
run with limited concurrency so a large directory doesn't spawn dozens of
escalated processes at once.

### Importing users from a spreadsheet

"Import from spreadsheet&hellip;" on the Users tab accepts .csv, .xlsx,
.xls, or .ods &mdash; parsed entirely in the browser (via a locally-vendored
copy of [SheetJS](https://sheetjs.com), `vendor/xlsx.core.min.js`, Apache-2.0
licensed &mdash; no file ever needs to touch the server just to be read, and
no external network request is made to parse it). After picking a file you
get:

- **A preview** of the first few rows, so you can confirm it parsed correctly.
- **Column mapping**: each target field (Username, First name, Last name,
  Email, Password, Groups) gets a dropdown of the file's actual column
  headers, pre-guessed from common header names (`username`/`sAMAccountName`,
  `first name`/`givenName`, etc.) but fully overridable. Username is the only
  required mapping.
- **Import settings applied to every row**: which OU/container to create the
  accounts in (the same visual tree picker used for Move), a password
  strategy (generate a random password per user, or fall back to one shared
  password for rows without their own), "must change password at next
  logon", and a set of groups to add every imported user to (merged with
  whatever's in each row's own Groups column, if mapped).
- Usernames that already exist are always skipped, never overwritten.

After the import runs, a results dialog lists every row's outcome
(created/skipped/failed, with the reason for skips and failures), and shows
any auto-generated passwords **once** &mdash; there's a "Download results
(CSV)" button to capture them, since they aren't retrievable afterward.
There's also a "Download a CSV template" link on the file-picker step to get
the expected column layout right from the start.


### File share permissions (why Windows said "access denied")

Two things have to line up for a Windows client to get into a share on an
AD DC, and this module now sets up both:

1. **`valid users` must name groups as groups.** In `smb.conf`,
   `valid users = Sales` means a *user* called Sales. A group must be written
   `@"DOMAIN\Sales"`. The share form now writes the correct form
   automatically (it knows which names are users and which are groups), and
   reads existing `@"DOMAIN\Group"` entries back into the picker.
2. **The share needs a Windows (NT) ACL, not just POSIX permissions.**
   Windows clients are gated by the NT ACL that `vfs_acl_xattr` keeps on the
   directory. "Create/fix directory & permissions" now looks up each named
   user/group's SID from the directory (no NSS/winbind name resolution
   needed), writes an NT ACL granting them Modify (or Read for read-only
   shares) with `samba-tool ntacl set`, opens the POSIX mode to `3777` so the
   NT ACL is the real gate, and shows the ACL now on disk so you can verify
   it. Saved shares get `vfs objects = acl_xattr`, `map acl inherit = yes`,
   `store dos attributes = yes` and `acl_xattr:ignore system acls = yes`.
   Any other parameters you added to a share by hand are preserved when the
   share is edited.

The ACL is applied to the share's root directory and inherited by new
content. Existing subfolders keep their old ACLs; use Windows' Security tab
("Replace all child object permissions") to push it down.

After changing access, Windows caches sessions and group tokens: disconnect
the mapped drive (`net use * /delete`), and log off/on if the user was only
just added to the group.

### Windows network discovery and "I can see it but can't open it"

Windows 10/11 find servers through **WS-Discovery** and then open
`\\<announced name>`. Discovery working only proves the *announcement*
reached the client; opening the server needs several other things. The
**Configuration → File sharing & network discovery** card runs checks for each:

| Check | What goes wrong without it |
|---|---|
| Discovery daemon | Not installed, stopped, or (wsdd2 on an AD DC) refused by systemd, see below |
| TCP 445 listening on the real interface | `bind interfaces only` / `interfaces` mistakes |
| Announced name == NetBIOS/DNS name | Explorer shows the OS hostname; if Samba/DNS know the server by another name, the click goes nowhere |
| Hostname does not resolve to `127.0.1.1` | Debian's default `/etc/hosts` makes Samba hand out an unreachable address |
| A record in AD DNS matches this host | Windows resolves `\\name` through DNS; no record = "network path not found" |
| Firewall (ufw / firewalld / nftables) | The discovery ports pass but TCP 445 is blocked (or the reverse) |
| Each share | Missing path, no Windows ACL yet, unresolvable `valid users` groups, `guest ok` (blocked by Windows 11 24H2) |

Each failing check has a one-click fix where that is safe (install/bind the
daemon, open firewall ports, refresh DNS records). On the **Shares** tab,
**Test access** signs in to a share from the server itself and reports which
layer fails: network, name, authentication, or share/folder permission, so you
can tell a server problem from a client problem.

**Package note (Debian 13):** the Python `wsdd` package is no longer in Debian
stable. Debian 13 ships **`wsdd2`**, which also answers LLMNR (a name-resolution
fallback for clients that do not use this DC for DNS). Debian's `wsdd2.service`
is bound to `smbd.service`, which is disabled on an AD DC, so the module writes a
drop-in (`/etc/systemd/system/wsdd2.service.d/samba-ad-dc.conf`) tying it to
`samba-ad-dc.service` instead. Ports: `wsdd2` needs UDP 3702, TCP 3702 and UDP/TCP
5355; the Python `wsdd`/`wsdd-server` needs UDP 3702 and TCP 5357. Both need TCP 445.

Client side (cannot be checked from the server): domain-joined clients should use
this DC as their DNS server; non-domain clients on a different DNS server can only
resolve the name through LLMNR (wsdd2) or a hosts entry.

### Group Policy

The **Group Policy** tab has two parts that mirror the Windows tools.

**Management (like GPMC):** a tree of the domain, OUs, sites and all GPOs.
Select a domain/OU to see its linked GPOs: change link order, toggle *Enforced*
and *Link enabled*, set *Block inheritance*, unlink, link an existing GPO or
create-and-link a new one. The *Group Policy Inheritance* tab computes the
effective precedence. Selecting a GPO shows *Scope* (where it is linked),
*Details* (versions, status, registered extensions) and *Settings* (a report of
everything configured). GPOs can be created, renamed, enabled/disabled per
computer/user side, and deleted (links are cleaned up).

**Editor (like GPME):** *Edit* opens Computer Configuration / User Configuration:

- **Administrative Templates**: browse categories, filter, *Not configured /
  Enabled / Disabled* with the real option controls (numbers, text, drop-downs,
  checkboxes, lists). Driven by ADMX/ADML, so any vendor's templates work.
  **Templates… → Download & install** fetches Microsoft's official *Administrative
  Templates (.admx) for Windows 11* (which also cover Windows Server of the same
  generation) onto the DC and installs them in the domain **Central Store**
  (`SYSVOL\<domain>\Policies\PolicyDefinitions`), the same thing you would do by hand
  on Windows. With that installed the tree has the same top-level categories as
  `gpedit.msc` (Control Panel, Desktop, Network, Printers, Server, Start Menu and
  Taskbar, System, Windows Components, All Settings) and ~4,500 policies; a small
  built-in set is used until then. Needs `msitools` (installed automatically) and
  internet access on the DC, or copy the `.msi` to the DC and use *An .msi file
  already on this server*. Other vendors' `.admx`/`.adml` can be uploaded, and Samba's
  own templates installed with one button.
- **Security Settings**: password and lockout policy; **Audit Policy** (legacy);
  **User Rights Assignment** (all 45 rights, with user/group lookup);
  **Security Options** (98 settings generated from Windows' own `sceregvl.inf`
  definitions, grouped like Windows, plus UAC/NTLM entries newer than that file);
  **Windows Defender Firewall with Advanced Security** (domain/private/public profile
  settings and logging, inbound and outbound rules); **Advanced Audit Policy
  Configuration** (all 52 subcategories, `audit.csv`).
- **Scripts**: startup/shutdown (computer) and logon/logoff (user), including
  PowerShell scripts; script files are stored in the GPO.
- **Preferences**: Registry items (computer and user) and Drive Maps (user).
- **Health check** (toolbar): verifies every GPO (SYSVOL folder, GPT.INI, AD/SYSVOL
  version, NT ACLs, client-side extensions registered) plus SYSVOL permissions, DNS SRV
  records, time sync, SPNs, firewall ports and each GPO's `gPCFileSysPath`, with
  per-item **Repair** and an **Auto-fix everything on the server** button that, in a
  safe order, defines a missing `[sysvol]`/`[netlogon]` (validated with `testparm`,
  `smb.conf` backed up), restarts a half-running DC service, enables time sync,
  registers missing SPNs, opens the AD ports in ufw/firewalld, runs
  `samba-tool ntacl sysvolreset` and `samba_dnsupdate`, repairs every inconsistent
  GPO and removes links to deleted GPOs, then re-checks.
  **Windows client fix script…** generates a PowerShell script for your domain
  (`client-fix.ps1.tpl`) for the client half of event 1058, which the server cannot
  repair remotely (and a GPO cannot deliver it, because the client cannot read
  SYSVOL): it fixes DNS, resyncs the clock, purges Kerberos tickets, checks/repairs
  the secure channel, tests reading SYSVOL with the real error, and runs `gpupdate`.

Nodes in the tree that this tool cannot edit (Software Settings, Name Resolution
Policy, Deployed Printers, Public Key Policies, AppLocker, Software Restriction,
IPsec, Network List Manager, Folder Redirection, Restricted Groups, System Services,
Registry/File System ACLs, wired/wireless policies, Kerberos, Event Log, QoS) are
shown with an explanation. Edit those from a Windows PC with RSAT
(`gpmc.msc`); changes coexist because both use the standard SYSVOL layout.

Every change is written immediately (like GPME) and bumps the GPO version and
registers the client-side extension so clients actually pick it up.

How it works: the module writes AD objects through the local `sam.ldb` and the
GPO files straight into the SYSVOL folder as root (case-insensitive, because Samba
creates `MACHINE`/`USER` in upper case), then applies the GPO's NT ACL to each new
file, which is what `samba-tool ntacl sysvolreset` does. This needs **no domain
credentials**. (It is deliberate: the DC's machine account is *not* allowed to write
into SYSVOL over SMB, so `samba-tool gpo create/load` with `-P` fails.)

Not included: security filtering and delegation editing, WMI filters, GPO
backup/restore, Restricted Groups, Kerberos policy, and Preference types other
than Registry and Drive Maps. Account/password policy: Samba's AD DC enforces
the *domain* password policy from the directory (`samba-tool domain passwordsettings`),
not from the GPO; GPO account policy only affects local accounts of computers in
the linked OU.

### First/last name on the Users list

The Users table shows First name and Last name columns (blank/&mdash; when
not set on that account), fetched efficiently with one bulk `ldbsearch`
query against the local database rather than one `samba-tool user show`
call per user. If `ldbsearch` (from the `ldb-tools` package) isn't
available, it automatically falls back to `samba-tool user show` per user,
run with limited concurrency so a large directory doesn't spawn dozens of
escalated processes at once.

### Importing users from a spreadsheet

"Import from spreadsheet&hellip;" on the Users tab accepts .csv, .xlsx,
.xls, or .ods &mdash; parsed entirely in the browser (via a locally-vendored
copy of [SheetJS](https://sheetjs.com), `vendor/xlsx.core.min.js`, Apache-2.0
licensed &mdash; no file ever needs to touch the server just to be read, and
no external network request is made to parse it). After picking a file you
get:

- **A preview** of the first few rows, so you can confirm it parsed correctly.
- **Column mapping**: each target field (Username, First name, Last name,
  Email, Password, Groups) gets a dropdown of the file's actual column
  headers, pre-guessed from common header names (`username`/`sAMAccountName`,
  `first name`/`givenName`, etc.) but fully overridable. Username is the only
  required mapping.
- **Import settings applied to every row**: which OU/container to create the
  accounts in (the same visual tree picker used for Move), a password
  strategy (generate a random password per user, or fall back to one shared
  password for rows without their own), "must change password at next
  logon", and a set of groups to add every imported user to (merged with
  whatever's in each row's own Groups column, if mapped).
- Usernames that already exist are always skipped, never overwritten.

After the import runs, a results dialog lists every row's outcome
(created/skipped/failed, with the reason for skips and failures), and shows
any auto-generated passwords **once** &mdash; there's a "Download results
(CSV)" button to capture them, since they aren't retrievable afterward.
There's also a "Download a CSV template" link on the file-picker step to get
the expected column layout right from the start.


### File share permissions

Setting `valid users` / `force group` in `smb.conf` only controls who is
**allowed to connect** to a share at the SMB layer &mdash; it grants nothing
at the filesystem level. A directory created with plain `mkdir` is owned by
`root:root`, so even a perfectly correct `smb.conf` still leaves everyone
else denied by the underlying POSIX permissions. The "Create/fix directory &
permissions" button (and the automatic re-check that runs after every share
save) applies real POSIX ACLs via `setfacl` for every account actually named
in Valid users / Force user / Force group &mdash; including default ACLs so
files and subdirectories created later inherit the same access &mdash; so
the filesystem actually matches what the share configuration says. This
needs the `acl` package (`setfacl`/`getfacl`) installed, which is present on
most Debian installs by default; if it's missing, `apt install acl`. If a
specific name still fails to get access after this, that name isn't
resolving to a valid uid/gid on this host, which points at a winbind/idmap
configuration issue rather than a share-permission one &mdash; `getent
passwd <name>` / `getent group <name>` on this DC is the next thing to
check.

## Requirements

- Debian 13 with Cockpit installed (`apt install cockpit`) and a working
  Samba AD DC (`samba-ad-dc` package, `samba-tool` on the `PATH`). The Group Policy
  and diagnostics helpers also need `python3` with Samba's Python modules
  (installed with `samba-ad-dc`) and `smbclient` for the sign-in test.
- The Cockpit user must be able to gain administrative access in Cockpit
  (in `sudo`, or root) — every privileged call uses Cockpit's normal
  "Administrative access" escalation (`superuser: "require"`).
- DNS, GPO link management, and Delegation use RPC calls that need domain
  administrator credentials, entered once per browser session in the DNS
  tab (kept in memory only, never written to disk).

## Install

```bash
tar xzf cockpit-samba-adc.tar.gz
cd cockpit-samba-adc
sudo ./install.sh
```

or manually:

```bash
sudo mkdir -p /usr/share/cockpit
sudo cp -r samba-adc /usr/share/cockpit/samba-adc
sudo chown -R root:root /usr/share/cockpit/samba-adc
sudo chmod -R a+rX /usr/share/cockpit/samba-adc
sudo systemctl restart cockpit.socket
```

"Samba AD DC" then appears in the Cockpit menu. If it doesn't show up
immediately, hard-refresh the browser (Ctrl+Shift+R).

### Per-user install (no root needed to install the page itself)

```bash
mkdir -p ~/.local/share/cockpit
cp -r samba-adc ~/.local/share/cockpit/samba-adc
```

(Administrative actions inside the page still need `sudo`/root through
Cockpit's normal privilege escalation.)

## Notes on specific tabs

- **Theme**: synced with Cockpit's own light/dark/auto choice on a
  best-effort basis (Cockpit doesn't guarantee package pages can read the
  shell's setting, depending on version/origin isolation), and can always be
  overridden directly with the **Theme** button in the header, which cycles
  Auto &rarr; Light &rarr; Dark and is remembered for this page specifically.
- **Credentials**: most of this module (user/group/computer/contact/OU
  list, show, create, delete, move...) talks straight to the local AD
  database as root and needs no credentials at all &mdash; that's the
  default, and it's what makes those actions fast and reliable. A smaller
  set of commands are genuinely network/RPC operations against the domain
  &mdash; DRS replication status, FSMO transfer/seize, Group Policy (which
  touches sysvol over SMB), Sites, and DNS management &mdash; and those need
  real authentication. For these, the module first tries this DC's own
  machine account (`-P`) automatically, which avoids depending on an
  interactive Kerberos ticket cache that doesn't exist in Cockpit's
  one-shot escalated shell. If you set real domain administrator
  credentials via the **Credentials** button in the header, those are used
  instead of `-P` for the same set of commands. Either way, `--use-kerberos=off`
  is added alongside so `samba-tool` authenticates with the supplied
  password directly via NTLM instead of first checking for an existing
  Kerberos ticket cache &mdash; that check itself is what throws
  `krb5_cc_get_principal: no such file or directory` when no cache exists,
  even though a valid password was supplied. (The older `-k no` spelling of
  this flag was deprecated in Samba 4.15+ in favor of `--use-kerberos`, so
  that's what this module uses.) Local-only commands are never touched by
  any of this.
- **DC targeting ("-H")**: GPO, Sites, and FSMO transfer/seize additionally
  need to locate a DC via LDAP before anything else can happen, which
  `samba-tool` normally does via DNS-SRV lookup ("Could not find DC for
  domain" is that lookup failing). This module auto-detects this machine's
  own hostname and passes it as `-H` for exactly those commands, bypassing
  the DNS lookup. **`drs showrepl` does not accept `-H` at all** and is
  deliberately excluded from this &mdash; it targets itself by default. You
  can still override the auto-detected hostname via the `-H` field in the
  header if it doesn't resolve properly in your environment; it applies to
  every samba-tool call except `drs`.
- **Service selector** (top right) probes for `samba-ad-dc.service`,
  `samba.service`, and `smbd.service`, since setups differ between the
  all-in-one `samba` process and a split DC + separate `smbd` file server.
- **FSMO**: Transfer moves a role to *this* DC gracefully; Seize forces a
  role onto this DC and should only be used when the current holder is
  permanently gone. Both are confirmed before running.
- **Domain functional level**: raising it is one-directional and affects
  every DC in the domain/forest — the UI warns before applying it.
- **DS ACLs**: `samba-tool dsacl get/set/delete` address AD objects by
  distinguished name and take raw SDDL strings for set/delete — this UI is
  a thin form around that, not an ACL builder. If you hit its known rough
  edges, `ldbsearch`/`ldbmodify` against `nTSecurityDescriptor` remain the
  fallback (see the Samba mailing list for examples).
- **NT ACLs**: `samba-tool ntacl get/set` address a POSIX path on this
  server (inside a share or the sysvol) and also take raw SDDL.
- **GPO**: see *Group Policy* above. It is implemented in `gpo-ui.js` /
  `gpo-core.js` with `gpo_backend.py` as the root helper; VGP (Linux client)
  policies are not covered by the editor.

## Extending it

There is no build step. The original three files hold the core module; the
Group Policy and file-sharing features add a few more:

- `gpo-core.js` (ADMX engine, GptTmpl.inf/scripts/GPP parsers, no UI),
  `gpo-builtin.js` (built-in templates), `gpo-ui.js` (GPMC/GPME UI),
  `gpo_backend.py` (root helper for AD + SYSVOL).
- `sharing-ui.js` and `sharing_diag.py` (diagnostics, automatic server fixes and the sign-in test).
- `user_backend.py` (root helper that edits user attributes; `tests/test_user_backend.py` covers its logic).
- `client-fix.ps1.tpl` (template for the generated Windows client repair script).
- `tests/` has Node unit tests for the pure logic (`npm i jsdom && node tests/core.test.js`).

The core is three files:

- `manifest.json` — Cockpit menu registration.
- `index.html` / `style.css` — layout and look, styled to sit naturally
  next to Cockpit's other pages rather than pull in a UI framework.
- `samba-adc.js` — all logic, organized by panel with small shared helpers
  at the top (`run()`, `openModal()`, `openMoveModal()`, `showAlert()`).
- `vendor/xlsx.core.min.js` — SheetJS, vendored locally (Apache-2.0, see
  `vendor/XLSX-LICENSE.txt`) so spreadsheet import needs no external
  network access and works under Cockpit's content-security policy.

Each panel follows the same shape: a `load*()`/`init*()` function registered
in `PANEL_LOADERS`, a table/form renderer, and modals built with
`openModal()`. Adding another `samba-tool` subcommand (e.g. `domain trust`,
`rodc`, `service-account`) means adding one more panel in that shape.
