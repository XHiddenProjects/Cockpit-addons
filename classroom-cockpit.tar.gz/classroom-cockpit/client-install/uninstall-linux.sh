#!/usr/bin/env bash
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "run as root"; exit 1; }

systemctl disable --now classroom-agent 2>/dev/null || true
rm -f /etc/systemd/system/classroom-agent.service
systemctl daemon-reload
rm -rf /opt/classroom-agent

if [ "${1:-}" = "--purge" ]; then
  rm -rf /etc/classroom
  rm -f /etc/modprobe.d/classroom-webcam.conf /etc/modprobe.d/classroom-usb.conf
  modprobe uvcvideo 2>/dev/null || true
  modprobe usb_storage 2>/dev/null || true
  nft delete table inet classroom_fw 2>/dev/null || true
  echo "Purged: agent, config and any active restriction rules removed."
else
  echo "Agent removed. Config kept at /etc/classroom (re-run with --purge to remove it too)."
fi