#!/usr/bin/env bash
set -euo pipefail
T=$(mktemp -d)
PKGS="python3 python3-pil python3-pil.imagetk python3-tk python3-pyautogui libnotify-bin xdg-utils gnome-screenshot scrot nftables ethtool pulseaudio-utils"

if command -v apt-get >/dev/null; then
  apt-get update
  apt-get install --download-only -y -o Dir::Cache::archives="$T" $PKGS
  OUT="pkgs-linux.tar.gz"; tar czf "$OUT" -C "$T" $(ls "$T" | grep '\.deb$')
elif command -v dnf >/dev/null; then
  dnf install -y dnf-plugins-core
  dnf download --resolve --destdir "$T" $PKGS
  OUT="pkgs-linux.tar.gz"; tar czf "$OUT" -C "$T" $(ls "$T" | grep '\.rpm$')
elif command -v pacman >/dev/null; then
  pacman -Sw --noconfirm --needed --cachedir "$T" $PKGS
  OUT="pkgs-linux.tar.gz"; tar czf "$OUT" -C "$T" $(ls "$T" | grep '\.pkg\.tar')
else
  echo "Unsupported package manager." >&2; exit 1
fi

rm -rf "$T"
echo "Built $OUT - copy it to /usr/share/classroom/offline/ on the admin server."
echo "Note: it must be prepared on the SAME distro/release as your classroom machines."