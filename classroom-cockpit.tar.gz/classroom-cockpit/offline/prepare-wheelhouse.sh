#!/usr/bin/env bash
# Run on an internet-connected Linux or macOS box (matching the client OS/arch).
set -euo pipefail
OS="${1:?usage: prepare-wheelhouse.sh linux|macos}"
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
REQUIREMENTS="$HERE/requirements-wheelhouse.txt"
[[ -f "$REQUIREMENTS" ]] || { echo "Missing dependency manifest: $REQUIREMENTS" >&2; exit 1; }
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
python3 -m pip wheel --wheel-dir "$T" --requirement "$REQUIREMENTS"
cp "$REQUIREMENTS" "$T/requirements-wheelhouse.txt"

# See the matching comment in prepare-wheelhouse.ps1: `pip wheel` builds wheels for
# THIS machine's exact Python minor version/arch, and a client whose Python doesn't
# match will have pip reject them as incompatible despite the file being right there -
# which looks exactly like "pip can't find pillow". Record what this was built for.
BUILT_FOR=$(python3 -c "import sys,platform;print(f'{sys.version_info.major}.{sys.version_info.minor}-{platform.machine()}')")
printf '%s' "$BUILT_FOR" > "$T/python-version.txt"
tar czf "wheelhouse-$OS.tar.gz" -C "$T" .
echo "Built wheelhouse-$OS.tar.gz for Python $BUILT_FOR."
echo "Copy it to /usr/share/classroom/offline/ on the admin server."
echo "IMPORTANT: every client machine's python3 must be this same version/architecture, or pip will reject these wheels as incompatible despite them being in the bundle."