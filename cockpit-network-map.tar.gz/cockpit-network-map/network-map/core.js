/* Network Map core: pure logic (no DOM, no cockpit), shared by the UI and the tests.
 *
 *  - zones:      LANs / VLANs / bridges / routed networks derived from the host's interfaces and routes
 *  - model:      nodes (devices) keyed by zone + IP, annotations (labels, roles, notes)
 *  - topology:   LLDP / SNMP forwarding-table attachment, tree builder + layout
 *  - rendering:  SVG strings (presentation attributes only, so it works under Cockpit's strict CSP)
 */
(function (root, factory) {
    if (typeof module === "object" && module.exports) module.exports = factory();
    else root.NMCore = factory();
}(typeof self !== "undefined" ? self : this, function () {
    "use strict";

    const VERSION = "2.0.0";

    /* ------------------------------------------------------------------ */
    /* constants                                                          */
    /* ------------------------------------------------------------------ */

    const TYPES = {
        internet:   { label: "Internet",          color: "#64748b" },
        router:     { label: "Router / L3",       color: "#f97316" },
        firewall:   { label: "Firewall",          color: "#ef4444" },
        switch:     { label: "Switch",            color: "#3b82f6" },
        ap:         { label: "Access point",      color: "#06b6d4" },
        hypervisor: { label: "Hypervisor",        color: "#8b5cf6" },
        server:     { label: "Server",            color: "#22a06b" },
        siem:       { label: "SIEM / monitoring", color: "#f59e0b" },
        target:     { label: "Target (vulnerable)", color: "#fb923c" },
        attacker:   { label: "Attacker box",      color: "#f43f5e" },
        vm:         { label: "Virtual machine",   color: "#6366f1" },
        computer:   { label: "Workstation",       color: "#14b8a6" },
        printer:    { label: "Printer",           color: "#eab308" },
        iot:        { label: "IoT / camera",      color: "#ec4899" },
        mobile:     { label: "Phone / tablet",    color: "#a855f7" },
        unknown:    { label: "Unknown",           color: "#94a3b8" },
    };
    const RANK = ["router", "firewall", "switch", "ap", "hypervisor", "server", "siem", "target", "attacker", "vm", "computer", "printer", "iot", "mobile", "unknown"];
    const ASSIGNABLE = RANK.slice();

    const PURPOSES = ["Management", "Attack", "Target", "DMZ", "Servers", "Users", "IoT", "Guest", "Monitoring", "Sandbox", "Other"];

    const ZONE_COLORS = ["#2563eb", "#059669", "#d97706", "#dc2626", "#7c3aed", "#0891b2", "#db2777", "#65a30d", "#ea580c", "#0d9488"];

    const THEMES = {
        light: { bg: "#f8fafc", card: "#ffffff", cardStroke: "#cbd5e1", text: "#0f172a", muted: "#64748b", faint: "#94a3b8", link: "#94a3b8", accent: "#2563eb" },
        dark:  { bg: "#0b1220", card: "#131d33", cardStroke: "#2a3856", text: "#e6edf7", muted: "#93a4bf", faint: "#6b7c99", link: "#4b5d7f", accent: "#60a5fa" },
    };

    const ICONS = {
        internet: '<path d="M7 18a4.5 4.5 0 0 1-.5-9A6 6 0 0 1 18 9.5 4 4 0 0 1 17.5 18z"/>',
        router: '<rect x="3" y="13" width="18" height="7" rx="2"/><path d="M7 16.5h.01M11 16.5h.01"/><path d="M12 13V9.5M9 7a4.2 4.2 0 0 1 6 0M6.5 4.5a7.8 7.8 0 0 1 11 0"/>',
        firewall: '<path d="M12 3l8 3v5.5c0 4.5-3.3 8-8 9.5-4.7-1.5-8-5-8-9.5V6z"/><path d="M8.5 10h7M8.5 13.5h7"/>',
        switch: '<rect x="2.5" y="8" width="19" height="8" rx="1.5"/><path d="M6 12h.01M9 12h.01M12 12h.01M15 12h.01M18 12h.01"/><path d="M12 8V5M12 16v3"/>',
        ap: '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.5a9.5 9.5 0 0 1 13 0M8.8 16a5 5 0 0 1 6.4 0"/><path d="M12 19.2h.01"/>',
        hypervisor: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12.5l9 5 9-5M3 16.5l9 5 9-5"/>',
        server: '<rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01M11 7h6M11 17h6"/>',
        siem: '<path d="M3 20V4M3 20h18"/><path d="M7 15l4-4 3 3 5-6"/>',
        target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><path d="M12 12h.01"/>',
        attacker: '<circle cx="12" cy="12" r="7"/><path d="M12 2v5M12 17v5M2 12h5M17 12h5"/>',
        vm: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/><path d="M12 12l8-4.5M12 12L4 7.5M12 12v9"/>',
        computer: '<rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8M12 16v4"/>',
        printer: '<path d="M7 9V3h10v6"/><rect x="3" y="9" width="18" height="8" rx="1.5"/><path d="M7 14h10v7H7z"/>',
        iot: '<path d="M3 8h13a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H3z"/><path d="M17 11l4-2.5v7L17 13"/>',
        mobile: '<rect x="7" y="2.5" width="10" height="19" rx="2"/><path d="M11 18.5h2"/>',
        unknown: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7M12 17h.01"/>',
    };

    const MONO = "ui-monospace,SFMono-Regular,Menlo,Consolas,monospace";
    const SANS = "system-ui,-apple-system,'Segoe UI',Roboto,'Helvetica Neue',Arial,sans-serif";

    /* ------------------------------------------------------------------ */
    /* small helpers                                                      */
    /* ------------------------------------------------------------------ */

    const ip2n = ip => ip.split(".").reduce((a, o) => a * 256 + Number(o), 0);
    const n2ip = n => [24, 16, 8, 0].map(s => Math.floor(n / 2 ** s) % 256).join(".");
    const cidrBase = (ip, prefix) => { const size = 2 ** (32 - prefix); return Math.floor(ip2n(ip) / size) * size; };
    const cidrNet = (ip, prefix) => n2ip(cidrBase(ip, prefix)) + "/" + prefix;
    function inCidr(ip, cidr) {
        if (!/^\d+\.\d+\.\d+\.\d+$/.test(ip || "")) return false;
        const [net, p] = cidr.split("/");
        return cidrBase(ip, Number(p)) === cidrBase(net, Number(p));
    }
    function cidrHosts(cidr) {
        const [ip, p] = cidr.split("/");
        const size = 2 ** (32 - Number(p));
        const base = cidrBase(ip, Number(p));
        const out = [];
        for (let i = 1; i < size - 1; i++) out.push(n2ip(base + i));
        return out;
    }
    const normMac = m => (m || "").toLowerCase().replace(/[^0-9a-f]/g, "").replace(/(..)(?=.)/g, "$1:");
    const esc = s => String(s === undefined || s === null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
    const trunc = (s, n) => (s.length > n ? s.slice(0, n - 1) + "…" : s);
    const hash = s => { let h = 0; for (const ch of String(s)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; };
    const isIpv4 = s => /^\d+\.\d+\.\d+\.\d+$/.test(s || "");

    const zoneColor = z => ZONE_COLORS[(z && z.vlan != null ? z.vlan : hash(z ? z.cidr : "")) % ZONE_COLORS.length];
    const zoneKey = z => z.cidr + "|" + (z.vlan == null ? "" : z.vlan);
    const nodeKey = n => (n.mac ? n.mac : n.zone + "|" + n.ip);
    const effType = n => (n.role && TYPES[n.role] ? n.role : n.type || "unknown");
    const typeInfo = n => TYPES[effType(n)] || TYPES.unknown;
    function displayName(n) {
        return n.label || (n.hostname ? n.hostname.split(".")[0] : "") || n.ip || (n.mac ? n.mac : "unknown");
    }
    function zoneBadge(z) {
        let text;
        if (z.kind === "vlan") text = "VLAN " + z.vlan;
        else if (z.kind === "bridge") text = "BRIDGE";
        else if (z.kind === "virtual") text = "VIRTUAL";
        else if (z.kind === "routed") text = "ROUTED";
        else text = z.vlan != null ? "VLAN " + z.vlan : "LAN";
        return { text, w: Math.round(text.length * 6.3 + 18) };
    }
    const zoneTitle = z => z.name || (z.kind === "routed" ? "Routed network" : z.iface);

    /* ------------------------------------------------------------------ */
    /* zones (LANs / VLANs)                                               */
    /* ------------------------------------------------------------------ */

    const VIRTUAL_IF = /^(docker|br-|virbr|veth|cni|flannel|cali|lxc|lxd|vmnet|tun|tap|wg|tailscale|zt|podman|kube|vboxnet)/;

    /* ifaces:  output of `ip -j -d addr show`
     * routes:  output of `ip -j -4 route show`
     * bridgeVlans: output of `bridge -j vlan show` (optional) */
    function buildZones(ifaces, routes, bridgeVlans) {
        const zones = [];
        const hostVlans = [];
        const seenIf = new Set();

        for (const i of ifaces || []) {
            if (!i || i.ifname === "lo") continue;
            const li = i.linkinfo || {};
            const kind = li.info_kind || "";
            let vlan = null;
            if (kind === "vlan" && li.info_data && li.info_data.id != null) vlan = Number(li.info_data.id);
            else if (!kind && i.link && /^.+\.(\d{1,4})$/.test(i.ifname)) vlan = Number(i.ifname.match(/\.(\d{1,4})$/)[1]);
            const addrs = (i.addr_info || []).filter(a => a.family === "inet" && a.scope === "global" && a.local);

            if (vlan != null && !addrs.length) {
                hostVlans.push({ iface: i.ifname, vlan, parent: i.link || "", ip: "", source: "sub-interface (no IPv4)" });
            }
            for (const a of addrs) {
                const cidr = cidrNet(a.local, a.prefixlen);
                let zkind = "physical";
                if (vlan != null) zkind = "vlan";
                else if (VIRTUAL_IF.test(i.ifname)) zkind = "virtual";
                else if (kind === "bridge") zkind = "bridge";
                zones.push({
                    id: i.ifname + ":" + cidr, cidr, prefix: a.prefixlen, iface: i.ifname, parent: i.link || "",
                    vlan, kind: zkind, localIp: a.local, localMac: normMac(i.address), gateway: "",
                    name: "", purpose: "", source: "local", state: i.operstate || "",
                    scan: zkind !== "virtual" && a.prefixlen >= 20, scanned: false,
                });
                if (vlan != null) hostVlans.push({ iface: i.ifname, vlan, parent: i.link || "", ip: a.local + "/" + a.prefixlen, source: "sub-interface" });
                seenIf.add(i.ifname);
            }
        }

        // routes: default gateway, per-zone gateways, statically routed networks
        let defaultGateway = "", defaultDev = "", bestMetric = Infinity;
        const localCidrs = new Set(zones.map(z => z.cidr));
        for (const r of routes || []) {
            if (r.dst === "default" && r.gateway) {
                const m = r.metric == null ? 0 : Number(r.metric);
                if (m < bestMetric) { bestMetric = m; defaultGateway = r.gateway; defaultDev = r.dev || ""; }
            }
        }
        for (const z of zones) {
            if (z.source !== "local") continue;
            for (const r of routes || []) {
                if (r.gateway && r.dev === z.iface && inCidr(r.gateway, z.cidr)) {
                    if (r.dst === "default" || !z.gateway) z.gateway = r.gateway;
                }
            }
        }
        for (const r of routes || []) {
            if (!r.gateway || !r.dst || r.dst === "default" || !r.dst.includes("/")) continue;
            const [net, p] = r.dst.split("/");
            const prefix = Number(p);
            if (!isIpv4(net) || prefix >= 32 || net.startsWith("169.254.") || localCidrs.has(r.dst)) continue;
            if (zones.some(z => z.source === "route" && z.cidr === r.dst)) continue;
            zones.push({
                id: "route:" + r.dst, cidr: r.dst, prefix, iface: r.dev || "", parent: "", vlan: null, kind: "routed",
                localIp: "", localMac: "", gateway: r.gateway, name: "", purpose: "", source: "route",
                state: "", scan: false, scanned: false,
            });
        }

        // VLAN-aware bridge configuration
        for (const b of bridgeVlans || []) {
            for (const v of b.vlans || []) {
                const flags = v.flags || [];
                hostVlans.push({
                    iface: b.ifname, vlan: Number(v.vlan), parent: "", ip: "",
                    source: "bridge port" + (flags.includes("PVID") ? " · PVID" : "") + (flags.includes("Egress Untagged") ? " · untagged" : " · tagged"),
                });
            }
        }
        return { zones, defaultGateway, defaultDev, hostVlans };
    }

    /* ------------------------------------------------------------------ */
    /* model                                                              */
    /* ------------------------------------------------------------------ */

    function createModel(info) {
        return {
            zones: new Map((info.zones || []).map(z => [z.id, Object.assign({}, z)])),
            nodes: new Map(),
            edges: [],
            upstream: [],
            vlanNames: {},
            defaultGateway: info.defaultGateway || "",
            defaultDev: info.defaultDev || "",
            hostVlans: info.hostVlans || [],
            scannedAt: null,
        };
    }
    const nodeId = (zoneId, ip) => zoneId + "|" + ip;
    const zoneNodes = (model, zoneId) => [...model.nodes.values()].filter(n => n.zone === zoneId);
    const findNodeByIp = (model, ip, zoneId) => {
        if (!ip) return null;
        if (zoneId && model.nodes.has(nodeId(zoneId, ip))) return model.nodes.get(nodeId(zoneId, ip));
        for (const n of model.nodes.values()) if (n.ip === ip) return n;
        return null;
    };
    const findNodeByMac = (model, mac, zoneId) => {
        mac = normMac(mac);
        if (!mac) return null;
        let any = null;
        for (const n of model.nodes.values()) if (n.mac === mac) { if (!zoneId || n.zone === zoneId) return n; any = any || n; }
        return any;
    };

    function upsertNode(model, zoneId, ip, props) {
        const id = nodeId(zoneId, ip);
        let n = model.nodes.get(id);
        if (!n) {
            n = { id, zone: zoneId, ip, mac: "", vendor: "", hostname: "", os: "", ports: [], type: "unknown", role: "", label: "", notes: "", local: false, sources: [], uplinkId: "", uplinkPort: "" };
            model.nodes.set(id, n);
        }
        for (const k in props || {}) {
            const v = props[k];
            if (v === undefined || v === null || v === "" || (Array.isArray(v) && !v.length && k !== "ports")) continue;
            if (k === "sources") { for (const s of v) if (!n.sources.includes(s)) n.sources.push(s); continue; }
            n[k] = v;
        }
        return n;
    }

    function orderedZones(model) {
        const all = [...model.zones.values()];
        const rank = z => (z.iface === model.defaultDev && z.kind !== "routed" ? 0 : z.kind === "vlan" ? 1 : z.kind === "physical" ? 2 : z.kind === "bridge" ? 3 : z.kind === "virtual" ? 4 : 5);
        return all.sort((a, b) => (rank(a) - rank(b)) || ((a.vlan || 0) - (b.vlan || 0)) || (ip2n(a.cidr.split("/")[0]) - ip2n(b.cidr.split("/")[0])));
    }
    const visibleZones = model => orderedZones(model).filter(z => z.scanned || zoneNodes(model, z.id).length);

    /* ------------------------------------------------------------------ */
    /* classification                                                     */
    /* ------------------------------------------------------------------ */

    function classifyNode(n, ctx) {
        if (n.forcedType) { n.type = n.forcedType; return n.type; }
        const ports = new Set((n.ports || []).map(p => p.port));
        const has = (...ps) => ps.some(p => ports.has(p));
        const v = n.vendor || "", name = (n.hostname || "").toLowerCase(), os = (n.os || "").toLowerCase();
        const z = ctx.zones.get(n.zone);
        const isGw = !!n.ip && ((z && z.gateway === n.ip) || ctx.defaultGateway === n.ip);
        const blob = v + " " + os + " " + name;
        let t = "unknown";

        if (/kali|parrot|pentest|blackarch|attacker/i.test(name)) t = "attacker";
        else if (/metasploitable|dvwa|vulnhub|juice|webgoat|bwapp|victim|vulnerable|target/i.test(name)) t = "target";
        else if (/pfsense|opnsense|fortigate|fortinet|palo alto|netgate|sophos|watchguard|sonicwall|check ?point|vyos/i.test(blob)) t = "firewall";
        else if (isGw) t = "router";
        else if (/unifi|access.?point|(^|[-_.])ap\d*([-_.]|$)/i.test(name) || /ruckus|engenius|cambium/i.test(v)) t = "ap";
        else if (/cisco|juniper|arista|extreme|brocade|netgear|zyxel|hewlett packard enterprise|aruba|d-?link|tp-?link|ubiquiti|mikrotik|routerboard|allied|huawei/i.test(v)
                 || /\bios\b|junos|routeros|openwrt|edgeos|switch/i.test(os + " " + name)
                 || (has(161) && !has(445, 3389, 22))) t = /router|mikrotik|routerboard|edgeos|junos/i.test(blob) ? "router" : "switch";
        else if (has(8006, 902, 16509, 2179) || /proxmox|esxi|hyper-v host|xenserver|libvirt/i.test(blob)) t = "hypervisor";
        else if (has(5601, 9200, 55000, 1514, 8089) || /wazuh|splunk|elastic|graylog|security.?onion|siem|zabbix|grafana/i.test(name)) t = "siem";
        else if (has(9100, 631, 515) || (/hewlett|hp inc|brother|canon|epson|xerox|lexmark|ricoh|kyocera/i.test(v) && !has(445))) t = "printer";
        else if (has(554, 37777, 1883, 8883) || /hikvision|dahua|axis|espressif|tuya|shelly|sonos|nest|\bring\b|roku|amazon|philips|signify/i.test(v)) t = "iot";
        else if (/windows/.test(os) || has(3389, 445, 135)) t = /server/.test(os) || has(1433, 3306, 80, 443, 53, 389, 88) ? "server" : "computer";
        else if (/apple|samsung|xiaomi|oneplus|oppo|motorola|google|huawei device/i.test(v) || /iphone|ipad|android|galaxy|pixel/.test(name)) t = "mobile";
        else if (has(22, 80, 443, 3306, 5432, 25, 53, 8080, 8443) || /linux|ubuntu|debian|centos|freebsd|rhel/.test(os)) t = "server";
        else if (/raspberry|intel|dell|lenovo|asustek|gigabyte|micro-star|realtek/i.test(v)) t = "computer";
        // a VM-vendor MAC only decides the type when nothing more specific was recognised
        if ((t === "unknown" || t === "computer") && /vmware|qemu|xensource|microsoft corp|parallels|red hat|virtualbox|pcs systemtechnik/i.test(v)) t = "vm";
        n.type = t;
        return t;
    }
    function classifyAll(model) {
        const ctx = { zones: model.zones, defaultGateway: model.defaultGateway };
        for (const n of model.nodes.values()) classifyNode(n, ctx);
    }

    /* ------------------------------------------------------------------ */
    /* parsers for tool output                                            */
    /* ------------------------------------------------------------------ */

    function parseLldp(j) {
        const out = [];
        const ifs = (j && j.lldp && j.lldp.interface) || [];
        const entries = Array.isArray(ifs) ? ifs.flatMap(o => Object.entries(o)) : Object.entries(ifs);
        for (const [ifname, info] of entries) {
            let ch = info.chassis || {};
            let name = "";
            if (!ch.id) { name = Object.keys(ch)[0] || ""; ch = ch[name] || {}; }
            let mgmt = ch["mgmt-ip"];
            if (Array.isArray(mgmt)) mgmt = mgmt.find(isIpv4);
            if (!isIpv4(mgmt)) mgmt = "";
            const caps = [].concat(ch.capability || []).filter(c => c && c.enabled !== false).map(c => String(c.type || "").toLowerCase());
            let vlan = null;
            const vl = info.vlan;
            const v0 = Array.isArray(vl) ? vl[0] : vl;
            if (v0 && v0["vlan-id"] != null) vlan = Number(v0["vlan-id"]);
            out.push({
                ifname, name: name || ch.name || "", ip: mgmt, mac: ch.id && ch.id.value ? normMac(ch.id.value) : "",
                descr: ch.descr || "", caps, vlan,
                port: (info.port && (info.port.descr || (info.port.id && info.port.id.value))) || "",
            });
        }
        return out;
    }

    function parseTraceroute(text) {
        const hops = [];
        for (const line of String(text || "").split("\n")) {
            const m = line.match(/^\s*\d+\s+(\d+\.\d+\.\d+\.\d+)/);
            if (m) hops.push(m[1]);
        }
        return hops;
    }

    /* snmpwalk -On output of dot1dTpFdbPort and/or dot1qTpFdbPort */
    function parseFdb(text) {
        const ports = new Map(), vlans = new Map();
        const hex = s => s.split(".").map(o => Number(o).toString(16).padStart(2, "0")).join(":");
        for (const line of String(text || "").split("\n")) {
            let m = line.match(/\.17\.7\.1\.2\.2\.1\.2\.(\d+)\.((?:\d+\.){5}\d+)\s*=\s*INTEGER:\s*(\d+)/);
            if (m) {
                if (m[3] === "0") continue;
                const mac = hex(m[2]);
                if (!ports.has(mac)) { ports.set(mac, m[3]); vlans.set(mac, Number(m[1])); }
                continue;
            }
            m = line.match(/\.17\.4\.3\.1\.2\.((?:\d+\.){5}\d+)\s*=\s*INTEGER:\s*(\d+)/);
            if (m && m[2] !== "0") { const mac = hex(m[1]); if (!ports.has(mac)) ports.set(mac, m[2]); }
        }
        return { ports, vlans };
    }
    function parseVlanNames(text) {
        const names = new Map();
        for (const line of String(text || "").split("\n")) {
            const m = line.match(/\.17\.7\.1\.4\.3\.1\.1\.(\d+)\s*=\s*STRING:\s*"?([^"\n]*)"?/);
            if (m && m[2].trim()) names.set(Number(m[1]), m[2].trim());
        }
        return names;
    }

    /* ------------------------------------------------------------------ */
    /* topology (uplinks)                                                 */
    /* ------------------------------------------------------------------ */

    /* ext: { lldp: [...parseLldp], hops: [ips], fdbs: Map(nodeId -> {ports, vlans}), vlanNames: Map } */
    function buildTopology(model, ext) {
        ext = ext || {};
        for (const n of model.nodes.values()) { n.uplinkId = ""; n.uplinkPort = ""; }
        model.edges = [];

        // LLDP neighbours are physically cabled to this host
        for (const nb of ext.lldp || []) {
            const zs = [...model.zones.values()].filter(z => z.source === "local" && (z.iface === nb.ifname || z.parent === nb.ifname));
            if (!zs.length) continue;
            const z0 = zs[0];
            let nbNode = findNodeByMac(model, nb.mac) || (nb.ip && findNodeByIp(model, nb.ip));
            if (!nbNode) {
                const zHome = (nb.ip && zs.find(z => inCidr(nb.ip, z.cidr))) || z0;
                nbNode = upsertNode(model, zHome.id, nb.ip || ("lldp-" + (nb.mac || nb.name)), { ip: nb.ip, mac: nb.mac, hostname: nb.name });
            }
            nbNode.sources.push("lldp");
            if (nb.descr) nbNode.descr = nb.descr;
            if (nb.caps.includes("router") && !nb.caps.includes("bridge")) nbNode.forcedType = "router";
            else if (nb.caps.includes("wlan") && !nb.caps.includes("bridge")) nbNode.forcedType = "ap";
            else if (nb.caps.includes("bridge")) nbNode.forcedType = "switch";
            for (const z of zs) {
                const local = [...model.nodes.values()].find(n => n.local && n.zone === z.id);
                if (!local || local === nbNode) continue;
                if (nbNode.zone === local.zone) { local.uplinkId = nbNode.id; local.uplinkPort = nb.port || nb.ifname; }
                else model.edges.push({ a: local.id, b: nbNode.id, label: nb.port || nb.ifname, kind: "lldp" });
            }
        }

        // a device sharing the default gateway's MAC in another zone is the same router (inter-VLAN routing)
        const gwNode = findNodeByIp(model, model.defaultGateway);
        if (gwNode && gwNode.mac) {
            for (const n of model.nodes.values()) {
                if (n !== gwNode && n.mac === gwNode.mac && n.ip) {
                    if (!n.forcedType) n.forcedType = "router";
                    const z = model.zones.get(n.zone);
                    if (z && !z.gateway) z.gateway = n.ip;
                }
            }
        }
        classifyAll(model);

        // SNMP forwarding tables
        const fdbs = ext.fdbs || new Map();
        const sources = [...fdbs.keys()].filter(id => model.nodes.has(id));
        if (sources.length) {
            const count = new Map();
            for (const id of sources) for (const port of fdbs.get(id).ports.values()) count.set(id + "|" + port, (count.get(id + "|" + port) || 0) + 1);
            const best = (n, allowed) => {
                if (!n.mac) return null;
                let pick = null;
                for (const id of allowed) {
                    if (id === n.id) continue;
                    const port = fdbs.get(id).ports.get(n.mac);
                    if (!port) continue;
                    const c = count.get(id + "|" + port);
                    if (!pick || c < pick.c) pick = { id, port, c };
                }
                return pick;
            };
            const isRoot = n => {
                const z = model.zones.get(n.zone);
                return n.ip === model.defaultGateway || (z && z.gateway === n.ip) || effType(n) === "router" || effType(n) === "firewall";
            };
            const placed = new Set(sources.filter(id => isRoot(model.nodes.get(id))));
            if (!placed.size) sources.forEach(id => placed.add(id));
            let todo = [...model.nodes.values()].filter(n => !n.local && (effType(n) === "switch" || effType(n) === "ap") && !placed.has(n.id));
            for (let guard = 0; guard < 12 && todo.length; guard++) {
                const next = [], newly = [];
                for (const n of todo) {
                    const p = best(n, sources.filter(s => placed.has(s)));
                    if (p) { n.uplinkId = p.id; n.uplinkPort = "port " + p.port; newly.push(n.id); } else next.push(n);
                }
                newly.forEach(id => placed.add(id));
                if (!newly.length) break;
                todo = next;
            }
            for (const n of model.nodes.values()) {
                if (n.local && n.uplinkId) continue;
                if (n.uplinkId || isRoot(n) && sources.includes(n.id)) continue;
                const p = best(n, sources);
                if (p) {
                    n.uplinkId = p.id; n.uplinkPort = "port " + p.port;
                    const vl = fdbs.get(p.id).vlans.get(n.mac);
                    if (vl != null) n.vlanSeen = vl;
                }
            }
        }
        if (ext.vlanNames) for (const [id, nm] of ext.vlanNames) model.vlanNames[id] = nm;
        for (const z of model.zones.values()) if (z.vlan != null && model.vlanNames[z.vlan] && !z.switchName) z.switchName = model.vlanNames[z.vlan];

        // break cycles
        for (const n of model.nodes.values()) {
            const seen = new Set([n.id]);
            let c = n.uplinkId ? model.nodes.get(n.uplinkId) : null;
            while (c) {
                if (seen.has(c.id)) { n.uplinkId = ""; n.uplinkPort = ""; break; }
                seen.add(c.id);
                c = c.uplinkId ? model.nodes.get(c.uplinkId) : null;
            }
        }
        model.upstream = (ext.hops || []).filter(h => !findNodeByIp(model, h)).slice(0, 4);
    }

    /* ------------------------------------------------------------------ */
    /* annotations                                                        */
    /* ------------------------------------------------------------------ */

    function applyAnnotations(model, ann) {
        ann = ann || { nodes: {}, zones: {} };
        for (const z of model.zones.values()) {
            const a = (ann.zones || {})[zoneKey(z)];
            z.name = (a && a.name) || "";
            z.purpose = (a && a.purpose) || "";
        }
        for (const n of model.nodes.values()) {
            const a = (ann.nodes || {})[nodeKey(n)];
            n.label = (a && a.label) || "";
            n.role = (a && a.role) || "";
            n.notes = (a && a.notes) || "";
        }
    }

    /* ------------------------------------------------------------------ */
    /* serialisation + reports                                            */
    /* ------------------------------------------------------------------ */

    function serialize(model) {
        return JSON.stringify({
            v: 2, zones: [...model.zones.values()], nodes: [...model.nodes.values()], edges: model.edges, upstream: model.upstream,
            vlanNames: model.vlanNames, defaultGateway: model.defaultGateway, defaultDev: model.defaultDev, hostVlans: model.hostVlans, scannedAt: model.scannedAt,
        });
    }
    function deserialize(text) {
        const j = typeof text === "string" ? JSON.parse(text) : text;
        if (!j || j.v !== 2) return null;
        const m = createModel({ zones: [], defaultGateway: j.defaultGateway, defaultDev: j.defaultDev, hostVlans: j.hostVlans });
        for (const z of j.zones) m.zones.set(z.id, z);
        for (const n of j.nodes) m.nodes.set(n.id, n);
        m.edges = j.edges || []; m.upstream = j.upstream || []; m.vlanNames = j.vlanNames || {}; m.scannedAt = j.scannedAt || null;
        return m;
    }

    function inventoryRows(model) {
        const rows = [];
        for (const z of visibleZones(model)) {
            for (const n of sortNodes(zoneNodes(model, z.id))) {
                rows.push({
                    zone: zoneTitle(z), vlan: z.vlan == null ? "" : z.vlan, cidr: z.cidr, purpose: z.purpose, ip: n.ip, name: displayName(n),
                    hostname: n.hostname, mac: n.mac, vendor: n.vendor, type: TYPES[effType(n)].label, role: n.role ? TYPES[n.role].label : "",
                    uplink: n.uplinkId && model.nodes.get(n.uplinkId) ? displayName(model.nodes.get(n.uplinkId)) + (n.uplinkPort ? " (" + n.uplinkPort + ")" : "") : "",
                    ports: (n.ports || []).map(p => p.port + (p.service ? "/" + p.service : "")).join(" "), os: n.os || "", notes: n.notes || "", id: n.id,
                });
            }
        }
        return rows;
    }
    function toCsv(model) {
        const cols = ["zone", "vlan", "cidr", "purpose", "ip", "name", "hostname", "mac", "vendor", "type", "role", "uplink", "ports", "os", "notes"];
        const q = v => '"' + String(v === undefined ? "" : v).replace(/"/g, '""') + '"';
        return [cols.join(",")].concat(inventoryRows(model).map(r => cols.map(c => q(r[c])).join(","))).join("\n") + "\n";
    }
    function toMarkdown(model) {
        const out = ["# Lab network map", "", "_Generated " + (model.scannedAt || new Date().toISOString()) + " by Network Map " + VERSION + "_", ""];
        const zs = visibleZones(model);
        out.push("## Zones", "", "| Zone | VLAN | Subnet | Purpose | Gateway | Hosts |", "|---|---|---|---|---|---|");
        for (const z of zs) out.push(`| ${zoneTitle(z)} | ${z.vlan == null ? "–" : z.vlan} | ${z.cidr} | ${z.purpose || "–"} | ${z.gateway || "–"} | ${zoneNodes(model, z.id).length} |`);
        for (const z of zs) {
            out.push("", `## ${zoneTitle(z)} (${z.vlan != null ? "VLAN " + z.vlan + ", " : ""}${z.cidr})`, "");
            const ns = sortNodes(zoneNodes(model, z.id));
            if (!ns.length) { out.push("_No hosts discovered._"); continue; }
            out.push("| IP | Name | Type | MAC | Vendor | Notes |", "|---|---|---|---|---|---|");
            for (const n of ns) out.push(`| ${n.ip} | ${displayName(n)}${n.local ? " (this host)" : ""} | ${TYPES[effType(n)].label} | ${n.mac || ""} | ${n.vendor || ""} | ${(n.notes || "").replace(/\|/g, "/").replace(/\n/g, " ")} |`);
        }
        return out.join("\n") + "\n";
    }
    function summary(model) {
        const counts = {};
        let hosts = 0;
        for (const n of model.nodes.values()) { hosts++; counts[effType(n)] = (counts[effType(n)] || 0) + 1; }
        return { zones: visibleZones(model).length, hosts, counts };
    }

    function sortNodes(ns) {
        return ns.slice().sort((a, b) => (RANK.indexOf(effType(a)) - RANK.indexOf(effType(b))) || ((a.ip ? ip2n(a.ip) : 0) - (b.ip ? ip2n(b.ip) : 0)));
    }
    function matcher(q) {
        q = (q || "").trim().toLowerCase();
        if (!q) return null;
        return n => [n.ip, n.mac, n.hostname, n.label, n.vendor, n.notes, TYPES[effType(n)].label, n.os].join(" ").toLowerCase().includes(q);
    }

    /* ------------------------------------------------------------------ */
    /* SVG rendering                                                      */
    /* ------------------------------------------------------------------ */

    const CARD_W = 150, CARD_H = 54, CELL_W = 164, CELL_H = 72, HEAD_H = 62;

    function T(x, y, s, o) {
        return `<text x="${x}" y="${y}" font-family="${o.mono ? MONO : SANS}" font-size="${o.size || 11}" font-weight="${o.weight || 400}" fill="${o.fill}" text-anchor="${o.anchor || "start"}">${esc(s)}</text>`;
    }
    const DEFS = '<defs><marker id="nm-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="#94a3b8"/></marker></defs>';

    function iconSvg(type, color, cx, cy, size) {
        const s = size / 24;
        return `<g transform="translate(${cx - size / 2},${cy - size / 2}) scale(${s})" fill="none" stroke="${color}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${ICONS[type] || ICONS.unknown}</g>`;
    }

    function card(n, x, y, o) {
        const t = o.theme, type = effType(n), ty = TYPES[type] || TYPES.unknown;
        const dim = o.match && !o.match(n);
        const sel = o.selected === n.id;
        const z = o.model && o.model.zones.get(n.zone);
        let s = `<g data-node="${esc(n.id)}" transform="translate(${x},${y})" opacity="${dim ? 0.25 : 1}">`;
        s += `<title>${esc([displayName(n), n.ip, n.mac, n.vendor, n.os, (n.ports || []).map(p => p.port).join(", ")].filter(Boolean).join("\n"))}</title>`;
        s += `<rect class="nm-card" x="${-CARD_W / 2}" y="${-CARD_H / 2}" width="${CARD_W}" height="${CARD_H}" rx="9" fill="${t.card}" stroke="${sel ? t.accent : t.cardStroke}" stroke-width="${sel ? 2.4 : 1}"/>`;
        s += `<circle cx="-52" cy="0" r="17" fill="${ty.color}" fill-opacity="0.14"/>` + iconSvg(type, ty.color, -52, 0, 22);
        s += T(-30, -4, trunc(displayName(n), 15), { size: 11.5, weight: 600, fill: t.text });
        s += T(-30, 9, n.ip || "no IP", { size: 10, mono: true, fill: t.muted });
        s += T(-30, 21, trunc(ty.label + (n.vendor ? " · " + n.vendor : ""), 20), { size: 9, fill: t.faint });
        if (o.zoneDot && z) s += `<circle cx="64" cy="-17" r="4" fill="${zoneColor(z)}"/>`;
        if (n.local) s += `<rect x="-75" y="-37" width="46" height="14" rx="7" fill="${t.accent}"/>` + T(-52, -27, "THIS HOST", { size: 7.5, weight: 700, fill: "#ffffff", anchor: "middle" });
        return s + "</g>";
    }
    function plainCard(label, sub, type, x, y, o) {
        const t = o.theme, ty = TYPES[type];
        return `<g transform="translate(${x},${y})">` +
            `<rect x="${-CARD_W / 2}" y="${-CARD_H / 2}" width="${CARD_W}" height="${CARD_H}" rx="9" fill="${t.card}" stroke="${t.cardStroke}" stroke-width="1"/>` +
            `<circle cx="-52" cy="0" r="17" fill="${ty.color}" fill-opacity="0.14"/>` + iconSvg(type, ty.color, -52, 0, 22) +
            T(-30, sub ? -2 : 4, label, { size: 11.5, weight: 600, fill: t.text }) + (sub ? T(-30, 12, sub, { size: 10, mono: true, fill: t.muted }) : "") + "</g>";
    }

    function curve(x1, y1, x2, y2) {
        const my = (y1 + y2) / 2;
        return `M${x1},${y1} C${x1},${my} ${x2},${my} ${x2},${y2}`;
    }

    function zoneBoxSvg(b, o, model) {
        const t = o.theme, z = b.z, c = zoneColor(z), bd = zoneBadge(z);
        const sel = o.selected === "zone:" + z.id;
        let s = `<g data-zone="${esc(z.id)}">`;
        s += `<rect x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" rx="14" fill="${c}" fill-opacity="0.06" stroke="${c}" stroke-opacity="${sel ? 1 : 0.55}" stroke-width="${sel ? 2.4 : 1.2}"${z.kind === "routed" ? ' stroke-dasharray="6 4"' : ""}/>`;
        s += `<rect x="${b.x + 14}" y="${b.y + 14}" width="${bd.w}" height="20" rx="10" fill="${c}"/>` + T(b.x + 14 + bd.w / 2, b.y + 28, bd.text, { size: 10, weight: 700, fill: "#ffffff", anchor: "middle" });
        s += T(b.x + 14 + bd.w + 10, b.y + 29, trunc(zoneTitle(z), 28), { size: 13.5, weight: 650, fill: t.text });
        const meta = [z.cidr, z.iface && z.kind !== "routed" ? z.iface : "", z.gateway ? "gw " + z.gateway : "", (b.ns.length) + (b.ns.length === 1 ? " host" : " hosts")].filter(Boolean).join("  ·  ");
        s += T(b.x + 16, b.y + 52, trunc(meta, 70), { size: 10.5, mono: true, fill: t.muted });
        if (z.purpose) {
            const pw = Math.round(z.purpose.length * 6.2 + 18);
            s += `<rect x="${b.x + b.w - pw - 14}" y="${b.y + 14}" width="${pw}" height="20" rx="10" fill="none" stroke="${c}" stroke-opacity="0.8"/>` + T(b.x + b.w - pw / 2 - 14, b.y + 28, z.purpose, { size: 10, weight: 600, fill: c, anchor: "middle" });
        }
        if (!b.ns.length) s += T(b.x + b.w / 2, b.y + HEAD_H + 22, "No hosts discovered", { size: 11, fill: t.faint, anchor: "middle" });
        return s + "</g>";
    }

    function renderZones(model, o) {
        const t = o.theme, match = matcher(o.query);
        o = Object.assign({}, o, { match, model, zoneDot: false });
        const zs = visibleZones(model);
        const PAD = 32, GAP = 28, TOP = 118, TARGET = o.targetWidth || 1700;
        const boxes = [];
        let x = PAD, y = TOP, rowH = 0, maxW = 0;
        for (const z of zs) {
            const ns = sortNodes(zoneNodes(model, z.id));
            const cols = ns.length <= 2 ? 2 : ns.length <= 3 ? 3 : ns.length <= 12 ? 4 : ns.length <= 24 ? 5 : 6;
            const rows = Math.max(1, Math.ceil(ns.length / cols));
            const w = Math.max(420, cols * CELL_W + 24);
            const h = HEAD_H + (ns.length ? rows * CELL_H : 52) + 14;
            if (x > PAD && x + w > TARGET) { x = PAD; y += rowH + GAP; rowH = 0; }
            boxes.push({ z, ns, x, y, w, h, cols });
            x += w + GAP; rowH = Math.max(rowH, h); maxW = Math.max(maxW, x - GAP);
        }
        const pos = new Map();
        for (const b of boxes) {
            const gridW = b.cols * CELL_W;
            const ox = b.x + (b.w - gridW) / 2;
            b.ns.forEach((n, i) => {
                pos.set(n.id, { x: ox + (i % b.cols + 0.5) * CELL_W, y: b.y + HEAD_H + (Math.floor(i / b.cols) + 0.5) * CELL_H });
            });
        }
        const W = Math.max(maxW + PAD, 760), H = y + rowH + PAD;

        let s = DEFS;
        for (const b of boxes) s += zoneBoxSvg(b, o, model);

        // links
        let links = "";
        for (const n of model.nodes.values()) {
            const a = pos.get(n.id), up = n.uplinkId && pos.get(n.uplinkId);
            if (a && up && model.nodes.get(n.uplinkId).zone === n.zone) {
                links += `<path d="${curve(up.x, up.y + CARD_H / 2, a.x, a.y - CARD_H / 2)}" fill="none" stroke="${t.link}" stroke-width="1.4"/>`;
                if (n.uplinkPort) links += T((a.x + up.x) / 2 + 4, (a.y + up.y) / 2, n.uplinkPort, { size: 8.5, fill: t.faint, anchor: "middle" });
            }
        }
        const groups = new Map();
        for (const n of model.nodes.values()) {
            const key = n.local ? "LOCAL" : n.mac;
            if (!key || !pos.has(n.id)) continue;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(n);
        }
        for (const [key, g] of groups) {
            if (g.length < 2) continue;
            for (let i = 0; i + 1 < g.length; i++) {
                const a = pos.get(g[i].id), b = pos.get(g[i + 1].id);
                const mx = (a.x + b.x) / 2, my = Math.min(a.y, b.y) - 70;
                links += `<path d="M${a.x},${a.y - CARD_H / 2} Q${mx},${my} ${b.x},${b.y - CARD_H / 2}" fill="none" stroke="${t.accent}" stroke-opacity="0.4" stroke-width="1.3" stroke-dasharray="5 4"/>`;
                links += T(mx, (a.y + b.y) / 2 - 38, key === "LOCAL" ? "this host" : "same device", { size: 8.5, fill: t.accent, anchor: "middle" });
            }
        }
        for (const e of model.edges) {
            const a = pos.get(e.a), b = pos.get(e.b);
            if (a && b) {
                const mx = (a.x + b.x) / 2, my = Math.min(a.y, b.y) - 50;
                links += `<path d="M${a.x},${a.y - CARD_H / 2} Q${mx},${my} ${b.x},${b.y - CARD_H / 2}" fill="none" stroke="${t.link}" stroke-width="1.6"/>`;
                if (e.label) links += T(mx, (a.y + b.y) / 2 - 28, e.label, { size: 8.5, fill: t.faint, anchor: "middle" });
            }
        }
        for (const b of boxes) {
            if (b.z.kind !== "routed") continue;
            const g = findNodeByIp(model, b.z.gateway), gp = g && pos.get(g.id);
            if (gp) {
                links += `<path d="${curve(b.x + b.w / 2, b.y, gp.x, gp.y + CARD_H / 2)}" fill="none" stroke="#94a3b8" stroke-width="1.4" stroke-dasharray="6 4" marker-end="url(#nm-arrow)"/>`;
                links += T((b.x + b.w / 2 + gp.x) / 2 + 6, (b.y + gp.y) / 2, "via " + b.z.gateway, { size: 9, fill: t.faint });
            }
        }
        // internet
        const gw = findNodeByIp(model, model.defaultGateway), gwp = gw && pos.get(gw.id);
        let inet = "";
        if (gwp) {
            inet = plainCard("Internet", "", "internet", gwp.x, 56, o);
            links += `<path d="M${gwp.x},${56 + CARD_H / 2} L${gwp.x},${gwp.y - CARD_H / 2}" fill="none" stroke="${t.link}" stroke-width="1.4" stroke-dasharray="3 4"/>`;
        }

        let nodes = "";
        for (const b of boxes) for (const n of b.ns) { const p = pos.get(n.id); nodes += card(n, p.x, p.y, o); }
        return { inner: s + links + inet + nodes, w: W, h: H, pos, boxes };
    }

    /* ---- tree view ---- */

    const GX = 170, GY = 120, LEAFH = 72;

    function buildTree(model) {
        const items = new Map();
        const add = it => { items.set(it.id, it); return it; };
        const zs = visibleZones(model);
        const inet = add({ id: "internet", kind: "inet", type: "internet", label: "Internet", parent: null });
        let prev = inet;
        for (const ip of (model.upstream || []).slice().reverse()) prev = add({ id: "hop:" + ip, kind: "hop", type: "router", ip, parent: prev.id });
        const top = prev;
        const defGw = findNodeByIp(model, model.defaultGateway);
        if (defGw) add({ id: defGw.id, kind: "node", node: defGw, parent: top.id });
        const localDef = [...model.nodes.values()].find(n => n.local && model.zones.get(n.zone) && model.zones.get(n.zone).iface === model.defaultDev) || [...model.nodes.values()].find(n => n.local);

        for (const z of zs) {
            let parent = defGw ? defGw.id : top.id, label = "";
            const gwHere = z.gateway ? model.nodes.get(nodeId(z.id, z.gateway)) : null;
            if (defGw && defGw.zone === z.id) parent = defGw.id;
            else if (z.kind === "routed") { const g = findNodeByIp(model, z.gateway); if (g) parent = g.id; label = "via " + z.gateway; }
            else if (defGw && gwHere && gwHere.mac && gwHere.mac === defGw.mac) parent = defGw.id;
            else if (localDef && z.id !== localDef.zone && [...model.nodes.values()].some(n => n.local && n.zone === z.id)) { parent = localDef.id; label = "this host"; }
            add({ id: "zone:" + z.id, kind: "zone", zone: z, parent, elabel: label });
        }
        for (const n of model.nodes.values()) {
            if (defGw && n.id === defGw.id) continue;
            const hdr = items.has("zone:" + n.zone) ? "zone:" + n.zone : top.id;
            const up = n.uplinkId && model.nodes.get(n.uplinkId);
            add({ id: n.id, kind: "node", node: n, parent: up && up.zone === n.zone && items.has(up.id) ? up.id : hdr, elabel: n.uplinkPort || "" });
        }
        for (const it of items.values()) {
            if (!it.parent) continue;
            if (!items.has(it.parent)) it.parent = top.id;
            const seen = new Set([it.id]);
            let c = items.get(it.parent);
            while (c) { if (seen.has(c.id)) { it.parent = top.id; break; } seen.add(c.id); c = c.parent ? items.get(c.parent) : null; }
        }
        // layout
        const children = new Map();
        for (const it of items.values()) { if (!it.parent) continue; if (!children.has(it.parent)) children.set(it.parent, []); children.get(it.parent).push(it); }
        const rk = it => (it.kind === "zone" ? -1 : it.kind === "node" ? RANK.indexOf(effType(it.node)) : 99);
        const ipn = it => (it.node && it.node.ip ? ip2n(it.node.ip) : 0);
        for (const arr of children.values()) arr.sort((a, b) => (rk(a) - rk(b)) || (ipn(a) - ipn(b)));
        let slot = 0, maxY = 0;
        const place = (it, y) => {
            it.y = y; maxY = Math.max(maxY, y);
            const kids = children.get(it.id) || [];
            if (!kids.length) { it.x = slot++ * GX + GX / 2 + 20; return; }
            if (kids.length > 8 && kids.every(k => !(children.get(k.id) || []).length)) {
                const cols = Math.min(8, Math.max(3, Math.ceil(Math.sqrt(kids.length * 1.6))));
                const start = slot;
                kids.forEach((k, i) => { k.x = (start + (i % cols)) * GX + GX / 2 + 20; k.y = y + GY + Math.floor(i / cols) * LEAFH; k.grid = true; maxY = Math.max(maxY, k.y); });
                it.gridBox = { x: start * GX + 24, y: y + GY - CARD_H / 2 - 12, w: cols * GX - 8, h: (Math.ceil(kids.length / cols) - 1) * LEAFH + CARD_H + 24 };
                slot += cols;
                it.x = (start + (cols - 1) / 2) * GX + GX / 2 + 20;
                return;
            }
            kids.forEach(k => place(k, y + GY));
            it.x = (kids[0].x + kids[kids.length - 1].x) / 2;
        };
        place(inet, 60);
        return { items, w: Math.max(slot, 1) * GX + 40, h: maxY + 90 };
    }

    function renderTree(model, o) {
        const t = o.theme, match = matcher(o.query);
        o = Object.assign({}, o, { match, model, zoneDot: true });
        const tree = buildTree(model);
        let edges = "", nodes = "";
        for (const it of tree.items.values()) {
            if (!it.parent || it.grid) continue;
            const p = tree.items.get(it.parent);
            const z = it.kind === "zone" ? it.zone : it.node && model.zones.get(it.node.zone);
            const col = z ? zoneColor(z) : t.link;
            const ph = p.kind === "zone" ? 22 : CARD_H / 2, ch = it.kind === "zone" ? 22 : CARD_H / 2;
            edges += `<path d="${curve(p.x, p.y + ph, it.x, it.y - ch)}" fill="none" stroke="${col}" stroke-opacity="0.7" stroke-width="1.5"/>`;
            if (it.elabel && !it.grid) edges += T((p.x + it.x) / 2 + 4, (p.y + it.y) / 2 + 2, it.elabel, { size: 8.5, fill: t.faint, anchor: "middle" });
        }
        for (const it of tree.items.values()) {
            if (!it.gridBox) continue;
            const g = it.gridBox, z = it.kind === "zone" ? it.zone : it.node && model.zones.get(it.node.zone), col = z ? zoneColor(z) : t.link;
            edges += `<rect x="${g.x}" y="${g.y}" width="${g.w}" height="${g.h}" rx="12" fill="${col}" fill-opacity="0.05" stroke="${col}" stroke-opacity="0.45" stroke-dasharray="4 4"/>`;
            edges += `<path d="${curve(it.x, it.y + (it.kind === "zone" ? 22 : CARD_H / 2), it.x, g.y)}" fill="none" stroke="${col}" stroke-opacity="0.7" stroke-width="1.5"/>`;
        }
        for (const it of tree.items.values()) {
            if (it.kind === "inet") nodes += plainCard("Internet", "", "internet", it.x, it.y, o);
            else if (it.kind === "hop") nodes += plainCard("Upstream hop", it.ip, "router", it.x, it.y, o);
            else if (it.kind === "node") nodes += card(it.node, it.x, it.y, o);
            else {
                const z = it.zone, c = zoneColor(z), bd = zoneBadge(z), sel = o.selected === "zone:" + z.id;
                nodes += `<g data-zone="${esc(z.id)}" transform="translate(${it.x},${it.y})">` +
                    `<rect x="-100" y="-22" width="200" height="44" rx="11" fill="${c}" fill-opacity="0.12" stroke="${c}" stroke-width="${sel ? 2.4 : 1.3}"/>` +
                    `<rect x="-90" y="-15" width="${bd.w}" height="18" rx="9" fill="${c}"/>` + T(-90 + bd.w / 2, -2.5, bd.text, { size: 9.5, weight: 700, fill: "#ffffff", anchor: "middle" }) +
                    T(-90 + bd.w + 7, -2, trunc(zoneTitle(z), 14), { size: 11.5, weight: 650, fill: t.text }) +
                    T(-90, 14, z.cidr, { size: 9.5, mono: true, fill: t.muted }) + "</g>";
            }
        }
        return { inner: DEFS + edges + nodes, w: tree.w, h: tree.h };
    }

    function standaloneSvg(r, theme, title) {
        return `<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="${r.w}" height="${r.h}" viewBox="0 0 ${r.w} ${r.h}">` +
            `<title>${esc(title || "Network map")}</title><rect width="100%" height="100%" fill="${theme.bg}"/>${r.inner}</svg>\n`;
    }

    return {
        VERSION, TYPES, RANK, ASSIGNABLE, PURPOSES, THEMES, ZONE_COLORS,
        ip2n, n2ip, cidrNet, inCidr, cidrHosts, normMac, isIpv4, esc,
        zoneColor, zoneKey, nodeKey, effType, displayName, zoneBadge, zoneTitle,
        buildZones, createModel, nodeId, upsertNode, zoneNodes, findNodeByIp, findNodeByMac, orderedZones, visibleZones,
        classifyNode, classifyAll, parseLldp, parseTraceroute, parseFdb, parseVlanNames, buildTopology, applyAnnotations,
        serialize, deserialize, inventoryRows, toCsv, toMarkdown, summary, sortNodes, matcher,
        renderZones, renderTree, buildTree, standaloneSvg,
    };
}));
