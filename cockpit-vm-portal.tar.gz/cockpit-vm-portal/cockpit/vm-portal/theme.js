/* Follow Cockpit's own light/dark choice (Cockpit stores it as "shell:style" = auto | light | dark
 * in localStorage and toggles the pf-v5/v6-theme-dark class on <html>). Loaded synchronously in <head>. */
(function () {
    "use strict";
    var mq = window.matchMedia("(prefers-color-scheme: dark)");
    function apply() {
        var style = "auto";
        try { style = window.localStorage.getItem("shell:style") || "auto"; } catch (e) { /* ignore */ }
        var dark = style === "dark" || (style === "auto" && mq.matches);
        var cl = document.documentElement.classList;
        cl.toggle("pf-v5-theme-dark", dark);
        cl.toggle("pf-v6-theme-dark", dark);
    }
    apply();
    window.addEventListener("storage", function (e) { if (e.key === "shell:style") apply(); });
    if (mq.addEventListener) mq.addEventListener("change", apply);
})();
